import json
from vasyunin import gram, bk
import numpy as np
d = json.load(open("economia.json"))
QI, QO = d["voraz"]["info_Q"], d["voraz"]["oga_Q"]
G = gram(list(range(1, 81))); b = np.array([bk(n) for n in range(1, 81)])
seg = []
for m in range(1, 81):
    L = np.linalg.cholesky(G[:m, :m]); y = np.linalg.solve(L, b[:m]); seg.append(1 - y @ y)
for eps in (0.03, 0.02, 0.015, 0.0125, 0.011):
    f = lambda Q: next((i+1 for i, q in enumerate(Q) if q <= eps), None)
    print(f"eps={eps}: segmento {f(seg)}  voraz-ΔI {f(QI)}  voraz-OGA {f(QO)}")
