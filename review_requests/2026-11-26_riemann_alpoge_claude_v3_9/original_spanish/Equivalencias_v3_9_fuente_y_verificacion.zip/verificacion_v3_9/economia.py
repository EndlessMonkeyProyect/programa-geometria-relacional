"""Ley de ganancia, información y economía mínima en el espacio de Báez-Duarte.
H = L2((0,inf), dt/t^2), chi = 1_[1,inf), e_n(t) = {t/n}. Q(K) = dist(chi, span{e_n: n in K})^2.
Información recuperable: I(K) = 1/2 log(1/Q(K)) (nats)."""
import numpy as np, json
from math import log
from vasyunin import ip, bk, gram

def Qof(idx):
    idx = list(idx)
    if not idx: return 1.0
    G = gram(idx); b = np.array([bk(n) for n in idx])
    L = np.linalg.cholesky(G)
    y = np.linalg.solve(L, b)
    return 1.0 - y @ y

def smooth(S, L):
    out = [1]
    for p in S:
        new = []
        for n in out:
            m = n*p
            while m <= L:
                new.append(m); m *= p
        out = sorted(out + new)
    return out

res = {}
# 1) segmento inicial con Gram exacto (revisa la tabla de 4.3)
seg = {N: Qof(range(1, N+1)) for N in (1, 2, 3, 5, 10, 20, 30, 40, 80, 160, 320)}
print("Q_N exacto:", {N: round(q, 5) for N, q in seg.items()})
print("Q_N log N:", {N: round(q*log(N), 4) for N, q in seg.items() if N > 1})
res["segmento"] = seg

# 2) ley de ganancia: comprobación de Q(V)-Q(V') = ||P_Z r||^2 y de la forma informacional
#    V = span{e_n : n 5-suave <= 300}, W = D_7 V = span{e_{7n}}
V = smooth([2, 3, 5], 300); W = [7*n for n in V]
QV, QVW = Qof(V), Qof(sorted(set(V + W)))
idx = V + W
Gfull = gram(idx); bfull = np.array([bk(n) for n in idx])
nV = len(V)
GV = Gfull[:nV, :nV]; bV = bfull[:nV]
cV = np.linalg.solve(GV, bV)                       # P_V chi = sum cV e
# r = chi - P_V chi ; Z = (I-P_V) W
# Gram de Z: G_WW - G_WV GV^-1 G_VW ; <r, z_w> = <chi, e_w> - <P_V chi, e_w>
GWW = Gfull[nV:, nV:]; GWV = Gfull[nV:, :nV]; bW = bfull[nV:]
GZ = GWW - GWV @ np.linalg.solve(GV, GWV.T)
rz = bW - GWV @ cV
gain = rz @ np.linalg.lstsq(GZ, rz, rcond=None)[0]
print(f"ley de ganancia: Q(V)-Q(V+D7V) = {QV-QVW:.10f}   ||P_Z r||^2 = {gain:.10f}")
res["ley"] = {"QV": QV, "QVW": QVW, "gain": gain, "nV": nV}

# 3) cadena por primos: S_j = primeros j primos, índices S_j-suaves <= L
primes = [2, 3, 5, 7, 11, 13, 17, 19, 23]
chain = {}
for L in (500, 2000, 8000):
    rows = []; Qprev = Qof([1])
    rows.append((0, 1, 1, Qprev, None, None))
    for j in range(1, len(primes)+1):
        S = primes[:j]; idx = smooth(S, L)
        if len(idx) > 900: break
        q = Qof(idx)
        eta = 1 - q/Qprev; dI = 0.5*log(Qprev/q)
        rows.append((j, primes[j-1], len(idx), q, eta, dI)); Qprev = q
    chain[L] = rows
    print(f"\nL={L}")
    for r in rows:
        print("  j=%d p=%s  #=%4d  Q=%.5f  eta=%s  dI=%s" % (r[0], r[1] if r[0] else "-", r[2], r[3],
              "%.4f" % r[4] if r[4] is not None else "-", "%.4f" % r[5] if r[5] is not None else "-"))
res["cadena"] = {str(k): v for k, v in chain.items()}

# 4) economía mínima por cardinalidad: voraz por máxima ganancia de información (dicc. n <= M)
M = 1000
G = gram(list(range(1, M+1))); b = np.array([bk(n) for n in range(1, M+1)])
def greedy(rule, steps=80):
    sel = []; Qs = []
    P = np.zeros((0, M)); a = np.zeros(0)        # <q_i, e_n>, <chi, q_i>
    diag = np.diag(G).copy()
    for _ in range(steps):
        u2 = diag - (P**2).sum(0)                   # ||(I-P_V) e_n||^2
        re = b - a @ P                              # <r, e_n>
        u2[sel] = np.inf
        score = re**2/np.maximum(u2, 1e-300) if rule == "info" else re**2/diag
        score[sel] = -1
        n = int(np.argmax(score)); sel.append(n)
        q = (G[n] - P[:, n] @ P)/np.sqrt(u2[n])
        a = np.append(a, re[n]/np.sqrt(u2[n])); P = np.vstack([P, q])
        Qs.append(1 - a @ a)
    return [s+1 for s in sel], Qs
selI, QI = greedy("info"); selO, QO = greedy("oga")
for m in (5, 10, 20, 40, 80):
    print(f"m={m:3d}  segmento Q={Qof(range(1, m+1)):.5f}   voraz-info Q={QI[m-1]:.5f} (exacto {Qof(selI[:m]):.5f})   voraz-OGA Q={QO[m-1]:.5f}")
print("primeros 25 índices voraz-info:", selI[:25])
print("primeros 25 índices voraz-OGA:", selO[:25])
res["voraz"] = {"info_sel": selI, "info_Q": QI, "oga_sel": selO, "oga_Q": QO,
                "seg_Q": {m: Qof(range(1, m+1)) for m in (5, 10, 20, 40, 80)},
                "info_Q_exact": {m: Qof(selI[:m]) for m in (5, 10, 20, 40, 80)}}
json.dump(res, open("economia.json", "w"), default=float, indent=1)
