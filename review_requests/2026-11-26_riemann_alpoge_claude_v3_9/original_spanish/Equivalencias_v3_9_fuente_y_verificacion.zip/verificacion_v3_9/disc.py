import mpmath as mp, numpy as np
mp.mp.dps = 25
gam = np.load("zeros_im.npy")
rho = [mp.mpc(0.5, float(t)) for t in gam]
def r(X):
    X = mp.mpf(X)
    return mp.nsum(lambda k: X**(-2*k)/(2*k*(2*k+1)), [1, mp.inf])
def d2(f, m): return f(m+1) - 2*f(m) + f(m-1)
for m in [5, 7, 8, 9, 10, 12]:
    a = m*d2(lambda X: X*mp.log(X) if X > 0 else 0, m)
    zs = 0
    for rr in rho:
        zs += 2*mp.re(d2(lambda X: mp.mpf(X)**rr, m)/(rr*(rr-1)))
    val = a - m*zs - m*d2(r, m)
    ps = [p for p in range(2, m+1) if m % p == 0 and all(p % q for q in range(2, p))]
    lam = mp.log(ps[0]) if len(ps) == 1 else 0
    print(m, mp.nstr(val, 8), " Λ(m) =", mp.nstr(lam, 8))
