"""Criterio de Báez-Duarte: Gram de e_k(t)={t/k} en H=L2((0,inf), dt/t^2), chi=1_[1,inf).
d_N^2 = 1 - b^T G^{-1} b = det Gram(chi,e_1..e_N) / det Gram(e_1..e_N)."""
import numpy as np, json
from math import gcd, lcm
import mpmath as mp

g = 0.57721566490153286060651209
C0 = 2 + g - np.log(4*np.pi)

def inner(j, k, U_periods=None):
    L = lcm(j, k)
    U = L * max(1, int(4e5 // L))          # U múltiplo del periodo, ~4e5
    br = np.union1d(np.arange(0, U + 1, j), np.arange(0, U + 1, k)).astype(np.float64)
    a = np.floor(br[:-1] / j + 1e-12); b = np.floor(br[:-1] / k + 1e-12)
    Lf, R = br[:-1], br[1:]
    # tramo inicial [0, min(j,k)]: integrando constante 1/(jk)
    first = min(j, k) / (j * k)
    Lf, R, a, b = Lf[1:], R[1:], a[1:], b[1:]
    val = (R - Lf)/(j*k) - (b/j + a/k)*np.log(R/Lf) + a*b*(1/Lf - 1/R)
    m = 0.25 + gcd(j, k)**2 / (12*j*k)      # media de {t/j}{t/k}
    return first + np.sum(val) + m / U

def bk(k):
    return (np.log(k) + 1 - g) / k

Nmax = 40
G = np.zeros((Nmax, Nmax))
for j in range(1, Nmax + 1):
    for k in range(j, Nmax + 1):
        G[j-1, k-1] = G[k-1, j-1] = inner(j, k)
b = np.array([bk(k) for k in range(1, Nmax + 1)])

# chequeo de una entrada con mpmath (j=2,k=3)
f = lambda t: mp.frac(t/2) * mp.frac(t/3) / t**2
pts = [0] + list(range(1, 2001))
chk = mp.quad(f, pts) + (mp.mpf(1)/4 + mp.mpf(1)/72) / 2000
print("<e2,e3> tramos:", G[1, 2], " mpmath:", mp.nstr(chk, 12))
print("<e1,e1> =", G[0, 0], " (exacto: log 2pi - g =", np.log(2*np.pi) - g, ")")

rows = []
for N in range(1, Nmax + 1):
    Gn = G[:N, :N]; bn = b[:N]
    c = np.linalg.solve(Gn, bn)
    d2 = 1 - bn @ c
    if N <= 10:
        full = np.zeros((N+1, N+1)); full[0, 0] = 1.0; full[0, 1:] = full[1:, 0] = bn; full[1:, 1:] = Gn
        ratio = np.linalg.det(full) / np.linalg.det(Gn)
    else:
        ratio = float("nan")
    rows.append((N, d2, ratio, d2*np.log(N) if N > 1 else float("nan"), np.linalg.cond(Gn)))
for N, d2, ratio, dl, cnd in rows:
    if N in (1, 2, 3, 4, 5, 8, 10, 15, 20, 25, 30, 35, 40):
        print(f"N={N:>2}  d_N^2={d2:.6f}  detratio={ratio:.6f}  d_N^2 logN={dl:.4f}  cond={cnd:.1e}")
print("C0 =", C0)
json.dump({"rows": rows, "C0": C0}, open("gram.json", "w"), default=float)
