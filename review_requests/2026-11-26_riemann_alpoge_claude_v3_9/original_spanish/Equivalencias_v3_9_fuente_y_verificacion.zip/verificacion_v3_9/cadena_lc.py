"""Finite squarefree inheritance, Gram Schur identity, and global controls.
Exact index sets and analytic Gram formula; floating-point evaluation."""
import json, math, itertools
import numpy as np
from vasyunin import gram, bk

def solve(G,b): return np.linalg.solve(G,b)
def data(idx):
    G=gram(idx); b=np.array([bk(n) for n in idx]); s=np.sqrt(np.diag(G)); return G/s[:,None]/s[None,:],b/s,s

def q(G,b): return float(1-b@solve(G,b))
idx=[1]; rows=[]; G,b,s=data(idx); old=q(G,b)
for p in [2,3,5,7,11,13,17]:
    idx2=idx+[p*n for n in idx]; F,h,s2=data(idx2); r=len(idx)
    A=F[:r,:r]; C=F[:r,r:]; B=F[r:,r:]
    L=np.linalg.cholesky(A); R=np.linalg.solve(L,C); R=np.linalg.solve(L,R.T).T
    schur=B-C.T@solve(A,C); v=h[r:]-C.T@solve(A,h[:r]); new=q(F,h)
    gain=float(v@solve(schur,v)); K=float(-.5*np.linalg.slogdet(np.eye(r)-R.T@R)[1]); err=abs(np.linalg.slogdet(F)[1]-2*np.linalg.slogdet(A)[1]+2*K)
    w={str(eps):float(1-2*(a:=np.array([-(-1)**(i.bit_count())*n**(-eps) for i,n in enumerate(idx2)])*s2)@h+a@F@a) for eps in (0,.25)}
    row=dict(p=p,refs=len(idx2),scale=max(idx2),Q=new,p_eta=p*(1-new/old),gain=gain,delta_I=.5*math.log(old/new),K=K,K_per_rank=K/r,max_corr=float(np.linalg.svd(R,compute_uv=False)[0]),schur_error=abs(old-new-gain),det_error=err,weights=w)
    rows.append(row);print(row,flush=True);idx=idx2;old=new
F,h,_=data(list(range(1,101))); controls={}
for k in (2,3):
    best=(1.,None)
    for i0 in range(100-k+1):
        ix=np.array([(i0,)+t for t in itertools.combinations(range(i0+1,100),k-1)])
        g=F[ix[:,:,None],ix[:,None,:]]; v=h[ix]; c=np.linalg.solve(g,v[...,None])[...,0]; qs=1-(v*c).sum(axis=1); i=int(np.argmin(qs))
        if qs[i]<best[0]:best=(float(qs[i]),(ix[i]+1).tolist())
    controls[str(k)]={'Q':best[0],'refs':best[1]}
sel=[]; G0=F; b0=h; greedy=[]
for k in range(3):
    candidates=[i for i in range(100) if i not in sel]
    best=min((q(F[np.ix_(sel+[i],sel+[i])],h[sel+[i]]),i) for i in candidates)
    sel.append(best[1]);greedy.append({'Q':best[0],'refs':[i+1 for i in sel]})
print('controls',controls,greedy,flush=True)
json.dump({'chain':rows,'global':controls,'greedy':greedy},open('cadena_lc.json','w'),indent=2)
