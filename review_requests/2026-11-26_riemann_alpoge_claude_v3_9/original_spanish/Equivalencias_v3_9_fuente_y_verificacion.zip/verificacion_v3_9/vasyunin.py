"""Productos internos exactos en H = L2((0,inf), dt/t^2) para e_k(t) = {t/k}.
Para h, k coprimos (fórmula de Vasyunin):
  <e_h,e_k> = (log 2pi - g)/2 (1/h + 1/k) + (k-h)/(2hk) log(h/k) - pi/(2hk) (V(h,k) + V(k,h)),
  V(h,k) = sum_{m=1}^{k-1} {m h / k} cot(pi m / k).
Para índices generales: <e_{g h}, e_{g k}> = <e_h, e_k> / g."""
import numpy as np
from math import gcd, log, pi
G_E = 0.57721566490153286060651209
L2P = log(2*pi)

def V(h, k):
    if k == 1: return 0.0
    m = np.arange(1, k)
    return float(np.sum(((m*h) % k)/k / np.tan(np.pi*m/k)))

_cache = {}
def ip(a, b):
    g = gcd(a, b); h, k = a//g, b//g
    if h > k: h, k = k, h
    key = (h, k)
    if key not in _cache:
        _cache[key] = (L2P - G_E)/2*(1/h + 1/k) + (k - h)/(2*h*k)*log(h/k) - pi/(2*h*k)*(V(h, k) + V(k, h))
    return _cache[key] / g

def bk(k):
    return (log(k) + 1 - G_E)/k

def gram(idx):
    n = len(idx); G = np.empty((n, n))
    for i in range(n):
        for j in range(i, n):
            G[i, j] = G[j, i] = ip(idx[i], idx[j])
    return G

if __name__ == "__main__":
    import json
    # validación contra integración exacta por tramos (gram.py)
    import importlib.util
    src = open("gram.py").read().split("def bk")[0]
    ns = {}; exec(src, ns)
    worst = 0
    for (a, b) in [(1,1),(1,2),(2,3),(3,5),(4,7),(5,12),(6,10),(9,14),(11,13),(8,27),(20,21),(15,35)]:
        x, y = ip(a, b), ns["inner"](a, b)
        worst = max(worst, abs(x-y))
        print(f"<e{a},e{b}>  Vasyunin {x:.12f}   tramos {y:.12f}   dif {abs(x-y):.1e}")
    print("peor diferencia:", worst)
