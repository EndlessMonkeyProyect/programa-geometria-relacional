import numpy as np, json, matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
plt.rcParams.update({"font.family": "serif", "font.serif": ["Latin Modern Roman", "DejaVu Serif"],
                     "mathtext.fontset": "cm", "font.size": 9, "axes.linewidth": 0.6})
d = dict(np.load("figdata.npz")); C0 = json.load(open("wnum.json"))["C0"]
N = 1_000_001
lam = np.zeros(N + 1); sv = np.ones(N + 1, bool); sv[:2] = False
for p in range(2, int(N**0.5) + 1):
    if sv[p]: sv[p*p::p] = False
for p in np.nonzero(sv)[0]:
    pk = int(p)
    while pk <= N: lam[pk] = np.log(p); pk *= int(p)
n = np.arange(N + 1); A = np.cumsum(np.where(n > 0, lam / np.maximum(n, 1), 0)); psi = np.cumsum(lam)
g = 0.5772156649015329
X = d["xz"]; m = np.floor(X).astype(int)
y = 1 / X; r = -0.5*np.log1p(-y*y) - np.arctanh(y)/y + 1
W = X*A[m] - psi[m] - X*np.log(X) + (1 + g)*X
d["xs"] = X; d["zp"] = (W - np.log(2*np.pi) + r) / np.sqrt(X)
print("max |primos - ceros| (sobre la escala /sqrt X):", np.max(np.abs(d["zp"] - d["zz"])))
BLUE, ORANGE, INK, GRID, AXIS = "#257de0", "#f47230", "#1f2d3d", "#e7e7e7", "#c2c2c2"
fig, ax = plt.subplots(figsize=(6.2, 2.75), dpi=200)
ax.axhspan(-C0, C0, color="#f2f4f7", zorder=0)
for y in (-C0, C0):
    ax.axhline(y, color="#8a97a8", lw=0.8, ls=(0, (4, 3)), zorder=1)
ax.axhline(0, color=AXIS, lw=0.6, zorder=1)
ax.plot(d["xs"], d["zp"], color=BLUE, lw=1.1, zorder=3, label="desde los primos: $W(X)$")
ax.plot(d["xz"], d["zz"], color=ORANGE, lw=0.9, ls=(0, (2.5, 2)), zorder=4, label="desde 400 ceros de $\\zeta$")
ax.set_xscale("log"); ax.set_xlim(10, 1e6); ax.set_ylim(-0.055, 0.055)
ax.set_xlabel("$X$", color=INK); ax.set_ylabel("$(W(X)-\\log 2\\pi + r(X))/\\sqrt{X}$", color=INK, fontsize=8)
ax.text(1.2e6, C0, " $+C_0$", va="center", ha="left", color=INK, fontsize=8, clip_on=False)
ax.text(1.2e6, -C0, " $-C_0$", va="center", ha="left", color=INK, fontsize=8, clip_on=False)
ax.grid(axis="y", color=GRID, lw=0.5); ax.tick_params(colors=INK, width=0.5, labelsize=8)
for s in ("top", "right"): ax.spines[s].set_visible(False)
for s in ("left", "bottom"): ax.spines[s].set_color(AXIS)
ax.legend(loc="lower left", bbox_to_anchor=(0, 1.0), frameon=False, fontsize=7.5, ncol=2, borderaxespad=0.2)
fig.tight_layout(); fig.savefig("fig_W.pdf"); fig.savefig("fig_W.png")
