"""W(X) desde los primos hasta 1e7, cota bajo RH y comparación con la suma sobre ceros."""
import numpy as np, json
import mpmath as mp

N = 10_000_000
g = 0.57721566490153286060651209
C0 = 2 + g - np.log(4*np.pi)
L2P = np.log(2*np.pi)

# Lambda(n)
lam = np.zeros(N + 1, dtype=np.float64)
sv = np.ones(N + 1, bool); sv[:2] = False
for p in range(2, int(N**0.5) + 1):
    if sv[p]: sv[p*p::p] = False
pr = np.nonzero(sv)[0]
for p in pr:
    lp = np.log(p); pk = int(p)
    while pk <= N:
        lam[pk] = lp; pk *= int(p)

n = np.arange(N + 1, dtype=np.longdouble)
A = np.cumsum(np.where(n > 0, lam.astype(np.longdouble) / np.maximum(n, 1), 0))   # sum Λ/n
psi = np.cumsum(lam.astype(np.longdouble))
X = n[1:]
T = X * A[1:] - psi[1:]
def r(Xv):
    y = 1/np.asarray(Xv, dtype=np.longdouble)
    out = np.where(y < 1, -0.5*np.log1p(-y*y) - np.arctanh(np.minimum(y, 0.999999))/y + 1, 1 - np.log(2))
    return out
W = T - X*np.log(X) + (1 + g)*X
Z = (W - L2P + r(X)) / np.sqrt(X)          # debe cumplir |Z| <= C0 bajo RH
# extremos interiores en (m, m+1): W'(X) = A(m) - log X + γ
m = n[1:-1]
Xs = np.exp(A[1:-1] + g)
inside = (Xs > m) & (Xs < m + 1)
Wi = Xs[inside]*A[1:-1][inside] - psi[1:-1][inside] - Xs[inside]*np.log(Xs[inside]) + (1+g)*Xs[inside]
Zi = (Wi - L2P + r(Xs[inside])) / np.sqrt(Xs[inside])
zmax = max(float(np.max(np.abs(Z[1:]))), float(np.max(np.abs(Zi))) if Zi.size else 0.0)
i = int(np.argmax(np.abs(Z[1:]))) + 2
print("C0 =", C0)
print("max |W - log2pi + r|/sqrt X, 2<=X<=1e7:", zmax, " en X≈", i, " ratio a C0:", zmax/C0)
for k in range(1, 8):
    s = slice(10**(k-1), 10**k)
    print(f"  10^{k-1}..10^{k}: max {float(np.max(np.abs(Z[s]))):.5f}")

# suma sobre ceros
gam = np.load("zeros_im.npy")
rho = 0.5 + 1j*gam
def Wzeros(Xv, K):
    Xv = np.asarray(Xv, float)
    s = np.zeros_like(Xv)
    for rr in rho[:K]:
        s += 2*np.real(np.exp(rr*np.log(Xv)) / (rr*(rr - 1)))
    return L2P - s - r(Xv).astype(float)
samples = [10, 100, 1000, 10_000, 100_000, 1_000_000, 10_000_000]
rows = []
for Xv in samples:
    wp = float(W[Xv - 1]); wz = float(Wzeros([Xv], 400)[0])
    rows.append((Xv, wp, wz, wp - wz, (wp - wz)/np.sqrt(Xv)))
    print(f"X={Xv:>9}  W(primos)={wp: .6f}  W(400 ceros)={wz: .6f}  dif={wp-wz: .2e}  dif/√X={(wp-wz)/np.sqrt(Xv): .2e}")

# datos para la figura (muestreo log)
xs = np.unique(np.round(np.logspace(1, 6, 4000)).astype(int))
zp = ((W[xs - 1] - L2P + r(xs)) / np.sqrt(xs)).astype(float)
xz = np.logspace(1, 6, 6000)
zz = (Wzeros(xz, 400) - L2P + r(xz).astype(float)) / np.sqrt(xz)
np.savez("figdata.npz", xs=xs, zp=zp, xz=xz, zz=zz)
json.dump({"C0": C0, "zmax": zmax, "argmax": i, "rows": rows,
           "bands": {k: float(np.max(np.abs(Z[10**(k-1):10**k]))) for k in range(1, 8)}},
          open("wnum.json", "w"), indent=1, default=float)
