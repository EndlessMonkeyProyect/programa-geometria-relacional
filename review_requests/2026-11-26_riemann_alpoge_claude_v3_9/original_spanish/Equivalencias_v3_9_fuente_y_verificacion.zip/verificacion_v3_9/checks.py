"""Comprobaciones numéricas de las identidades de la v3.2."""
import mpmath as mp
import numpy as np
from math import gcd

mp.mp.dps = 30
g = mp.euler

def primes_upto(n):
    s = np.ones(n + 1, bool); s[:2] = False
    for p in range(2, int(n ** 0.5) + 1):
        if s[p]: s[p*p::p] = False
    return np.nonzero(s)[0]

print("== (a) T_p E_S = E_{S u p}")
def C(S, x):
    return sum(1 for n in range(1, int(x) + 1) if all(n % p for p in S))
def delta(S):
    r = mp.mpf(1)
    for p in S: r *= (1 - mp.mpf(1)/p)
    return r
def E(S, x): return C(S, x) - delta(S) * x
S = [2, 3]; p = 5
err = max(abs(E(S+[p], x) - (E(S, x) - E(S, mp.mpf(x)/p))) for x in [mp.mpf(k)/7 for k in range(1, 2000, 13)])
print("max err", err)
xs = [mp.mpf(k)/3 for k in range(1, 3000, 7)]
print("max |E_S| (S=2,3,5,7):", max(abs(E([2,3,5,7], x)) for x in xs), "cota 2^(|S|-1)=8")

print("== (b) Mellin F_S = zeta P_S / s, S={2,3}, s=0.6+3i")
s = mp.mpc(0.6, 3)
S = [2, 3]; P = 6; dS = delta(S)
# E_S periódica de periodo 6; integración exacta por tramos lineales
def piece(c, a, b, s):
    # ∫_a^b (c - dS x) x^{-s-1} dx
    I1 = c * (a**(-s) - b**(-s)) / s if a > 0 else None
    I2 = -dS * (b**(1-s) - a**(1-s)) / (1 - s)
    return I1 + I2
tot = -dS * (mp.mpf(1)**(1-s)) / (1 - s)   # tramo [0,1]: -dS x
cnt = 0; M = 60000
for n in range(1, M):
    if n % 2 and n % 3: cnt += 1
    tot += piece(cnt, mp.mpf(n), mp.mpf(n+1), s)
lhs = tot
rhs = mp.zeta(s) * (1 - 2**(-s)) * (1 - 3**(-s)) / s
print("lhs", mp.nstr(lhs, 10), " rhs", mp.nstr(rhs, 10), " |diff|", mp.nstr(abs(lhs-rhs), 3))

print("== (c) -F_S'/F_S - 1/s = sum Lambda_S n^-s, S={2,3}, s=2")
s = mp.mpf(2)
F = lambda z: mp.zeta(z) * (1 - 2**(-z)) * (1 - 3**(-z)) / z
lhs = -mp.diff(F, s) / F(s) - 1/s
N = 2_000_000
pr = primes_upto(N)
acc = mp.mpf(0)
for q in pr:
    if q in (2, 3): continue
    lq = mp.log(q); pk = mp.mpf(q)
    while pk <= N:
        acc += lq / pk**2; pk *= q
print("lhs", mp.nstr(lhs, 12), " suma (n<=2e6)", mp.nstr(acc, 12), " cola ~", mp.nstr(1/mp.mpf(N), 2))

print("== (d) Mellin de T: ∫_1^∞ T(X) X^{-s-1} dX = (-zeta'/zeta)(s)/(s(s-1)) en s=2 ; ⟨(X/n-1)_+⟩ = n^-s/(s(s-1))")
n = 7; s = mp.mpf(2.5)
val = mp.quad(lambda X: (X/n - 1) * X**(-s-1), [n, mp.inf])
print(mp.nstr(val, 15), mp.nstr(mp.mpf(n)**(-s)/(s*(s-1)), 15))

print("== (e) residuo en s=1 y en s=0")
X = mp.mpf(37.3)
f = lambda z: (-mp.zeta(z, derivative=1)/mp.zeta(z)) * X**z / (z*(z-1))
r1 = mp.mpf(0)
# residuo numérico en s=1 por integral de contorno
r1 = mp.quad(lambda t: f(1 + 0.3*mp.expj(t)) * 0.3j*mp.expj(t), [0, 2*mp.pi]) / (2j*mp.pi)
print("Res s=1:", mp.nstr(r1, 12), " esperado X log X-(1+g)X:", mp.nstr(X*mp.log(X)-(1+g)*X, 12))
r0 = mp.quad(lambda t: f(0.3*mp.expj(t)) * 0.3j*mp.expj(t), [0, 2*mp.pi]) / (2j*mp.pi)
print("Res s=0:", mp.nstr(r0, 12), " esperado log 2pi:", mp.nstr(mp.log(2*mp.pi), 12))

print("== (f) suma sobre ceros: sum 1/(rho(rho-1)) = log4pi-2-g ; sum 1/|rho|^2 = 2+g-log4pi")
K = 400
zs = [mp.zetazero(k) for k in range(1, K+1)]
S1 = sum(2*mp.re(1/(r*(r-1))) for r in zs)
S2 = sum(2/abs(r)**2 for r in zs)
T = mp.im(zs[-1])
tail = (1/mp.pi) * (mp.log(T/(2*mp.pi)) + 1) / T   # ~ 2 * ∫_T^∞ (1/2π)log(t/2π) dt / t^2
C0 = 2 + g - mp.log(4*mp.pi)
print("sum 1/(rho(rho-1)) [K=400]:", mp.nstr(S1, 10), " +cola≈", mp.nstr(S1 - tail, 10), " teórico", mp.nstr(-C0, 10))
print("sum 1/|rho|^2 [K=400]:", mp.nstr(S2, 10), " +cola≈", mp.nstr(S2 + tail, 10), " C0 =", mp.nstr(C0, 10))
np.save("zeros_im.npy", np.array([float(mp.im(r)) for r in zs]))

print("== (g) <chi, e_k> = (log k + 1 - g)/k  en H = L2(dt/t^2), e_k(t) = {t/k}, chi = 1_[1,inf)")
for k in [1, 2, 5, 12]:
    # ∫_1^∞ {t/k} t^-2 dt ; tramos exactos
    tot = mp.mpf(0)
    # [1,k]: t/k
    tot += mp.log(k) / k
    # [jk,(j+1)k], j>=1: (t/k - j)/t^2
    J = 200000
    for j in range(1, J):
        a, b = j*k, (j+1)*k
        tot += mp.log(mp.mpf(b)/a)/k - j*(mp.mpf(1)/a - mp.mpf(1)/b)
    tot += mp.mpf(1)/2 / (J*k)  # cola: media 1/2
    print(k, mp.nstr(tot, 10), mp.nstr((mp.log(k) + 1 - g)/k, 10))
