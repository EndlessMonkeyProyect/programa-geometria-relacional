# Historial de esta edición

## Complemento P frente a NP y el cubo de espejos — 2026-10-28

- Incorporación revisada del suplemento P/NP × CME del 28-oct; el suplemento recibido se conserva sin cambios en `recibido/`, y sus 49 fuentes congeladas, idénticas a las de 2026-10-24, no se duplican.
- Nueva sección «El cubo como imagen tangible del problema» y siete controles exactos (C1–C7) en el puente revisado.
- Ocho correcciones registradas en `REVISION_2026-10-28.md`, y diez precisiones más tras dos revisiones cruzadas asistidas por IA: el historial del issue #1 (cerrado y reabierto el 25-oct, con la respuesta de la API guardada), los polimorfismos de K₃ frente a S₃, el espejo móvil sin inclinación hacia P ≠ NP, que una restricción nueva no siempre obliga a refinar, recuentos frente a relaciones en (2,3,6) y (2,3,7), los niveles de prueba y la reproducción antes y después de publicar, con `--rapido` y `--limite`.
- `reproducir_todo.py`: integridad y todos los verificadores en copia temporal; resultados idénticos byte a byte.
- Traducción inglesa del documento principal y guía `READ_FIRST.en.md`.

## Complemento Más allá de Yang–Mills — 2026-10-27

- Incorporación del artículo en español e inglés, en Markdown y PDF, y de siete paquetes PR-01 a PR-07.
- Revisión independiente de R-02, resultados de referencia y manifiesto SHA-256: 47 archivos verificados.
- El complemento se presenta como borrador para revisión y deja explícita la brecha de masa como problema abierto.

## Edición ordenada — 2026-10-24

- Incorporación navegable del paquete fechado: 1.047 archivos cotejados con su manifiesto SHA-256.
- Manuscrito público, suplemento de ritmo y gravedad, hilo integrado, realizaciones, ramas, laboratorios y archivo histórico.
- Guía y textos principales en inglés; la edición conceptual 0.1.0 continúa disponible.

## 0.1.0-editorial — 2026-09-29

- Preservación de 79 archivos recibidos y extracción navegable de tres miembros del ZIP.
- Síntesis y diez capítulos conceptuales.
- Glosario, notación, linaje y registro de 26 resultados.
- Separación de correcciones históricas, nueve observaciones editoriales y ocho pendientes.
- Catálogo completo y manifiesto de integridad.
- Ejemplos nuevos y verificaciones identificados como editoriales.
- Repositorio Git inicial y bundle portable.
- Traducción inglesa de los 25 documentos editoriales; las fuentes originales permanecen intactas.
- Publicación en GitHub y protección de los bytes originales en las clonaciones de Windows.

Esta numeración describe el trabajo editorial. No sustituye las versiones v0.xx ni los identificadores MF del programa.
