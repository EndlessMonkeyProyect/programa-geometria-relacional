# History of this edition

## P versus NP and the mirror cube complement — 2026-10-28

- Revised integration of the 28-Oct P/NP × CME supplement; the received supplement is kept unchanged in `recibido/`, and its 49 frozen sources, identical to those of 2026-10-24, are not duplicated.
- New section "The cube as a tangible image of the problem" and seven exact controls (C1–C7) in the revised bridge.
- Eight corrections recorded in `REVISION_2026-10-28.md`, plus ten precisions after two AI-assisted cross-reviews: the history of issue #1 (closed and reopened on 25 Oct, with the API response kept), K₃'s polymorphisms versus S₃, the moving mirror without a lean toward P ≠ NP, that a new constraint does not always force a refinement, counts versus relations in (2,3,6) and (2,3,7), proof levels, and reproduction before and after publication, with `--rapido` and `--limite`.
- `reproducir_todo.py`: integrity and every verifier in a temporary copy; byte-identical results.
- English translation of the main document and a `READ_FIRST.en.md` guide.

## Beyond Yang–Mills complement — 2026-10-27

- Added the Spanish and English article in Markdown and PDF, plus seven PR-01 to PR-07 packages.
- Added an independent R-02 check, reference results, and a SHA-256 manifest: 47 files verified.
- The complement is a draft for review and explicitly leaves the mass gap open.

## Organized edition — 2026-10-24

- Browsable addition of the dated package: 1,047 files checked against its SHA-256 manifest.
- Public manuscript, rhythm and gravity supplement, integrated thread, realizations, research branches, laboratories, and historical archive.
- English guide and principal texts; the 0.1.0 conceptual edition remains available.

## 0.1.0-editorial — 2026-09-29

- Preservation of 79 received files and navigable extraction of three ZIP members.
- Synthesis and ten conceptual chapters.
- Glossary, notation, lineage, and a register of 26 results.
- Separation of historical corrections, nine editorial observations, and eight open issues.
- Complete catalog and integrity manifest.
- New examples and checks identified as editorial work.
- Initial Git repository and portable bundle.
- English translations of the 25 editorial documents; the original sources remain unchanged.
- Publication on GitHub and preservation of original bytes in Windows checkouts.

This numbering describes the editorial work. It does not replace the program's v0.xx versions or MF identifiers.
