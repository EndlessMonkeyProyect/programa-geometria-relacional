#!/usr/bin/env python3
"""Puente CME <-> P/NP, versión revisada del 28 de octubre de 2026.

Conserva los siete controles del suplemento recibido (P1-P7) y los etiqueta:
  - «control»: puede fallar si el enunciado fuera falso;
  - «ilustración»: es verdadero por construcción y sólo muestra una idea.

Añade siete controles nuevos (C1-C7). Cada uno toma un ejemplo del cubo de
espejos y lo lee como imagen tangible de una pieza del problema:
  C1  cierra / se repite / se abre: crecimiento finito, polinómico, exponencial
  C2  plegar por la simetría del cubo ahorra a lo sumo el tamaño del grupo
  C3  en dos colores la arista es un espejo; en tres, no
  C4  las únicas operaciones que cierran las relaciones de 3 colores
  C5  el cubo es bipartito y sus dos clases son los dos tetraedros de O19
  C6  el diamante es un espejo local, y su cierre depende del recinto
  C7  la paridad del cubo: un cierre global que el álgebra hace barato

Todo es exacto y finito; sólo usa la biblioteca estándar.
Ningún control infiere una cota de complejidad universal ni decide P frente a NP.

Uso:  python3 puente_cme_pnp_revisado.py
Escribe resultados_puente_revisado.json junto a este archivo.
"""
import itertools
import json
import math
from fractions import Fraction as F
from pathlib import Path


# ---------------------------------------------------------------------------
# Utilidades del suplemento recibido (sin cambios de significado)
# ---------------------------------------------------------------------------

def rho(x, L):
    """Firma plegada de la órbita generada por dos espejos paralelos en 0 y L."""
    x, L = F(x), F(L)
    assert L > 0
    r = x % (2 * L)
    return min(r, 2 * L - r)


def canonical_colors(seq):
    """Renombra colores por orden de aparición: representante de la órbita S3."""
    renaming = {}
    return tuple(renaming.setdefault(x, len(renaming)) for x in seq)


def count_colorings(n, edges, q=3):
    return sum(all(x[a] != x[b] for a, b in edges)
               for x in itertools.product(range(q), repeat=n))


def colorings(n, edges, q=3):
    return [x for x in itertools.product(range(q), repeat=n)
            if all(x[a] != x[b] for a, b in edges)]


def pairs_projection(states, i, j):
    return {(row[i], row[j]) for row in states}


# ---------------------------------------------------------------------------
# P1-P7: controles del suplemento recibido, etiquetados
# ---------------------------------------------------------------------------

def controles_recibidos():
    r = {}
    x, y = F(1, 4), F(7, 4)

    # P1 [control] Correr la pared de L=1 a L=3/2 separa dos puntos que la firma
    # antigua identificaba (F-PN-CME-1).
    assert rho(x, 1) == rho(y, 1) == F(1, 4)
    assert rho(x, F(3, 2)) == F(1, 4)
    assert rho(y, F(3, 2)) == F(5, 4)
    r['P1_pared_movil'] = {
        'tipo': 'control',
        'x': str(x), 'y': str(y), 'firma_L1': str(rho(x, 1)),
        'firmas_L3_2': [str(rho(x, F(3, 2))), str(rho(y, F(3, 2)))],
        'lectura': 'novedad contextual: la firma antigua deja de ser suficiente'}

    # P2 [control] Un desplazamiento que no es simetría no desciende al cociente;
    # la reflexión en la pared sí conserva la firma (F-PN-CME-2).
    t = F(1, 4)
    assert rho(x + t, 1) != rho(y + t, 1)
    muestras = [F(k, 8) for k in range(-40, 41)]
    assert all(rho(2 - a, 1) == rho(a, 1) for a in muestras)
    r['P2_factorizacion_dinamica'] = {
        'tipo': 'control',
        'desplazamiento': str(t), 'nueva_firma_x': str(rho(x + t, 1)),
        'nueva_firma_y': str(rho(y + t, 1)),
        'reflexion_en_pared_conserva_firma_en_casos': len(muestras)}

    # P3 [control + ilustración] Órbitas de S3 sobre asignaciones de k posiciones.
    vals = {n: len({canonical_colors(tup) for tup in itertools.product(range(3), repeat=n)})
            for n in range(1, 9)}
    stirling = {n: sum(_stirling2(n, j) for j in range(1, 4)) for n in range(1, 9)}
    assert vals == stirling and vals[8] == 1094
    # La parte del «anclaje» es verdadera por construcción: ilustración.
    assert canonical_colors((0,)) == canonical_colors((1,))
    r['P3_orbitas_S3'] = {
        'tipo': 'control (conteo de órbitas = suma de Stirling); el anclaje es ilustración',
        'clases_por_longitud': vals, 'etiquetados_n8': 3 ** 8, 'canon_n8': vals[8],
        'ahorro_n8': round(3 ** 8 / vals[8], 4)}

    # P4 [control] E25: paridades opuestas, mismas proyecciones por pares, intersección vacía.
    states = list(itertools.product((0, 1), repeat=3))
    E = {z for z in states if sum(z) % 2 == 0}
    O = {z for z in states if sum(z) % 2 == 1}
    assert len(E) == len(O) == 4 and not E & O
    assert all(pairs_projection(E, i, j) == pairs_projection(O, i, j)
               for i, j in itertools.combinations(range(3), 2))
    r['P4_paridad_ternaria'] = {
        'tipo': 'control', 'mismo_tamano': 4, 'marginales_pares_iguales': True,
        'interseccion_vacia': True}

    # P5 [control] E26: el diamante obliga a la igualdad de sus puntas en tres colores.
    edges = {(0, 1), (0, 2), (0, 3), (1, 2), (1, 3)}
    assert count_colorings(4, edges) == 6
    assert count_colorings(4, edges | {(2, 3)}) == 0
    r['P5_diamante'] = {
        'tipo': 'control', 'coloraciones_antes': 6, 'coloraciones_con_arista_uv': 0,
        'contexto': 'tres colores sin anclajes'}

    # P6 Mismo cardinal, respuestas distintas a una pregunta nueva.
    trip = list(itertools.product(range(3), repeat=3))
    A = {z for z in trip if z[0] != z[1]}
    D = {z for z in trip if z[1] != z[2]}
    K = {z for z in trip if z[0] != z[1]}          # el K recibido coincide con A
    assert len(A) == len(D) == 18 and len(A & K) == 18 and len(D & K) == 12
    K2 = {z for z in trip if z[0] == z[1]}         # pregunta nueva distinta de A y de D
    assert K2 != A and K2 != D
    assert len(A & K2) == 0 and len(D & K2) == 6
    r['P6_mismo_cardinal_distinto_contexto'] = {
        'tipo': 'ilustración con K = A (caso degenerado); control con K2 = {a = b}',
        'recibido': {'ambos_tamano': 18, 'A_con_K': 18, 'D_con_K': 12},
        'no_degenerado': {'pregunta': '¿a y b iguales?', 'A_con_K2': 0, 'D_con_K2': 6}}

    # P7 [ilustración] h/N = ph/pN es una identidad: conserva el valor y nada más.
    n, p, h = F(6), F(5), F(2)
    assert (h / n) == (p * h / (p * n))
    r['P7_normalizador'] = {
        'tipo': 'ilustración', 'antes': '2/6', 'despues': '10/30', 'valor_conservado': True,
        'lectura': 'la normalización aritmética no dice nada sobre costo de cómputo'}
    return r


def _stirling2(n, k):
    if n == k == 0:
        return 1
    if n == 0 or k == 0:
        return 0
    return k * _stirling2(n - 1, k) + _stirling2(n - 1, k - 1)


# ---------------------------------------------------------------------------
# C1: cierra / se repite / se abre  (CME-001, CME-002)
# ---------------------------------------------------------------------------
# Representación geométrica exacta de los grupos de triángulo (2,3,k). Con base
# en las normales, cada reflexión tiene entradas 2cos(pi/m) en Z[c], c = 2cos(pi/k).
# Se trabaja en Z[c]/(p(c)) con enteros exactos.

POLINOMIO_MINIMO = {   # p(c) = 0, coeficientes de mayor a menor grado, mónico
    4: (1, 0, -2),          # c = raíz de 2
    5: (1, -1, -1),         # c = razón áurea
    6: (1, 0, -3),          # c = raíz de 3
    7: (1, -1, -2, 1),      # c = 2cos(pi/7)
}


class Anillo:
    """Z[c] módulo el polinomio mínimo de c = 2cos(pi/k)."""

    def __init__(self, k):
        self.p = POLINOMIO_MINIMO[k]
        self.d = len(self.p) - 1
        c = 2 * math.cos(math.pi / k)
        assert abs(sum(a * c ** (self.d - i) for i, a in enumerate(self.p))) < 1e-12

    def cero(self):
        return (0,) * self.d

    def entero(self, n):
        return (n,) + (0,) * (self.d - 1)

    def c(self):
        return (0, 1) + (0,) * (self.d - 2)

    def suma(self, a, b):
        return tuple(x + y for x, y in zip(a, b))

    def producto(self, a, b):
        prod = [0] * (2 * self.d - 1)
        for i, x in enumerate(a):
            if x:
                for j, y in enumerate(b):
                    prod[i + j] += x * y
        # c^d = -(p1 c^(d-1) + ... + pd)
        for grado in range(len(prod) - 1, self.d - 1, -1):
            coef = prod[grado]
            if coef:
                prod[grado] = 0
                for i in range(1, self.d + 1):
                    prod[grado - i] -= coef * self.p[i]
        return tuple(prod[:self.d])


def _reflexiones_triangulo(k):
    """Reflexiones s1, s2, s3 con m12 = 2, m23 = 3, m13 = k."""
    R = Anillo(k)
    dos_cos = {2: R.cero(), 3: R.entero(1), k: R.c()}   # 2cos(pi/m)
    m = {(0, 1): 2, (1, 2): 3, (0, 2): k}
    gens = []
    for i in range(3):
        M = [[R.entero(1) if r == col else R.cero() for col in range(3)] for r in range(3)]
        # s_i(e_j) = e_j + 2cos(pi/m_ij) e_i ;  s_i(e_i) = -e_i
        for j in range(3):
            if j == i:
                M[i][i] = R.entero(-1)
            else:
                M[i][j] = dos_cos[m[tuple(sorted((i, j)))]]
        gens.append(tuple(tuple(fila) for fila in M))
    return R, gens


def _mult(R, A, B):
    return tuple(tuple(
        _sumar(R, [R.producto(A[i][t], B[t][j]) for t in range(3)]) for j in range(3))
        for i in range(3))


def _sumar(R, xs):
    total = R.cero()
    for x in xs:
        total = R.suma(total, x)
    return total


def _orden(R, A, tope=20):
    ident = tuple(tuple(R.entero(1) if i == j else R.cero() for j in range(3)) for i in range(3))
    P = A
    for n in range(1, tope + 1):
        if P == ident:
            return n
        P = _mult(R, P, A)
    return None


def esferas_triangulo(k, L):
    """Número de orientaciones nuevas en cada longitud 0..L (exacto)."""
    R, gens = _reflexiones_triangulo(k)
    ident = tuple(tuple(R.entero(1) if i == j else R.cero() for j in range(3)) for i in range(3))
    vistos = {ident}
    frontera = [ident]
    esferas = [1]
    for _ in range(L):
        nueva = []
        for g in frontera:
            for s in gens:
                h = _mult(R, g, s)
                if h not in vistos:
                    vistos.add(h)
                    nueva.append(h)
        esferas.append(len(nueva))
        frontera = nueva
    ordenes_pares = {
        'm12': _orden(R, _mult(R, gens[0], gens[1])),
        'm23': _orden(R, _mult(R, gens[1], gens[2])),
        'm13': _orden(R, _mult(R, gens[0], gens[2])),
    }
    return esferas, ordenes_pares


# Valores de CME-002 (calculados allí por ángulos y por identidades, Todd-Coxeter
# y serie de Steinberg). Aquí se recalculan por un tercer camino independiente.
CME002_ESFERAS = {
    5: [1, 3, 5, 7, 9, 11, 12, 12, 12, 12, 11, 9, 7, 5, 3, 1, 0],
    6: [1, 3, 5, 7, 9, 12, 15, 17, 19, 21, 24, 27, 29, 31, 33, 36, 39],
    7: [1, 3, 5, 7, 9, 12, 16, 20, 24, 28, 33, 40, 48, 57, 67, 78, 92],
}
LEHMER = 1.176280818259917


def c1_tres_regimenes():
    L = 16
    res = {}
    for k in (4, 5, 6, 7):
        esferas, pares = esferas_triangulo(k, L)
        # Cada par de espejos cierra en los cuatro casos: lo local siempre cierra.
        assert pares == {'m12': 2, 'm23': 3, 'm13': k}, (k, pares)
        res[k] = {'esferas': esferas, 'bola': list(itertools.accumulate(esferas)),
                  'ordenes_de_cada_par': pares}
    for k in (5, 6, 7):
        assert res[k]['esferas'] == CME002_ESFERAS[k], k
    # cierra: finito
    assert sum(res[4]['esferas']) == 48 and res[4]['esferas'][-1] == 0
    assert sum(res[5]['esferas']) == 120 and res[5]['esferas'][15] == 1
    # se repite: cada 5 pasos aparecen 12 nuevas más -> esfera lineal, bola cuadrática
    s6 = res[6]['esferas']
    assert all(s6[n] - s6[n - 5] == 12 for n in range(10, L + 1))
    # se abre: la razón entre esferas sucesivas tiende al número de Lehmer
    s7 = res[7]['esferas']
    razones = [s7[n] / s7[n - 1] for n in range(12, L + 1)]
    assert all(1.15 < q < 1.22 for q in razones)
    # Lo local no decide el régimen: hasta L = 5 las tres esferas coinciden
    # salvo la del recinto que cierra, que se separa en L = 5.
    assert s6[:6] == s7[:6] and s6[6] != s7[6]
    assert res[5]['esferas'][:5] == s6[:5] and res[5]['esferas'][5] != s6[5]
    return {
        'regimenes': {
            '(2,3,4)': 'cierra en 48 (cubo)',
            '(2,3,5)': 'cierra en 120',
            '(2,3,6)': 'se repite: +12 nuevas cada 5 pasos (esfera lineal, bola cuadrática)',
            '(2,3,7)': 'se abre: razón de esferas -> número de Lehmer',
        },
        'esferas': {f'(2,3,{k})': res[k]['esferas'] for k in res},
        'bolas': {f'(2,3,{k})': res[k]['bola'] for k in res},
        'ordenes_de_cada_par': {f'(2,3,{k})': res[k]['ordenes_de_cada_par'] for k in res},
        'razones_2_3_7_L12_a_L16': [round(q, 6) for q in razones],
        'numero_de_Lehmer': LEHMER,
        'profundidad_acotada_no_decide': 'las esferas de (2,3,6) y (2,3,7) coinciden hasta L=5 y se separan en L=6 '
                                         '(15 frente a 16). Sus relaciones difieren en un par (orden 6 frente a 7): '
                                         'esa relación tiene longitud 12 frente a 14 y no toca los recuentos hasta L=5',
        'coincide_con_CME002': True,
        'lectura': 'constante / polinómico / exponencial: en grupos de reflexión es un teorema; leído como '
                   'clases de costo de un algoritmo es una analogía orientadora. El régimen lo decide una '
                   'relación global, no la finitud de cada par',
    }


# ---------------------------------------------------------------------------
# Cubo: vértices, aristas y grupo de simetrías B3 (48)
# ---------------------------------------------------------------------------

VERTICES = list(itertools.product((0, 1), repeat=3))
IDX = {v: i for i, v in enumerate(VERTICES)}
ARISTAS_Q3 = [(IDX[u], IDX[v]) for u, v in itertools.combinations(VERTICES, 2)
              if sum(a != b for a, b in zip(u, v)) == 1]


def grupo_B3():
    perms = set()
    for orden in itertools.permutations(range(3)):
        for flips in itertools.product((0, 1), repeat=3):
            img = tuple(IDX[tuple(v[orden[i]] ^ flips[i] for i in range(3))] for v in VERTICES)
            perms.add(img)
    return sorted(perms)


def _ciclos(perm):
    vistos, c = set(), 0
    for i in range(len(perm)):
        if i not in vistos:
            c += 1
            j = i
            while j not in vistos:
                vistos.add(j)
                j = perm[j]
    return c


# ---------------------------------------------------------------------------
# C2: plegar por la simetría del cubo ahorra a lo sumo |G|
# ---------------------------------------------------------------------------

def c2_plegado_por_simetria():
    B3 = grupo_B3()
    assert len(B3) == 48
    # B3 conserva las aristas del cubo: son simetrías del grafo
    E = {frozenset(e) for e in ARISTAS_Q3}
    assert all({frozenset((g[a], g[b])) for a, b in ARISTAS_Q3} == E for g in B3)
    S3 = list(itertools.permutations(range(3)))
    todas = list(itertools.product(range(3), repeat=8))
    propias = [x for x in todas if all(x[a] != x[b] for a, b in ARISTAS_Q3)]

    def orbitas(X, con_colores):
        canon = set()
        for x in X:
            imgs = []
            for g in B3:
                y = [0] * 8
                for i in range(8):
                    y[g[i]] = x[i]
                if con_colores:
                    for s in S3:
                        imgs.append(tuple(s[c] for c in y))
                else:
                    imgs.append(tuple(y))
            canon.add(min(imgs))
        return len(canon)

    res = {}
    for nombre, X in (('todas_las_asignaciones', todas), ('coloraciones_propias_del_cubo', propias)):
        for con_colores, G in ((False, 48), (True, 288)):
            o = orbitas(X, con_colores)
            assert o * G >= len(X)                 # cota de órbitas: |X/G| >= |X|/|G|
            res[f'{nombre}__G{G}'] = {'tamano': len(X), 'orbitas': o,
                                       'ahorro': round(len(X) / o, 4), 'cota_del_ahorro': G}
    # Burnside como segundo camino para B3 sobre todas las asignaciones
    burnside = F(sum(3 ** _ciclos(g) for g in B3), 48)
    assert burnside == res['todas_las_asignaciones__G48']['orbitas']
    return {
        'grupo_del_cubo': 48, 'con_permutacion_de_colores': 288,
        'casos': res, 'burnside_coincide': True,
        'lectura': 'cada órbita tiene a lo sumo |G| elementos; plegar por un grupo fijo ahorra un factor '
                   'constante, nunca convierte un crecimiento exponencial en polinómico',
    }


# ---------------------------------------------------------------------------
# C3: en dos colores la arista es un espejo; en tres, no
# ---------------------------------------------------------------------------

def _componer(R, S):
    return {(a, c) for a, b in R for b2, c in S if b == b2}


def c3_arista_espejo():
    res = {}
    for q in (2, 3):
        NE = {(a, b) for a in range(q) for b in range(q) if a != b}
        EQ = {(a, a) for a in range(q)}
        funcion = all(sum(1 for (a, b) in NE if a == x) == 1 for x in range(q))
        comp = _componer(NE, NE)
        res[q] = {'es_funcion_involutiva': funcion, 'compuesta_dos_veces': sorted(comp)}
        # Recorrer un ciclo: la relación que impone el ciclo sobre su vértice inicial
        ciclos = {}
        for n in range(3, 9):
            R = EQ
            for _ in range(n):
                R = _componer(R, NE)
            ciclos[n] = len(R & EQ) > 0   # ¿puede volver al mismo color?
        res[q]['ciclo_cierra_por_longitud'] = ciclos
    assert res[2]['es_funcion_involutiva'] and set(res[2]['compuesta_dos_veces']) == {(0, 0), (1, 1)}
    assert all(res[2]['ciclo_cierra_por_longitud'][n] == (n % 2 == 0) for n in range(3, 9))
    assert not res[3]['es_funcion_involutiva'] and len(res[3]['compuesta_dos_veces']) == 9
    assert all(res[3]['ciclo_cierra_por_longitud'][n] for n in range(3, 9))
    return {
        'dos_colores': {
            'arista': 'x -> 1 - x: un espejo (involución)',
            'dos_aristas': 'igualdad: los espejos componen y cierran (grupo Z2)',
            'ciclo': 'cierra si y sólo si es par: la paridad del bit',
            'ciclo_cierra_por_longitud': res[2]['ciclo_cierra_por_longitud']},
        'tres_colores': {
            'arista': 'no es función: cada color tiene dos vecinos posibles',
            'dos_aristas': 'las 9 parejas: componer olvida todo',
            'ciclo_cierra_por_longitud': res[3]['ciclo_cierra_por_longitud']},
        'lectura': 'con dos colores el problema se pliega por paridad (está en P); con tres, la arista '
                   'deja de ser espejo y la información no se transporta a lo largo de los caminos',
    }


# ---------------------------------------------------------------------------
# C4: las operaciones que cierran las relaciones (polimorfismos ternarios)
# ---------------------------------------------------------------------------

def _homomorfismos_potencia(q):
    """Todas las f: {0..q-1}^3 -> {0..q-1} que conservan la relación «distinto»."""
    dominio = list(itertools.product(range(q), repeat=3))
    vecinos = {x: [y for y in dominio if all(a != b for a, b in zip(x, y))] for x in dominio}
    orden = sorted(dominio, key=lambda x: -len(vecinos[x]))
    f, sols = {}, []

    def rec(i):
        if i == len(orden):
            sols.append(dict(f))
            return
        x = orden[i]
        usados = {f[y] for y in vecinos[x] if y in f}
        for c in range(q):
            if c not in usados:
                f[x] = c
                rec(i + 1)
                del f[x]
    rec(0)
    return sols


def _es_esencialmente_unaria(f, q):
    for i in range(3):
        pi = {}
        ok = True
        for x, v in f.items():
            if pi.setdefault(x[i], v) != v:
                ok = False
                break
        if ok and sorted(pi.values()) == list(range(q)):
            return True
    return False


def _es_wnu(f, q):
    return all(f[(y, x, x)] == f[(x, y, x)] == f[(x, x, y)] for x in range(q) for y in range(q))


def c4_cierres_de_las_relaciones():
    p2 = _homomorfismos_potencia(2)
    p3 = _homomorfismos_potencia(3)
    mayoria = {x: int(sum(x) >= 2) for x in itertools.product((0, 1), repeat=3)}
    minoria = {x: sum(x) % 2 for x in itertools.product((0, 1), repeat=3)}
    assert len(p2) == 16 and mayoria in p2 and minoria in p2
    assert sum(_es_wnu(f, 2) for f in p2) >= 2
    assert len(p3) == 18                                   # Greenwell-Lovász: 3 coordenadas x 3!
    assert all(_es_esencialmente_unaria(f, 3) for f in p3)
    assert not any(_es_wnu(f, 3) for f in p3)
    return {
        'dos_colores': {'operaciones_ternarias_que_conservan_distinto': 16,
                        'incluye_mayoria': True, 'incluye_paridad_x+y+z': True,
                        'con_simetria_debil_WNU': sum(_es_wnu(f, 2) for f in p2)},
        'tres_colores': {'operaciones_ternarias_que_conservan_distinto': 18,
                         'todas_copian_una_coordenada_y_renombran_colores': True,
                         'con_simetria_debil_WNU': 0},
        'lectura': 'en tres colores los 18 polimorfismos ternarios de la plantilla K3 son proyecciones '
                   'seguidas de permutaciones de colores (esencialmente unarios) y ninguno es WNU; su única '
                   'parte no trivial es S3, que sólo pliega por 6 (P3, C2). Por la dicotomía de CSP (Bulatov; '
                   'Zhuk), en el núcleo de una plantilla finita tener o no un polimorfismo WNU separa P de '
                   'NP-completo. Esto no descarta algoritmos construidos de otra manera ni cierres '
                   'contextuales de una instancia (el diamante, C6); ser NP-completo no prueba que no exista '
                   'un algoritmo polinómico: eso sería P distinto de NP',
    }


# ---------------------------------------------------------------------------
# C5: el cubo es bipartito; sus dos clases son los dos tetraedros
# ---------------------------------------------------------------------------

def _bipartito(n, aristas):
    vec = {i: [] for i in range(n)}
    for a, b in aristas:
        vec[a].append(b)
        vec[b].append(a)
    color = {}
    for s in range(n):
        if s in color:
            continue
        color[s] = 0
        pila = [s]
        while pila:
            u = pila.pop()
            for w in vec[u]:
                if w not in color:
                    color[w] = 1 - color[u]
                    pila.append(w)
                elif color[w] == color[u]:
                    return None
    return color


def c5_cubo_bipartito():
    col = _bipartito(8, ARISTAS_Q3)
    assert col is not None
    clases = [sorted(VERTICES[i] for i in range(8) if col[i] == c) for c in (0, 1)]
    paridad = [sorted(v for v in VERTICES if sum(v) % 2 == p) for p in (0, 1)]
    assert sorted(clases) == sorted(paridad)
    for clase in clases:                         # cada clase: tetraedro regular de lado raíz de 2
        d2 = {sum((a - b) ** 2 for a, b in zip(u, v)) for u, v in itertools.combinations(clase, 2)}
        assert d2 == {2}
    K4 = list(itertools.combinations(range(4), 2))
    assert _bipartito(4, K4) is None
    assert count_colorings(4, K4, 3) == 0 and count_colorings(4, K4, 4) == 24
    return {
        'cubo_Q3': {'bipartito': True, 'clases': [[''.join(map(str, v)) for v in c] for c in clases],
                    'cada_clase_es_un_tetraedro_regular': True},
        'tetraedro_K4': {'bipartito': False, 'coloraciones_con_3': 0, 'coloraciones_con_4': 24},
        'lectura': 'Hell y Nesetril (1990): colorear hacia un grafo H está en P si H es bipartito y es '
                   'NP-completo si no. Colorear «hacia el cubo» se pliega por paridad; «hacia el '
                   'triángulo o el tetraedro» no tiene ese pliegue',
    }


# ---------------------------------------------------------------------------
# C6: el diamante es un espejo local
# ---------------------------------------------------------------------------

def c6_diamante_espejo():
    a, b, u, v = 0, 1, 2, 3
    aristas = {(a, b), (a, u), (a, v), (b, u), (b, v)}
    sigma = {a: a, b: b, u: v, v: u}
    norm = lambda e: tuple(sorted(e))
    assert {norm((sigma[x], sigma[y])) for x, y in aristas} == {norm(e) for e in aristas}
    c3 = colorings(4, aristas, 3)
    c4 = colorings(4, aristas, 4)
    assert len(c3) == 6 and all(x[u] == x[v] for x in c3)
    assert len(c4) == 48 and sum(x[u] == x[v] for x in c4) == 24
    return {
        'espejo': 'intercambiar las puntas u, v fijando la arista compartida a-b es una simetría',
        'tres_colores': {'coloraciones': 6, 'puntas_iguales_en_todas': True},
        'cuatro_colores': {'coloraciones': 48, 'puntas_iguales': 24},
        'lectura': 'el cierre local (certificado E26) depende del recinto: con tres colores las puntas '
                   'son la misma imagen; con cuatro, no',
    }


# ---------------------------------------------------------------------------
# C7: la paridad del cubo, un cierre global barato
# ---------------------------------------------------------------------------

def _gauss_gf2(filas, ncols):
    """Eliminación de Gauss sobre GF(2). filas: enteros con bit ncols = término independiente."""
    filas = list(filas)
    rango = 0
    for col in range(ncols):
        piv = next((i for i in range(rango, len(filas)) if filas[i] >> col & 1), None)
        if piv is None:
            continue
        filas[rango], filas[piv] = filas[piv], filas[rango]
        for i in range(len(filas)):
            if i != rango and filas[i] >> col & 1:
                filas[i] ^= filas[rango]
        rango += 1
    consistente = not any(f == 1 << ncols for f in filas)
    return consistente, rango


def c7_paridad_del_cubo():
    m = len(ARISTAS_Q3)
    assert m == 12
    mascaras = [sum(1 << e for e, (p, q) in enumerate(ARISTAS_Q3) if i in (p, q)) for i in range(8)]
    # Fuerza bruta: síndrome de cada una de las 2^12 asignaciones de aristas
    cuenta = {}
    for asign in range(1 << m):
        s = tuple(bin(asign & mk).count('1') & 1 for mk in mascaras)
        cuenta[s] = cuenta.get(s, 0) + 1
    for carga in itertools.product((0, 1), repeat=8):
        filas = [mascaras[i] | (carga[i] << m) for i in range(8)]
        consistente, rango = _gauss_gf2(filas, m)
        soluciones = cuenta.get(carga, 0)
        assert consistente == (sum(carga) % 2 == 0) == (soluciones > 0)
        assert rango == 7
        if consistente:
            assert soluciones == 2 ** (m - rango) == 32
    return {
        'sistema': 'una variable por arista del cubo; en cada vértice, la suma módulo 2 de sus aristas = carga',
        'cargas_probadas': 256,
        'resoluble_si_y_solo_si_la_carga_total_es_par': True,
        'rango': 7, 'soluciones_cuando_es_resoluble': 32,
        'dimension_del_espacio_de_ciclos': 12 - 8 + 1,
        'lectura': 'la paridad no se ve por pares (P4), pero la eliminación de Gauss la cierra de una vez. '
                   'Es el ejemplo de una representación que escapa al motor de tablas: la resolución '
                   'necesita tamaño exponencial para estas fórmulas en grafos expansores (Urquhart, 1987)',
    }


# ---------------------------------------------------------------------------

def verify():
    resultado = {
        'version': 'revisada 2026-10-28',
        'controles_recibidos_P1_P7': controles_recibidos(),
        'imagen_del_cubo_C1_C7': {
            'C1_cierra_se_repite_se_abre': c1_tres_regimenes(),
            'C2_plegado_por_simetria': c2_plegado_por_simetria(),
            'C3_arista_espejo': c3_arista_espejo(),
            'C4_cierres_de_las_relaciones': c4_cierres_de_las_relaciones(),
            'C5_cubo_bipartito': c5_cubo_bipartito(),
            'C6_diamante_espejo': c6_diamante_espejo(),
            'C7_paridad_del_cubo': c7_paridad_del_cubo(),
        },
        'conclusion': 'Todos los controles son exactos y finitos; no infieren complejidad universal '
                      'ni deciden P frente a NP.',
    }
    return resultado


if __name__ == '__main__':
    res = verify()
    out = Path(__file__).resolve().parent / 'resultados_puente_revisado.json'
    out.write_text(json.dumps(res, ensure_ascii=False, indent=2, sort_keys=True) + '\n', encoding='utf-8')
    print('PUENTE CME-PNP (revisado): PASS — 7 controles recibidos (P1-P7) y 7 de la imagen del cubo (C1-C7)')
    print('Resultados:', out)
