# P versus NP and the mirror cube — complement of 28 October 2026

**Relational Geometry Program · Le Matt Ansatz Di Ego**

This complement integrates the revised update of the P/NP branch with the mirror-cube laboratory. It reads the cube examples as a **tangible image** of the problem: an enclosure that closes, repeats or opens depending on how its mirrors relate. It is added to the 24-October edition without modifying anything in it. [Leer en español](LEER_PRIMERO.md).

**Status.** It does not prove P = NP or P ≠ NP. It gathers what is established under contract, the falsifiers and what remains open. Correspondences between the cube and complexity that are known theorems are cited as such; the others are marked as image.

## Contents

| Path | What it contains |
|---|---|
| [`ACTUALIZACION_PNP_CME_2026-10-28_revisada.en.md`](ACTUALIZACION_PNP_CME_2026-10-28_revisada.en.md) | The main document in English. Section 3 is the image of the cube |
| [`ACTUALIZACION_PNP_CME_2026-10-28_revisada.md`](ACTUALIZACION_PNP_CME_2026-10-28_revisada.md) | Spanish original, the reference version |
| [`MATRIZ_DE_RESULTADOS_revisada.md`](MATRIZ_DE_RESULTADOS_revisada.md) | Status and source of every claim, including C1–C7 (Spanish) |
| [`GRAFO_DE_RELACIONES_revisado.md`](GRAFO_DE_RELACIONES_revisado.md) | Genealogy of results with the cube-image layer (Spanish) |
| [`REVISION_2026-10-28.md`](REVISION_2026-10-28.md) | What was checked, corrected and added, and where the integration departed from the instructions (Spanish) |
| [`laboratorio/`](laboratorio/puente_cme_pnp_revisado.py) | Revised bridge: the 7 received controls (P1–P7), labeled, and 7 new ones of the cube image (C1–C7) |
| [`reproducir_todo.py`](reproducir_todo.py) | Integrity, every verifier in a temporary copy, byte-for-byte comparison |
| [`verificacion/`](verificacion/registro_reproduccion.json) | Reproduction record of this delivery and [GitHub API query on issue #1](verificacion/issue1_github_api.json) |
| [`recibido/`](recibido/SUPLEMENTO_PNP_CME_2026-10-28/README.md) | The supplement as received, unchanged, except the 49 frozen sources, which are identical to those of the 24-Oct edition ([list](recibido/DUPLICADOS_RETIRADOS.csv)) |

## The image of the cube, in short

| In the cube | In 3-coloring | Status |
|---|---|---|
| An enclosure **closes** (48, 120), **repeats** (+12 every 5 steps) or **opens** (×1.176 per step) | Constant, polynomial or exponential growth of what an algorithm must keep | Known theorem for groups; orienting analogy for algorithms |
| Every pair of mirrors closes, yet the whole opens; (2,3,6) and (2,3,7) have the same counts up to depth 5, though they differ in one pair (order 6 vs 7) | What is seen at bounded depth does not decide the global answer | Known; exact checks |
| The tetrahedron that exchanges its references closes (24, 48); the one that brings new references opens (2·3ᴸ − 1) | Folding by symmetry saves at most \|G\|; novelty opens | Known; checked with the cube's group |
| With two colors an edge is a mirror (x ↦ 1 − x) and a cycle closes iff it is even; with three it is not: the template's 18 ternary polymorphisms are projections followed by color permutations, with no WNU | 2-coloring is in P; 3-coloring is NP-complete (Hell–Nešetřil; CSP dichotomy) | Known theorems; exact checks |
| The parity of the cube closes with one Gaussian elimination | Algebra escapes resolution on parity formulas (Urquhart) | Known |

In the image, P versus NP asks: **is there a polynomial fold for the triangle that does not come from any polymorphism of its template?** NP-completeness alone does not rule one out.

## Reproduction

**Until the complement is on `main`**, apply it to a copy of the repository, which already holds the `2026-10-24/` edition:

    git clone https://github.com/EndlessMonkeyProyect/programa-geometria-relacional.git
    cd programa-geometria-relacional
    git am Complemento_2026-10-28_PNP_Cubo_de_Espejos_r3.patch   # or unzip the ZIP in this folder
    cd 2026-10-28_pnp_cubo_de_espejos

**Once published**, cloning the repository and entering `2026-10-28_pnp_cubo_de_espejos/` is enough. In both cases, then:

    pip install -r requirements.txt          # numpy and sympy; only CME-001, CME-002 and the bit rule use them
    python3 reproducir_todo.py               # every verifier
    python3 reproducir_todo.py --rapido      # skips CME-001 and CME-002, the heaviest
    python3 reproducir_todo.py --limite 120  # stops each verifier after 120 s
    python3 reproducir_todo.py --registrar   # also rewrites verificacion/registro_reproduccion.json

**The complement runs inside the full repository.** The script reads the sibling edition `2026-10-24/`; the complement's ZIP alone is not enough. The full run took about 35 seconds on the machine recorded in `verificacion/`, and can take much longer elsewhere: CME-001 enumerates over a million orientations. All verifiers pass, and every regenerated result is byte-identical to the stored one. Timings are data about the run, not evidence of complexity.

**Exit codes.** 0 if everything passes and nothing was skipped; 1 if something fails; 2 if something was left unchecked. With `--rapido` the summary reads INCOMPLETO and the code is 2 even when everything that ran passes, because the two heavy verifiers are skipped on purpose.
