# PGR — Actualización aditiva de P versus NP y la caja de espejos

**Programa de Geometría Relacional · Autoría del hilo: Le Matt Ansatz Di Ego**  
**Corte documental:** 28 de octubre de 2026 · **versión revisada**  
**Naturaleza:** reconstrucción crítica e integración aditiva; **no sustituye los originales ni afirma resolver P vs NP**.

> Esta es la versión revisada del suplemento recibido, que se conserva intacto en [`recibido/`](recibido/SUPLEMENTO_PNP_CME_2026-10-28/ACTUALIZACION_PNP_CME_2026-10-28.md). La revisión añade la sección 3, *El cubo como imagen tangible del problema*, y corrige ocho puntos; dos revisiones cruzadas asistidas por IA agregaron diez precisiones más. Cada cambio está registrado en [`REVISION_2026-10-28.md`](REVISION_2026-10-28.md).

## 0. Alcance, estados y jerarquía del programa

Orden de exposición: **lenguaje del pensamiento → ontología → definiciones de observación → teoremas → experimentos → hipótesis y falsadores → próximas operaciones**. Revisión sobre la edición ordenada del 24-oct, la Imagen Total 3.9, las contribuciones CME-001/002/003, O19–O22, O59–O60, N1, MF-27/52/86/97/99/106, CR-3/6, E25/26/28 y LAB-CONV v2, más discusiones conservadas y el repositorio público. El acceso a conversaciones históricas fue **indirecto por sus documentos de continuidad**; no se dispone de transcripciones íntegras de cada chat antiguo.

Marcas: **[O]** ontología, **[D]** definición, **[T]** derivado bajo hipótesis o teorema conocido, **[E]** ensayo reproducido o prueba computacional exacta y finita, **[I]** imagen: analogía orientadora, **[F]** falsador, **[C]** condicional, **[A]** abierto.

## 1. Lenguaje y nacimiento de la pregunta

[O] La unidad puede reflexionarse y construir distinciones dentro de la totalidad. La diferencia precede a medirla; la comparación acredita relaciones; un cierre suficiente permite volver a usar lo resuelto como una referencia y un nuevo vínculo puede distinguir clases anteriormente comunes. **La novedad refina el lenguaje** sin convertir en falsa una respuesta anterior para su pregunta original. El múltiplo que normalizó conserva la proporción de la representación; no por ello controla tiempo de cómputo o identidad física.

La frase rectora en la rama P/NP es: «Cada número nuevo que aparece es un nodo de caminos para llegar a él como soluciones donde convergen estructuras». La formulación posterior exigió distinguir **coincidencia de valor**, **equivalencia contextual** y **convergencia estructural certificada**. No todo número cardinal identifica por sí solo una clase suficiente.

## 2. Los espejos: qué se probó, qué se corrigió

### 2.1 CME-001 — cierre de orientaciones frente a posiciones [T/E]

Las partes lineales de los espejos ortogonales ideales producen ocho patrones de signo en tres coordenadas; el ortoesquema cúbico estudiado produce 48 orientaciones. La reflexión entre planos paralelos produce posiciones virtuales infinitas, aun cuando las orientaciones sean finitas. Por tanto, **«ocho orientaciones» no significa «ocho imágenes espaciales»**.

El tetraedro regular, reflejado en sus cuatro caras, **nunca cierra**: con a lo sumo L reflexiones alcanza exactamente 2·3ᴸ − 1 orientaciones. CME-001 lo registra como teorema conocido: Świerczkowski (1959) probó que no existe una cadena cerrada de tetraedros regulares, y Dekker (1959) y Mason (1972) mostraron que esas cuatro reflexiones generan el producto libre de cuatro grupos de orden dos. El ensayo lo reproduce hasta L = 12. Es imprescindible no identificar un cierre finito de orientaciones con un cierre espacial, óptico o computacional general.

### 2.2 O59 — órbita y firma plegada [T]

En una dimensión con paredes en 0 y L>0:

\[\mathcal O_L(p)=\{2nL\pm p:n\in\mathbb Z\},\quad \rho_L(x)=\operatorname{dist}(x,2L\mathbb Z).\]

Para el grupo generado por estas reflexiones, dos posiciones comparten órbita si y solo si comparten firma \(\rho_L\). Con tres ejes se componen tres firmas (con sus longitudes), cuando el contrato es separable. La firma es **suficiente para la pregunta de pertenencia a órbita**, no para una consulta arbitraria de posición, fase o historia. El número de imágenes es infinito; la representación de la clase no lo es.

### 2.3 CME-002 — tres regímenes, condición global [T/E/F]

En la familia triangular de grupos de reflexión \((2,3,k)\), la suma \(\tfrac12+\tfrac13+\tfrac1k\) es mayor que 1 para k=2..5, igual a 1 para k=6, y menor que 1 para k≥7. En el contrato correspondiente, esto clasifica grupo esférico finito, afín euclídeo e hiperbólico infinito, respectivamente. **«Sólo cierra hasta 5» vale para esta familia, no para todas las disposiciones:** el control \((2,2,k)\) es finito para cada k. La finitud de cada producto de dos generadores no prueba finitud del grupo generado por todos (control (2,3,7)). El origen de los ángulos \(\pi/2,\pi/3\) no fue demostrado desde una pared móvil sin hipótesis geométricas adicionales.

### 2.4 CME-003 — cuatro referencias y reflexión [T/E]

Cuatro vectores con coordenadas de paridad \((1,1,1),(1,-1,-1),(-1,1,-1),(-1,-1,1)\) en \(\mathbb R^3\) euclídeo. Los intercambios de pares se realizan por reflexiones con normales dadas por diferencias de vértices: su grupo es una representación de \(S_4\) de orden 24. Dos intercambios disjuntos producen producto de orden 2; dos con vértice compartido, orden 3 (ángulos agudos de planos \(\pi/2,\pi/3\)). Al agregar un cambio de signo coordenado, aparece extensión de orden 48 (tipo \(B_3\)), con productos de orden 4. **Ojo:** en el grupo de orden 24 hay elementos de orden 4 que son transformaciones de orientación inversa (rotorreflexiones, determinante −1); CME-003 los llama «giros» y conviene no llamarlos rotaciones. Los operadores originales usan métrica y cuatro referencias como premisas, no las derivan de la ontología.

En esta actualización se reejecutaron satisfactoriamente CME-001, CME-002, la regla del bit, CME-003, O59, O22, LAB-CONV v2 (laboratorio y control exhaustivo) y el escalado de la revisión del 24-oct. Cada verificador corre en una copia temporal y sus resultados regenerados son idénticos byte a byte a los guardados (ver `reproducir_todo.py` y `verificacion/`). La teoría de reflexiones utilizada es clásica; su integración ontológica es el aporte interpretativo del programa.

## 3. El cubo como imagen tangible del problema

[O] El cubo de espejos es el lugar donde la idea se ve. Antes que un algoritmo, ofrece una **imagen**: un recinto que cierra o se abre según cómo se relacionan sus espejos. Esta sección lee cada ejemplo del laboratorio como imagen de una pieza de la pregunta P frente a NP. De cada imagen se dice qué se ve en el cubo, a qué corresponde en 3-coloración y qué no dice. Cuando la correspondencia es un teorema se marca [T]; cuando es una analogía orientadora, [I]. Los controles C1–C7 son pruebas computacionales exactas y finitas: acreditan esos casos, no enunciados generales. Los controles C1–C7 están en [`laboratorio/puente_cme_pnp_revisado.py`](laboratorio/puente_cme_pnp_revisado.py).

### 3.1 Cierra, se repite, se abre [T/E]

**En el cubo** (CME-001, CME-002, C1). Contamos las orientaciones nuevas que aparecen en cada paso de reflexión.

| Recinto | Orientaciones nuevas por paso, L = 0, 1, 2, … | Régimen |
|---|---|---|
| (2,3,4), el cubo | 1, 3, 5, 7, 8, 8, 7, 5, 3, 1, 0 | **cierra** en 48 |
| (2,3,5) | 1, 3, 5, 7, 9, 11, 12, 12, 12, 12, 11, 9, 7, 5, 3, 1, 0 | **cierra** en 120 |
| (2,3,6) | 1, 3, 5, 7, 9, 12, 15, 17, 19, 21, 24, 27, … | **se repite**: 12 nuevas más cada 5 pasos |
| (2,3,7) | 1, 3, 5, 7, 9, 12, 16, 20, 24, 28, 33, 40, 48, 57, 67, 78, 92 | **se abre**: cada paso multiplica por ≈ 1,176 (número de Lehmer) |
| tetraedro regular | 1, 4, 12, 36, 108, … (acumulado 2·3ᴸ − 1) | **se abre** del todo |

C1 recalcula las cuatro primeras filas por un tercer camino exacto, independiente de los dos de CME-002, y coinciden.

**Correspondencia.** Los tres regímenes son las tres clases de crecimiento que distingue la complejidad: **constante, polinómico, exponencial**. En el recinto que se repite, lo acumulado crece como L²; en el que se abre, como 1,176ᴸ. [T] Para grupos de reflexión no hay término medio: un grupo de Coxeter es finito, o afín y de crecimiento polinómico, o de crecimiento exponencial (de la Harpe, 1987).

En 3-coloración lo que crece es el número de estados distintos que un procedimiento tiene que guardar. N1-A prueba que el motor de tablas recorre al menos 3^(tw+1) candidatos: en familias de ancho creciente, **se abre**. La revisión del 24-oct muestra algo más: en cuadrículas k×k, que son bipartitas y se resuelven con una búsqueda en anchura, el motor también se abre (de 22 a 107.005 evaluaciones entre k = 3 y k = 9). El motor cuenta imágenes en vez de plegarlas.

**La pregunta, en la imagen:** ¿toda familia de instancias de 3-coloración admite una representación cuyo recinto *se repita* en vez de *abrirse*?

**Lo que no dice.** El espacio de búsqueda de 3-coloración no es un grupo de Coxeter. La imagen da la forma de la pregunta, no una reducción.

### 3.2 Lo visto a profundidad acotada no decide el régimen [T/E]

**En el cubo** (CME-002, C1). En (2,3,7) cada par de espejos cierra: sus productos tienen orden 2, 3 y 7. Aun así, el recinto entero se abre. Lo que decide es la suma 1/2 + 1/3 + 1/7 frente a 1, que es una relación global. Además, las esferas de (2,3,6) y (2,3,7) son idénticas hasta L = 5 (1, 3, 5, 7, 9, 12) y se separan en L = 6 (15 frente a 16). Mirando hasta profundidad 5 no se distingue el recinto que se repite del que se abre.

**Correspondencia.** Es la misma lección de E25: dos relaciones de paridad tienen las mismas proyecciones por pares y su intersección es vacía. Y es la de LAB-CONV: decidir una igualdad global forzada es coNP-completo. El ensayo 3 de la secuencia convenida (§6) pide parejas de familias de grafos con estadísticas locales semejantes. El cubo da la plantilla de esa pareja, con una precisión. Lo que comparten (2,3,6) y (2,3,7) son los recuentos hasta profundidad 5 y el hecho de que cada par de espejos cierra. Sus relaciones completas difieren en un par, de orden 6 frente a 7; esa relación tiene longitud 12 frente a 14 y no toca los recuentos hasta L = 5. Mismos recuentos a profundidad acotada, distintas relaciones entre generadores, distinto régimen global.

### 3.3 El tetraedro dos veces: intercambiar no es traer [T/E]

**En el cubo** (CME-003 §7, CME-001, C2). La misma figura da dos cosas. Reflejado en sus caras, el tetraedro trae referencias nuevas y nunca cierra (2·3ᴸ − 1). Intercambiando sus referencias, que son sus espejos de simetría, cierra en 24; con el bit, en 48.

**Correspondencia.** Intercambiar lo que ya está es la simetría de la instancia: renombrar colores (S₃) o los automorfismos del grafo. [T] Plegar por un grupo G ahorra a lo sumo |G|, porque cada órbita tiene a lo sumo |G| elementos: |X/G| ≥ |X|/|G|. C2 lo comprueba con el propio grupo del cubo:

| Conjunto | Tamaño | Órbitas bajo 48 | Órbitas bajo 48 × 6 colores |
|---|---|---|---|
| Asignaciones de 3 colores a los 8 vértices | 6.561 | 267 (ahorro 24,6) | 58 (ahorro 113) |
| Coloraciones propias del cubo | 114 | 15 (ahorro 7,6) | 4 (ahorro 28,5) |

Nunca más que el tamaño del grupo. Un grupo fijo pliega por un factor constante; no convierte un recinto que se abre en uno que se repite. Traer una referencia nueva corresponde a cada vértice o restricción que aporta información que no estaba, y eso es lo que abre.

**Coincidencia de valor, no convergencia.** El tetraedro se abre con base 3 y las tablas de 3-coloración también (N1-A). Es el caso que §1 pide distinguir: el 3 del tetraedro es «cuatro espejos menos el que se acaba de usar»; el 3 de la coloración es el número de colores. No se deriva uno del otro.

### 3.4 La firma plegada: cómo se ve un pliegue barato [T en el cubo; A en 3-coloración]

**En el cubo** (O59). La firma ρ_L devuelve cada imagen al recinto con una sola operación: la distancia a 2Lℤ. Una órbita infinita queda representada por un punto del dominio fundamental, sin recorrer las imágenes.

**Correspondencia.** Un algoritmo polinómico sería un pliegue de ese tipo: una forma canónica de la frontera (la firma de CR-6) que se calcula sin recorrer la órbita. La imagen muestra qué se busca. En O59 el pliegue es barato porque el grupo se conoce de antemano y actúa eje por eje. En 3-coloración el «grupo» tendría que salir de la instancia.

### 3.5 El espejo que se agrega [T/F]

**En el cubo** (O59 §4, F-PN-CME-1). Un espejo nuevo en x = 3/4 manda 1/4 a 5/4. Correr la pared de L = 1 a L = 3/2 separa 1/4 y 7/4, que eran la misma imagen. La partición antigua en órbitas deja de valer.

**Correspondencia.** Una restricción nueva puede separar estados que antes no se distinguían, como el espejo nuevo separa imágenes. No siempre lo hace: una arista redundante, que ya respetan todas las coloraciones posibles, no separa ninguna clase. Cuando la restricción no respeta el cociente anterior, la firma debe refinarse o conservar procedencia adicional. O59 T5 lo dice en el cubo: repetir las mismas reflexiones nunca alcanza un punto fuera de la órbita, y un conjunto fijo de operaciones de pliegue no crea la información que trae una restricción nueva. **La novedad que separa no es gratis.** F-PN-CME-1 prueba que existen actualizaciones que rompen la suficiencia de una firma, no que la ruptura sea inevitable: la necesidad y el costo del refinamiento se comprueban para cada operación y cada pregunta nuevas. Tampoco favorece ninguno de los dos desenlaces generales: muchos algoritmos polinómicos refinan su estado, y a costo polinómico.

### 3.6 En dos colores la arista es un espejo; en tres, no [T]

**En el cubo** (O19, CME-003, C5). El bit separa los ocho vértices por paridad en dos tetraedros: una reflexión impar los intercambia, una par los conserva. El grafo del cubo es bipartito, y C5 comprueba que sus dos clases son exactamente esos dos tetraedros regulares, de lado √2.

**Correspondencia.**
- **Con dos colores** (C3), una arista dice «el otro color»: x ↦ 1 − x, que es un espejo. Dos aristas componen la igualdad, y un ciclo cierra si y solo si es par: es la paridad del bit. Colorear con dos colores se pliega por paridad en tiempo lineal.
- **Con tres colores** (C3), la arista deja de ser una función: cada color tiene dos vecinos posibles. Componer dos aristas da las nueve parejas: componer olvida.
- **Los polimorfismos de la plantilla** (C4). Las operaciones ternarias que conservan la relación «distinto» son 16 con dos colores, entre ellas la mayoría y la paridad x + y + z. Con tres colores son exactamente 18: cada una es una proyección seguida de una permutación de colores, es decir, esencialmente unaria (Greenwell–Lovász), y ninguna es un WNU. Su única parte no trivial es el renombre de colores, S₃, que pliega por 6 (§3.3). Esto habla de la plantilla fija K₃: no descarta algoritmos construidos de otra manera ni cierres contextuales de una instancia concreta, como la igualdad que certifica el diamante (§3.7).

[T] Esto no es solo una imagen. Hell y Nešetřil (1990) probaron que colorear «hacia» un grafo H está en P si H es bipartito y es NP-completo si no. La dicotomía de CSP (Bulatov, 2017; Zhuk, 2017–2020) lo extiende a toda plantilla finita: tomada la plantilla en su núcleo (core), el problema está en P si ese núcleo admite un polimorfismo de casi-unanimidad débil (WNU), y es NP-completo si no. K₃ es su propio núcleo y no admite ninguno. En la imagen: colorear hacia el cubo se pliega por paridad; hacia el triángulo o el tetraedro, no hay pliegue que venga de la plantilla.

**Lo que no dice.** Ser NP-completo no descarta por sí solo un algoritmo polinómico; eso solo lo haría una prueba de P ≠ NP. Lo que sí dice es dónde no buscar: como K₃ no tiene polimorfismos WNU, un algoritmo polinómico para 3-coloración, si existiera, no vendría de ellos. En la imagen, P frente a NP pregunta: **¿existe un pliegue polinómico para el triángulo que no venga de ningún polimorfismo de su plantilla?**

### 3.7 El diamante es un espejo local [T]

**En la imagen** (E26, C6). En el diamante K₄ − e, intercambiar las puntas u, v dejando fija la arista compartida a–b es una simetría: un espejo cuyo plano es esa arista. Con tres colores las puntas son la misma imagen, c(u) = c(v) en las 6 coloraciones. Con cuatro colores no lo son: solo en 24 de 48. El cierre depende del recinto, como en CME-002 depende de la suma.

**Correspondencia.** Los certificados de E26 son espejos locales visibles en la instancia. LAB-CONV y N1 piden que el próximo laboratorio mire familias sin diamantes y de ancho creciente: recintos donde no se ve ningún espejo local y donde el cierre, si existe, es solo global (§3.2).

### 3.8 La paridad del cubo: un cierre global que el álgebra hace barato [T/E]

**En el cubo** (laboratorio del cubo §5, C7). En las redes XOR del cubo hay 12 aristas y 8 vértices, y el espacio de ciclos tiene dimensión 5. El sistema pone una variable en cada arista y exige en cada vértice que la suma módulo 2 de sus aristas sea una carga dada. La eliminación de Gauss decide las 256 cargas: hay solución si y solo si la carga total es par, y entonces hay exactamente 32 = 2⁵ soluciones.

**Correspondencia.** La paridad no se ve por pares (P4, E25), pero se cierra con una operación lineal. [T] La resolución, que es el sistema que simula al motor de tablas en 3-coloración (N1-B), necesita tamaño exponencial para estas fórmulas de paridad en grafos expansores (fórmulas de Tseitin; Urquhart, 1987). La eliminación de Gauss las resuelve en tiempo polinómico. Es un ejemplo existente de lo que pide §6: una representación que escapa **expresivamente** a las tablas. Para 3-coloración, los motores algebraicos análogos (Nullstellensatz, bases de Gröbner) también tienen cotas inferiores conocidas (Lauria y Nordström, 2017).

### 3.9 Reflejar no es rellenar [O/T]

**En el cubo** (O22). O22 separa dos contratos. **Reflejar** es una operación que genera imágenes. **Rellenar** es hacer que las celdas compartan interfaces y ocupen el espacio sin huecos ni solapes. El panal de tetraedros y octaedros rellena ℝ³ con una red de paridad y reglas locales de empalme.

**Correspondencia.** 3-coloración es un relleno: poner en cada vértice una de tres «piezas» con la regla de empalme «vecinos distintos». [T] Rellenar una región acotada con reglas locales de empalme es NP-completo en general (embaldosado acotado; Levin, 1973; Lewis y Papadimitriou, 1981), y rellenar todo el plano con ellas es indecidible (Berger, 1966). O22 rellena con facilidad porque sus reglas vienen con una red, la paridad, que da la construcción: es una instancia con el pliegue a la vista. Las instancias difíciles son las que no traen esa red.

### 3.10 Cuadro de la imagen

| Imagen del cubo | Fuente | Contraparte en 3-coloración | Estado | Lo que no dice |
|---|---|---|---|---|
| Cierra / se repite / se abre | CME-001, CME-002, C1 | Constante / polinómico / exponencial; el motor de tablas se abre (N1-A) | [T] en grupos; [I] en algoritmos | El espacio de búsqueda no es un grupo de Coxeter |
| Cada par cierra y el todo se abre; esferas iguales hasta L = 5 | CME-002, C1 | Los pares no deciden la relación ternaria (E25); la igualdad global forzada es coNP-completa | [T/E] | Que compartan sus relaciones: difieren en un par, 6 frente a 7; qué familia de grafos realiza esa pareja |
| El tetraedro dos veces | CME-003, CME-001, C2 | La simetría pliega a lo sumo por \|G\|; la novedad abre | [T] | Que no haya pliegues que no sean simetrías |
| Firma plegada | O59 | Forma canónica sin recorrer la órbita | [T] en el cubo; [A] en 3-coloración | Cómo encontrarla para una instancia |
| Espejo que se agrega | O59, F-PN-CME-1 | Una restricción nueva puede separar estados y obligar a refinar la firma | [T/F] | Que toda restricción nueva la rompa; una cota del refinamiento |
| La arista es espejo con 2 colores y no con 3 | O19, CME-003, C3–C5 | 2-coloración en P por paridad; en 3-coloración los polimorfismos de la plantilla son esencialmente unarios, sin WNU | [T] Hell–Nešetřil; Bulatov–Zhuk | P ≠ NP; los cierres contextuales de una instancia |
| El diamante, espejo local | E26, C6 | Certificados locales de igualdad | [T] | Los cierres globales sin diamante |
| Paridad del cubo | Laboratorio del cubo §5, C7 | El álgebra escapa a la resolución en paridad | [T] | Un álgebra así para tres colores (hay cotas en contra) |
| Reflejar no es rellenar | O22 | 3-coloración es un relleno; el relleno acotado es NP-completo | [T] | — |

## 4. Puente formal entre reflexión y cierre computacional

### T-PN-CME-1 — Descenso de una dinámica a clases de simetría [T; proposición elemental]

Sea un grupo \(G\) actuando en un conjunto \(X\), su proyección de órbitas \(\pi:X\to X/G\), un observable \(Q:X\to Y\) y una transición \(F:X\to X\). Si \(Q(gx)=Q(x)\) y \(F(gx)=gF(x)\) para todo \(g\in G\), entonces existen mapas bien definidos \(\bar Q:X/G\to Y\) y \(\bar F:X/G\to X/G\) tales que

\[Q=\bar Q\circ\pi,\qquad \pi\circ F=\bar F\circ\pi.\]

**Demostración.** Si \(\pi(x)=\pi(y)\), hay \(g\) con \(y=gx\). Por invariancia, \(Q(y)=Q(x)\); por equivariancia, \(F(y)=F(gx)=gF(x)\), de modo que sus imágenes permanecen en la misma órbita. Definimos \(\bar Q([x])=Q(x)\) y \(\bar F([x])=[F(x)]\). Ninguno depende del representante. ∎

La equivariancia es **suficiente**, no necesaria: el criterio necesario y suficiente para \(F\) es sólo que preserve la relación de equivalencia. Si cambian las reglas, la firma anterior puede ser insuficiente.

### T-PN-CME-2 — Criterio exacto de actualización de una firma [T]

Para una firma \(\Phi:X\to S\) y transición \(F:X\to X\), existe \(\widehat F\) sobre \(\Phi(X)\) con \(\Phi\circ F=\widehat F\circ\Phi\) si y sólo si

\[\Phi(x)=\Phi(y)\Rightarrow\Phi(F(x))=\Phi(F(y)).\]

**Prueba.** Necesidad por sustitución. Suficiencia: definir \(\widehat F(\Phi(x))=\Phi(F(x))\), bien definido por la implicación. ∎

### F-PN-CME-1 — Cambiar la pared rompe la suficiencia de una firma [F/E]

Tome \(x=1/4\), \(y=7/4\), \(L=1\). Se cumple \(\rho_1(x)=\rho_1(y)=1/4\). Al cambiar a \(L'=3/2\), sin cambiar las dos posiciones:

\[\rho_{3/2}(x)=1/4,\qquad\rho_{3/2}(y)=5/4.\]

Por tanto, **no existe en todas las posiciones un mapa \(T\) con \(\rho_{3/2}=T\circ\rho_1\)**. Para reconstruir la nueva comparación hacen falta más datos de rama/procedencia, o refinamiento explícito. El mecanismo de novedad existe aquí como ejemplo concreto, pero **no es gratis**. La firma ampliada \((\rho_1,\rho_{3/2})\) sí conserva ambas respuestas, sin demostrar una cota uniforme de tamaño ante sucesivos cambios.

### F-PN-CME-2 — Una operación no equivalente rompe el cociente [F/E]

Con los mismos \(x,y,L=1\), tras desplazar ambas posiciones \(t=1/4\): \(\rho_1(x+t)=1/2\) y \(\rho_1(y+t)=0\). Un desplazamiento arbitrario no desciende necesariamente al cociente de la reflexión; reflexiones que ya son elementos de su grupo sí preservan la firma.

### T-PN-CME-3 — El cociente por un grupo fijo no vence una barrera exponencial [T/E]

En 3-coloración sin colores absolutos fijados, la permutación global \(S_3\) actúa sobre las asignaciones, y las restricciones de desigualdad son invariantes. Para una frontera de k posiciones, los patrones de igualdad bajo esa acción son \(P_3(k)=\sum_{j=1}^{\min(3,k)}\big\{\!\!\begin{smallmatrix}k\\j\end{smallmatrix}\!\!\big\}\), con números de Stirling. Para k=8 hay 1094 patrones frente a 6561 asignaciones; para k grande la mejora es de factor constante cercano a 6, no una cota polinómica.

En general, para cualquier grupo finito \(G\) que actúe sobre \(X\), cada órbita tiene a lo sumo \(|G|\) elementos, luego \(|X/G|\ge |X|/|G|\): el ahorro nunca supera \(|G|\). C2 lo comprueba con el grupo de 48 del cubo y con 48 × 6. Si se exige que un vértice tenga específicamente color 0, la simetría global de renombramiento deja de respetar la pregunta. Un grupo finito de 24/48 transformaciones de CME-003 no sustituye automáticamente las restricciones de 3-coloración de un grafo arbitrario.

### F-PN-CME-3 — Cardinalidad e interfaces parciales insuficientes [F/E]

Las relaciones de paridad ternaria par/impar poseen cuatro soluciones cada una, todas sus proyecciones binarias coinciden, y su intersección es vacía. Las relaciones de frontera \(A=\{a\neq b\}\) y \(D=\{b\neq c\}\) en tres colores tienen cardinalidad 18 ambas. Ante la pregunta nueva \(K_2=\{a=b\}\), A no deja ningún caso y D deja 6. (El suplemento recibido usaba \(K=\{a\neq b\}\), que coincide con A: 18 frente a 12. Es correcto, pero degenerado.) Los testigos de E25 y LAB-CONV siguen vigentes: **valor, radio o correlaciones por pares no determinan la respuesta de cada relación futura**.

## 5. P versus NP: estado correcto después de N1 y LAB-CONV v2

**Establecido bajo contratos:** MF-86 normalización contextual idempotente; MF-97 equivalencia ante continuaciones; MF-99 composición; CR-6 firma existencial sobre frontera; E25 contraejemplo ternario; E26 fusiones por diamante con certificado; LAB-CONV v2 eliminación exacta, simetría y obstrucciones; N1-A/N1-B límites para las variantes de eliminación por tablas O2/O2c. El informe del 24-oct vuelve a ejecutar 1338 controles de grafos y clasifica coNP-completo el problema de igualdad global forzada de dos vértices bajo el contrato del laboratorio.

**N1-A:** la contabilidad del motor sin poda se gobierna por la anchura de las tablas de frontera; la elección de orden por sí sola no cambia esa familia de limitaciones. **N1-B:** toda corrida negativa del motor extensional O2c, cuando sólo cambia la prioridad de eliminación, puede traducirse a una refutación por resolución. La fuente demostraba una cota de \(\le(3/2)\cdot\texttt{total\_candidates}\) pasos de resolución bajo su codificación y convenio de conteo. Esto transfiere cotas inferiores de resolución de familias correctamente emparejadas a **ese motor**, no a toda posible operación relacional. Son resultados históricos del programa, no teoremas nuevos de este suplemento.

**Resultado de LAB-CONV v2:** 1338 grafos de control con coincidencia exacta en la reproducción actual de `verificar_exhaustivo.py` (64 de orden 4, 1024 de orden 5 y 250 de orden 6), además de instancias con y sin cierres locales. Reconocer una fusión *globalmente forzada* puede esconder una decisión coNP-completa. Un mero selector de la siguiente variable del motor ya delimitado por N1 no constituye vía nueva hacia P=NP.

**Obligación abierta:** un operador uniforme, causal, correcto y de costo polinómico total que produzca y actualice firmas contextuales operables para 3-coloración de grafos arbitrarios sin presuponer las respuestas. Debe contabilizar descubrimiento de cierres, comprobación, construcción, unión, proyección, normalización, refino, almacenamiento, consultas y resolución residual. Probar ese procedimiento para 3-coloración demostraría P=NP; un fallo del operador no demostraría P≠NP.

## 6. Contrato de la siguiente operación: otra clase de representación, no otro orden de tablas

Buscamos una `Cápsula` **operable** (MF-27/MF-52):

\[\mathfrak K=(\text{Representar},\text{Comparar},\text{Incorporar},\text{Refinar},\text{Unir},\text{Proyectar},\text{Vacío},\text{Certificar}).\]

Entrada: grafo simple con restricciones 3-color y preguntas exteriores declaradas. Salida: respuesta exacta y su certificado, o cápsula reducible con interfaz suficiente. La nueva clase debe permitir operaciones verificables con costos de bits explícitos; no basta afirmar que la cápsula tiene una fórmula corta. Formalizar sobre familias que eviten diamantes y sean de anchura creciente, incluyendo casos positivos y negativos. Exigir demostración de cómo escapa **expresivamente** a las tablas de O2/O2c, o bien reconocer que N1 vuelve a aplicar. Probar separadamente calidad de compresión, costo de encontrar equivalencias y cantidad de clases necesarias.

### Secuencia de ensayos ya convenida

1. Copiar los verificadores originales sin editarlos y repetir controles conocidos antes de cambios.
2. Usar transformaciones de espejo para verificar invariancia de la firma bajo el grupo, y falsadores cuando la pregunta nueva no sea invariante.
3. Ensayar parejas de familias de grafos de elevada anchura y con estadísticas locales semejantes, separando SAT/UNSAT y costos de selección/consulta.
4. En toda transición mantener `referencia anterior`, `novedad`, `interfaz previa`, `interfaz nueva`, `testigo`, `costo`, `condición de falsación`.
5. Evitar expresiones «múltiplo nuevo = independencia computacional» hasta demostrar un mapa operativo; la regla aritmética \(h/N=(ph)/(pN)\) no cierra el costo de 3-coloración.

### 6.1 Propuesta de la revisión: el mapa de barreras, leído en el cubo [propuesta; decide el autor]

Esta subsección es una propuesta de la revisión del 28-oct, no del suplemento recibido. No sustituye el punto de continuación de §8.

Antes de construir a escala una cápsula nueva, responder para cada representación propuesta: **¿qué sistema de prueba la simula y qué cota inferior hereda para familias de 3-coloración?** Los candidatos son la resolución (N1-B), el álgebra lineal sobre GF(2) (§3.8), el cálculo polinómico (Nullstellensatz, Gröbner) y sistemas más fuertes, como planos de corte o Frege, donde el panorama de cotas es más incompleto.

En la imagen del cubo, se trata de **clasificar cada representación por su régimen** (cierra, se repite o se abre) en las familias difíciles:
- Una representación que se abre bajo una cota conocida se descarta con certificado.
- Una que no simula ningún sistema con cotas conocidas es un candidato real, y caracterizarla sería un resultado aunque al final fallara.

El trabajo es finito y falsable, y da resultados en las dos direcciones.

## 7. Estado de repositorio y procedencia

El repositorio público `https://github.com/EndlessMonkeyProyect/programa-geometria-relacional` presenta la edición base del 24-oct y el complemento de Yang–Mills del 27-oct. Este complemento del 28-oct se agrega en su propia carpeta, sin modificar ninguno de los dos.

CME-003 tiene una solicitud pública de revisión en `https://github.com/EndlessMonkeyProyect/programa-geometria-relacional/issues/1`. La API pública de GitHub, consultada el 29-oct a las 05:31 UTC (28-oct, 23:31 en Costa Rica), registra que el autor la cerró el 25-oct a las 06:57 UTC y la reabrió a las 07:01 UTC; a las 07:03 agregó el PDF de la solicitud, su único comentario. En esa consulta el estado era abierta, con motivo «reabierta». La respuesta se guarda sin editar en [`verificacion/issue1_github_api.json`](verificacion/issue1_github_api.json), con los comandos para repetirla. El suplemento recibido y dos revisiones cruzadas asistidas por IA informaron el issue como cerrado, a partir de la página pública y sin acceso al historial de eventos. El estado puede cambiar y debe volver a comprobarse antes de citarlo.

En r/LLMmathematics, donde el autor publicó la solicitud el 26-oct, recibió una respuesta que reconoce CME-003 como la construcción clásica A₃/B₃, correcta, con correcciones de terminología. No se adjunta transcripción. Su estatus es el de un **comentario informal**, no una revisión matemática formal. Tampoco se afirma tener transcripciones literales de todos los chats.

Las fuentes congeladas del suplemento recibido son copias exactas de archivos de la edición del 24-oct, comprobadas por SHA-256 y listadas en `recibido/DUPLICADOS_RETIRADOS.csv`. Los verificadores reejecutados figuran en `verificacion/registro_reproduccion.json` con estado, tiempo y salida. Las pruebas de reflexión/combinatoria y las barreras clásicas no se reclaman como descubrimientos inéditos; la propuesta original aquí es su encadenamiento desde el hilo del programa y sus preguntas de investigación.

## 8. Estado final

- **[T]** Firmas de órbita y compresión bajo simetrías para preguntas invariantes; el ahorro por un grupo fijo nunca supera su tamaño.
- **[T]** Descenso de acciones compatibles a un cociente y criterio exacto de suficiencia dinámica.
- **[F]** La pared móvil y operaciones nuevas pueden romper la suficiencia de la firma antigua.
- **[T/I]** Imagen del cubo: los tres regímenes (cierra, se repite, se abre); la arista que es espejo con dos colores y deja de serlo con tres; la paridad que el álgebra cierra. Las correspondencias que se citan como teoremas son resultados conocidos (Hell–Nešetřil, Bulatov–Zhuk, Urquhart, embaldosado acotado), no resultados nuevos; la lectura de los regímenes como clases de costo de un algoritmo es una analogía orientadora.
- **[E]** Pruebas computacionales exactas y finitas. Verificadores históricos CME-001, CME-002, regla del bit, CME-003, O59, O22, LAB-CONV v2 y el escalado del 24-oct reproducidos con resultados idénticos; 7 controles recibidos del puente (P1–P7) y 7 nuevos de la imagen del cubo (C1–C7).
- **[A]** No hay regla universal de transformación PNP derivada del cubo, ni cota polinómica total para grafos generales.

**Punto preciso para continuar:** construir y someter a prueba un **refinador de cierre con procedencia** que incorpore preguntas nuevas sin reexpandir indebidamente las clases, bajo una arquitectura no reducida a elegir el orden de las mismas tablas de eliminación. La revisión propone hacerlo pasar primero por el mapa de barreras de §6.1.

## Referencias de enlace

- R. Berger, «The undecidability of the domino problem», *Memoirs of the AMS* 66 (1966).
- A. Bulatov, «A dichotomy theorem for nonuniform CSPs», *FOCS* (2017).
- T. J. Dekker, «On reflections in Euclidean spaces generating free products», *Nieuw Archief voor Wiskunde* 7 (1959).
- P. de la Harpe, «Groupes de Coxeter infinis non affines», *Expositiones Mathematicae* 5 (1987).
- D. Greenwell y L. Lovász, «Applications of product colouring», *Acta Mathematica Academiae Scientiarum Hungaricae* 25 (1974).
- P. Hell y J. Nešetřil, «On the complexity of H-coloring», *Journal of Combinatorial Theory, Series B* 48 (1990).
- M. Lauria y J. Nordström, «Graph colouring is hard for algorithms based on Hilbert's Nullstellensatz and Gröbner bases», *CCC* (2017).
- L. Levin, «Universal sequential search problems», *Problems of Information Transmission* 9 (1973).
- H. R. Lewis y C. H. Papadimitriou, *Elements of the Theory of Computation* (1981).
- J. H. Mason, «Can regular tetrahedra be glued together face to face to form a ring?», *Mathematical Gazette* 56 (1972).
- S. Świerczkowski, «On chains of regular tetrahedra», *Colloquium Mathematicum* 7 (1959).
- A. Urquhart, «Hard examples for resolution», *Journal of the ACM* 34 (1987).
- D. Zhuk, «A proof of the CSP dichotomy conjecture», *Journal of the ACM* 67 (2020).
