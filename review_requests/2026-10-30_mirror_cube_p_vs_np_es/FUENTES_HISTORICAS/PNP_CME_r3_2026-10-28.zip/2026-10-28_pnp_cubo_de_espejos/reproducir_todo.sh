#!/usr/bin/env bash
# Atajo: ejecuta reproducir_todo.py desde cualquier carpeta.
#   bash reproducir_todo.sh              -> integridad, verificadores y comparación
#   bash reproducir_todo.sh --registrar  -> además reescribe verificacion/registro_reproduccion.json
set -euo pipefail
RAIZ="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
exec python3 "${RAIZ}/reproducir_todo.py" "$@"
