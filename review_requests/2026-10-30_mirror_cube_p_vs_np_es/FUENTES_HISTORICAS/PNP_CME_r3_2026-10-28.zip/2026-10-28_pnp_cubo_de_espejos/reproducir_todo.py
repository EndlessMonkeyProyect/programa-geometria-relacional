#!/usr/bin/env python3
"""Reproduce el complemento P/NP x Cubo de Espejos del 28 de octubre de 2026.

1. Integridad: manifiesto de este complemento y procedencia del suplemento recibido.
   Las 49 «fuentes congeladas» del suplemento se retiraron por ser copias exactas de
   archivos de la edición 2026-10-24; se comprueban allí (recibido/DUPLICADOS_RETIRADOS.csv).
2. Verificadores: copia a una carpeta temporal las fuentes que usan (nunca se ejecutan
   en su sitio, porque algunos reescriben sus resultados) y los corre uno por uno.
3. Comparación: los resultados regenerados deben ser idénticos byte a byte a los guardados.

Necesita el repositorio completo: lee la edición hermana 2026-10-24/ y no corre desde el ZIP
del complemento suelto.

Uso:
    python3 reproducir_todo.py                # todos los verificadores
    python3 reproducir_todo.py --rapido       # omite CME-001 y CME-002, los más pesados
    python3 reproducir_todo.py --limite 120   # corta cada verificador a los 120 s
    python3 reproducir_todo.py --registrar    # además escribe verificacion/registro_reproduccion.json

Los tiempos se registran como dato de la ejecución; no son evidencia de complejidad y cambian
de un equipo a otro.
Código de salida: 0 todo pasa; 1 algún fallo; 2 algo quedó sin comprobar (dependencias que
faltan, --rapido o tiempo límite).
"""
import csv
import hashlib
import importlib.util
import json
import platform
import shutil
import subprocess
import sys
import tempfile
import time
from pathlib import Path

AQUI = Path(__file__).resolve().parent
REPO = AQUI.parent
BASE = REPO / '2026-10-24'
RECIBIDO = AQUI / 'recibido' / 'SUPLEMENTO_PNP_CME_2026-10-28'

CUBO = '02_REALIZACIONES/01_cubo_de_espejos'
PNP = '03_RAMAS/p_vs_np'

PESADOS = {'CME-001 cierre por reflexión', 'CME-002 pared que se corre'}

# (nombre, carpeta relativa en la copia temporal, orden, dependencias, salida guardada a comparar)
VERIFICADORES = [
    ('CME-001 cierre por reflexión', f'{CUBO}/CME-001_cierre_por_reflexion',
     ['cme001_cierre_por_reflexion.py'], ['numpy'], 'cme001_resultados.json'),
    ('CME-002 pared que se corre', f'{CUBO}/CME-002_pared_que_se_corre',
     ['cme002_angulos_e_identidades.py'], ['numpy', 'sympy'], 'cme002_resultados.json'),
    ('CME-002 regla del bit', f'{CUBO}/CME-002_pared_que_se_corre',
     ['comprobacion_regla_del_bit.py'], ['numpy', 'sympy'], None),
    ('CME-003 cuatro referencias', f'{CUBO}/CME-003_de_las_cuatro_referencias_a_los_angulos',
     ['cme003_cuatro_referencias.py'], [], 'cme003_resultados.json'),
    ('O59 firma plegada', f'{CUBO}/O59_orbita_y_firma_plegada',
     ['verificar_o59.py'], [], None),
    ('O22 relleno y foco', f'{CUBO}/geometria_O19_O22/O22',
     ['laboratorio_o22.py'], [], None),
    ('LAB-CONV v2 laboratorio', f'{PNP}/VIGENTE_LAB_CONV_V2',
     ['laboratorio_v2.py'], [], 'resultados_v2.json'),
    ('LAB-CONV v2 exhaustivo (1338 grafos)', f'{PNP}/VIGENTE_LAB_CONV_V2',
     ['verificar_exhaustivo.py'], [], 'controles_exhaustivos.json'),
    ('Revisión 24-oct: escalado del motor', f'{PNP}/revision_2026-10-24',
     ['escalado_cuadriculas_y_cubicos.py', '../VIGENTE_LAB_CONV_V2'], [], None),
    ('Puente recibido (7 controles)', 'recibido/laboratorio_nuevo',
     ['puente_cme_pnp.py'], [], 'resultados_puente.json'),
    ('Puente revisado (P1-P7 y C1-C7)', 'complemento/laboratorio',
     ['puente_cme_pnp_revisado.py'], [], 'resultados_puente_revisado.json'),
]


def sha256(p):
    return hashlib.sha256(Path(p).read_bytes()).hexdigest()


def integridad():
    informe = {}
    # a) manifiesto del complemento
    man = AQUI / 'MANIFIESTO_SHA256.txt'
    ok = malos = 0
    faltan = []
    if man.is_file():
        for linea in man.read_text(encoding='utf-8').splitlines():
            if not linea.strip():
                continue
            h, ruta = linea.split(None, 1)
            p = AQUI / ruta.strip().lstrip('*').removeprefix('./')
            if not p.is_file():
                faltan.append(ruta)
            elif sha256(p) == h:
                ok += 1
            else:
                malos += 1
        informe['manifiesto_complemento'] = {'ok': ok, 'distintos': malos, 'faltan': faltan}
    else:
        informe['manifiesto_complemento'] = 'no encontrado'
    # b) procedencia del suplemento recibido, con las fuentes congeladas resueltas en 2026-10-24
    duplicados = {}
    with (AQUI / 'recibido' / 'DUPLICADOS_RETIRADOS.csv').open(encoding='utf-8', newline='') as fh:
        for fila in csv.DictReader(fh):
            duplicados[fila['ruta_en_el_suplemento_recibido']] = REPO / fila['copia_identica_en_el_repositorio']
    ok = malos = 0
    faltan = []
    for linea in (RECIBIDO / 'PROCEDENCIA_SHA256.tsv').read_text(encoding='utf-8').splitlines():
        partes = linea.split('\t')
        if len(partes) < 3:
            continue
        h, _, ruta = partes[0], partes[1], partes[2]
        p = duplicados.get(ruta, RECIBIDO / ruta)
        if not p.is_file():
            faltan.append(ruta)
        elif sha256(p) == h:
            ok += 1
        else:
            malos += 1
    informe['procedencia_suplemento_recibido'] = {
        'ok': ok, 'distintos': malos, 'faltan': faltan,
        'resueltos_en_2026-10-24': len(duplicados)}
    return informe


def preparar_copia(tmp):
    for rel in (CUBO, PNP):
        shutil.copytree(BASE / rel, tmp / rel)
    shutil.copytree(RECIBIDO / 'laboratorio_nuevo', tmp / 'recibido' / 'laboratorio_nuevo')
    shutil.copytree(AQUI / 'laboratorio', tmp / 'complemento' / 'laboratorio',
                    ignore=shutil.ignore_patterns('__pycache__'))


def guardada(carpeta, salida):
    """Ruta del resultado guardado con el que se compara lo regenerado."""
    if carpeta.startswith('recibido/'):
        return RECIBIDO / carpeta.removeprefix('recibido/') / salida
    if carpeta.startswith('complemento/'):
        return AQUI / carpeta.removeprefix('complemento/') / salida
    return BASE / carpeta / salida


def main():
    registrar = '--registrar' in sys.argv
    rapido = '--rapido' in sys.argv
    limite = None
    if '--limite' in sys.argv:
        limite = float(sys.argv[sys.argv.index('--limite') + 1])
    if hasattr(sys.stdout, 'reconfigure'):
        sys.stdout.reconfigure(encoding='utf-8')
    if not BASE.is_dir():
        print('Falta la edición 2026-10-24/ junto a esta carpeta. Este complemento se reproduce '
              'dentro del repositorio completo:\n'
              '  git clone https://github.com/EndlessMonkeyProyect/programa-geometria-relacional.git')
        return 2
    faltantes = {m for m in ('numpy', 'sympy') if importlib.util.find_spec(m) is None}
    print('== Integridad')
    integ = integridad()
    print(json.dumps(integ, ensure_ascii=False, indent=2))
    fallo = any(isinstance(v, dict) and (v['distintos'] or v['faltan']) for v in integ.values())

    filas = []
    with tempfile.TemporaryDirectory() as t:
        tmp = Path(t)
        preparar_copia(tmp)
        print('\n== Verificadores (en una copia temporal)')
        for nombre, carpeta, orden, deps, salida in VERIFICADORES:
            falta = [d for d in deps if d in faltantes]
            fila = {'verificador': nombre, 'carpeta': carpeta, 'orden': 'python3 ' + ' '.join(orden)}
            if falta or (rapido and nombre in PESADOS):
                motivo = 'falta ' + ', '.join(falta) if falta else 'omitido con --rapido'
                fila.update(estado='OMITIDO', motivo=motivo)
                print(f'  OMITIDO  {nombre}  ({motivo})')
                filas.append(fila)
                continue
            t0 = time.perf_counter()
            try:
                proc = subprocess.run([sys.executable] + orden, cwd=tmp / carpeta, timeout=limite,
                                      capture_output=True, text=True, encoding='utf-8')
            except subprocess.TimeoutExpired:
                fila.update(estado='TIEMPO', motivo=f'superó el límite de {limite:g} s')
                print(f'  TIEMPO   {nombre}  (superó {limite:g} s)')
                filas.append(fila)
                continue
            seg = time.perf_counter() - t0
            salida_txt = (proc.stdout + proc.stderr).strip().splitlines()
            estado = 'PASS' if proc.returncode == 0 else 'FAIL'
            fila.update(estado=estado, codigo=proc.returncode, segundos=round(seg, 2),
                        ultimas_lineas=salida_txt[-4:])
            if salida and estado == 'PASS':
                igual = (tmp / carpeta / salida).read_bytes() == guardada(carpeta, salida).read_bytes()
                fila['resultado_regenerado_identico_al_guardado'] = igual
                if not igual:
                    estado = fila['estado'] = 'FAIL'
            fallo = fallo or estado == 'FAIL'
            print(f'  {estado:7s}  {nombre}  ({seg:.1f} s)'
                  + ('' if not salida or 'resultado_regenerado_identico_al_guardado' not in fila
                     else f'  · {salida} idéntico: {fila["resultado_regenerado_identico_al_guardado"]}'))
            filas.append(fila)

    omitidos = any(f['estado'] in ('OMITIDO', 'TIEMPO') for f in filas)
    resumen = 'FAIL' if fallo else ('INCOMPLETO' if omitidos else 'PASS')
    print('\n== Resumen:', resumen)
    if registrar:
        versiones = {'python': platform.python_version(), 'plataforma': platform.platform()}
        for m in ('numpy', 'sympy'):
            if m not in faltantes:
                versiones[m] = __import__(m).__version__
        registro = {
            'fecha': time.strftime('%Y-%m-%d'),
            'entorno': versiones,
            'resumen': resumen,
            'integridad': integ,
            'verificadores': filas,
            'nota': 'Los tiempos son de esta ejecución y no son evidencia de complejidad. '
                    'Cada verificador corre en una copia temporal; las fuentes no se modifican.',
        }
        destino = AQUI / 'verificacion' / 'registro_reproduccion.json'
        destino.parent.mkdir(exist_ok=True)
        destino.write_text(json.dumps(registro, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
        print('Registro:', destino.relative_to(REPO))
    return 1 if fallo else (2 if omitidos else 0)


if __name__ == '__main__':
    raise SystemExit(main())
