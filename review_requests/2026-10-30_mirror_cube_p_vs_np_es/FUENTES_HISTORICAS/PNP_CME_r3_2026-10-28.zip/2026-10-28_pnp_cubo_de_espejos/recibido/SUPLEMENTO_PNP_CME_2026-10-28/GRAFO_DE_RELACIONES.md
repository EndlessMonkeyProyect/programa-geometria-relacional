# Genealogía de cierre entre el laboratorio de espejos y P frente a NP

## Grafo de resultados (las flechas no representan implicaciones universales)

```mermaid
flowchart TD
  O[Ontología: reflexión, diferencia, cierre propio] --> M[Espejo móvil y normalización]
  O --> Q[MF-97: equivalencia por continuaciones]
  M --> CME1[CME-001: orientaciones y posiciones]
  M --> CME2[CME-002: suma de ángulos y tricotomía]
  M --> CME3[CME-003: cuatro referencias / 24 y 48]
  CME1 --> O59[O59: firma de órbita]
  O59 --> T2[Puente: firma y suficiencia dinámica]
  CME2 --> T2
  CME3 --> T1[Puente: acciones de grupos y clases]
  Q --> CR6[CR-6: interfaz de frontera]
  Q --> T1
  CR6 --> E25[E25: ternario contra marginales]
  CR6 --> E26[E26: certificados por diamante]
  E25 --> LC[LAB-CONV v2: unión/proyección/normalizar]
  E26 --> LC
  LC --> N1[N1-A/B: límites del motor de tablas]
  T1 --> META[Pregunta nueva: refinador operable con procedencia]
  T2 --> META
  N1 --> META
  META --> OPEN[Abierto: corrección y costo polinómico universal]
```

## Lectura obligatoria de las flechas

- **Espejos → cómputo:** una *realización ejemplar* de equivalencia y pérdida de suficiencia, no un algoritmo universal sobre grafos.
- **N1 → nuevo operador:** obliga a no reducir el avance a un nuevo orden de eliminación en el mismo motor.
- **MF-97 → CR-6:** una instanciación con preguntas exteriores limitadas a fronteras, no identidad absoluta de historias.
- **CME-003 → 3-coloración:** analogía de acciones de grupo; no extender S4/S3 sin demostrar que es simetría de la instancia y de la pregunta.
- **Cierre ontológico → eficiencia:** enlace *abierto*: requiere demostrar costos y certidumbre de todas las operaciones.
