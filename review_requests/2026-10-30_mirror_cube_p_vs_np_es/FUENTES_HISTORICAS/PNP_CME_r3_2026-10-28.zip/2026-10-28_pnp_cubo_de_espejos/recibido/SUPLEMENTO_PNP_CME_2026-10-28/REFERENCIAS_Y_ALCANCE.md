# Fuentes, procedencia y límites

## Fuentes del paquete

- Archivo base: `Programa_Geometria_Relacional_Ordenado_2026-10-24.zip` (Biblioteca), examinado y verificado (1.047/1.047 archivos, cero errores). El ZIP integrado lo preserva sin cambiar un byte de sus archivos.
- `fuentes_congeladas/`: extractos del original: CME-001/002/003, O19–O22, O59, LAB-CONV v2, N1-B y PISO DEL CAMINO v2.7.
- `fuentes_complementarias/`: MF-106, E26, auditoría E25 y kit CME-003 del 25-oct, recuperados en Biblioteca. Las instrucciones compiladoras del 24-oct se consultaron, pero su copia en bruto no estaba disponible; el suplemento conserva sus correcciones relevantes.
- Repositorio público: https://github.com/EndlessMonkeyProyect/programa-geometria-relacional (consulta del 28-oct-2026). README indica edición base 24-oct y complemento YM 27-oct.
- Solicitud CME-003: https://github.com/EndlessMonkeyProyect/programa-geometria-relacional/issues/1 (aparece cerrada el 25-oct; ninguna reseña externa se afirma aquí).
- Resúmenes y documentos de continuidad de conversaciones antiguas: no equivalen a transcripciones palabra por palabra; el acceso histórico completo al chat no estaba disponible en esta ejecución.

## No incluidas / no verificadas íntegramente

- Cada chat original como transcripción literal completa.
- Todos los cálculos de todas las versiones experimentales históricas; sí se preserva la base y se reejecutan los ensayos enumerados.
- Una evaluación externa por especialistas de CME-003.
- Una modificación remota confirmada del repositorio público (no se ha publicado este suplemento allí).
- Ninguna prueba general de P=NP ni P≠NP.
