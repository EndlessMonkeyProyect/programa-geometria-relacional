# Estado de reproducciones en esta sesión (28-oct-2026)

| Prueba | Estado | Duración observada (s) | Evidencia |
|---|---|---:|---|
| CME001_run | PASS | 12.06 | ] / tetraedro_regular  [5, 17, 53, 161, 485, 1457, 4373, 13121, 39365, 118097, 354293, 1062881]  diedros/pi=[0.391827] / tetraedro regular = 2·3^L−1 (producto libre de cuatro Z2) hasta L=12; cubo=8; ortoesquema=48 /  |
| CME002_run | PASS | 21.918 | 8260 = número de Lehmer 1.176280818260 / (2,3,k): cierra para k=2..5 (12, 24, 48, 120), se repite en k=6, se abre desde k=7. (2,2,k): cierra para todo k en 4k. Ángulos e identidades coinciden en todos los casos. /  |
| CME003_run | PASS | 1.238 |  ; el 5 no aparece /  una referencia distinguible: 6 orientaciones, espejos alrededor de una recta: 2 direcciones, no 3 /  espejo de cara: crea una referencia nueva a 5/3 del radio; las cuatro, tetraedro invertido /  |
| CME_BIT_run | PASS | 1.017 | ..256): /   p=3: ord=2 /   p=5: ord=4 /   p=7: ord=3 /   p=17: ord=8 /   p=31: ord=5 /   p=11: ord=10 /   p=13: ord=12 /   p=127: ord=7 /   p=43: ord=14 /   p=257: ord=16 / enteros n<=40 sin primo con ord_p(2)=n (Zsigmondy): [1, 6] /  |
| LABCONV_run | PASS | 1.346 | EXHAUSTIVO n= 4 64 PASSED / EXHAUSTIVO n= 5 1024 PASSED / PASSED total: 1338 graphs /  |
| LAB_CONV_BATERIA_run | PASS | 3.01 | s 85 bag 3 peak_valid 9 /   min_fill orbit YES  evals 20 bag 3 peak_valid 2 /   reverse raw YES  evals 85 bag 3 peak_valid 9 /   reverse orbit YES  evals 20 bag 3 peak_valid 2 / OK 12 cases; outputs resultados_v2.json /  |
| O59_run | PASS | 1.013 | O59 verificación racional: PASS (8 grupos de verificaciones) /  |

El script nuevo `laboratorio_nuevo/puente_cme_pnp.py` también pasó sus 7 grupos de controles finitos exactos, con `resultados_puente.json`. Los tiempos no demuestran ninguna cota asintótica y no forman parte de las pruebas teóricas. Los controles históricos se realizaron sobre copias temporales para preservar los fuentes congelados; los JSON de `verificacion/` son registros nuevos. No se reejecutó toda la genealogía histórica ni se auditó matemáticamente cada afirmación externa.
