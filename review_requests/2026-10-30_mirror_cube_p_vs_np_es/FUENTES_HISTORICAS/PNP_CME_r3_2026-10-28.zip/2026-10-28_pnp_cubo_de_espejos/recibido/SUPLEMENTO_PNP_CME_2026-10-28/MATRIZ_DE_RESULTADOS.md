# Matriz de estado PNP ↔ CME · 2026-10-28

| ID | Enunciado delimitado | Estado | Prueba o fuente | Advertencia |
|---|---|---|---|---|
| CME-001 | Cubo ideal 8 partes lineales; 48 ortoesquema | T/E histórico | CME-001 | Posiciones infinitas posibles |
| O59 | Firma de órbita de espejos 0,L | T/E | `verificar_o59.py` | No responde cualquier consulta exterior |
| CME-002 | Tricotomía de (2,3,k), cierre k=2..5; afín 6 | T/E | `cme002_angulos_e_identidades.py` | No generalizar a todo grupo Coxeter |
| CME-003 | Intercambios de cuatro referencias: 24; con bit: 48 | T/E | `cme003_cuatro_referencias.py` | Hipótesis geométricas explícitas |
| PN-CME-T1 | Cociente por grupo y dinámica equivariante | T | Demostración en suplemento | Criterio suficiente |
| PN-CME-T2 | Factorización iff preservación de clases | T | Demostración en suplemento | No promete cómputo económico |
| PN-CME-F1 | Cambio de L separa misma órbita vieja | F/E | `puente_cme_pnp.py` | Nueva diferencia exige refinamiento |
| PN-CME-F2 | Desplazamiento arbitrario no respeta cociente | F/E | `puente_cme_pnp.py` | No toda operación del marco es simetría |
| E25 | Proyecciones binarias no determinan restricción ternaria | T/F/E | E25, puente | Cardinal/radio no bastan |
| E26 | Diamante certifica igualdad en 3-coloración | T/E | E26, puente | No detecta todos los cierres globales |
| LAB-CONV-v2 | Eliminación por fronteras + 1338 controles | T/E | `verificar_exhaustivo.py` | Ancho crece, simetría S3 ahorra factor constante |
| N1-A/B | Barreras de motores de tablas O2/O2c | T condicionado al motor | PISO, N1-B | No implica P≠NP |
| R-01 | Normalización aritmética de múltiplos | T | R-01, secuencia | No equiparar con costo computacional |
| Hipótesis central | Refinador universal económico para 3-coloración | A | Laboratorio futuro | Implicaría P=NP si se demostrara |
| P=NP/P≠NP | Resolución general | A | Ninguna | No reclamada |
