# Actualización P/NP × Cubo de Espejos — 28 octubre 2026

**Estado:** suplemento integrado, aditivo, de uso interno y revisión. **No prueba P=NP ni P≠NP.**

- `ACTUALIZACION_PNP_CME_2026-10-28.md`: hilo ontológico, matemática, falsadores, límites y nuevo punto de reanudación.
- `MATRIZ_DE_RESULTADOS.md`: estados y procedencia por afirmación.
- `INSTRUCCIONES_DE_INTEGRACION.md`: destino para los capítulos de la Imagen Total / ROSI.
- `laboratorio_nuevo/puente_cme_pnp.py`: siete controles finitos exactos sobre firma plegada, desplazamiento, simetrías, E25 y diamante.
- `verificacion/`: resultados reejecutados en esta sesión, con tiempos observados no usados para deducir complejidad.
- `fuentes_congeladas/`: copias sin edición de originales del archivo ordenado del 24-oct; incluyen CME-001/002/003, O59, geometría O19–O22, LAB-CONV v2 y revisiones/N1.
- `fuentes_complementarias/`: documentos históricos de Biblioteca conservados como archivos independientes.
- `PROCEDENCIA_SHA256.tsv` y `ESTADO_EJECUCIONES.md`: controles de integridad y límites reproducibles.

## Para reproducir

Desde la raíz de este paquete:

```bash
python3 laboratorio_nuevo/puente_cme_pnp.py
python3 fuentes_congeladas/02_REALIZACIONES/01_cubo_de_espejos/CME-003_de_las_cuatro_referencias_a_los_angulos/cme003_cuatro_referencias.py
python3 fuentes_congeladas/02_REALIZACIONES/01_cubo_de_espejos/O59_orbita_y_firma_plegada/verificar_o59.py
```

Para pruebas históricas más lentas (`CME-002`, `LAB-CONV v2`) consultar los respectivos scripts y los registros existentes. Los ejecutados en esta sesión figuran con sus resultados en `verificacion/`.

## Fuente base principal

`Programa_Geometria_Relacional_Ordenado_2026-10-24.zip` (Biblioteca), copiado parcialmente sin modificación a `fuentes_congeladas/`. El ZIP integrado incluye todos los originales de la edición base por separado. Las conversaciones históricas se representan por sus registros y documentos recuperables; no se garantiza acceso textual literal a cada conversación.
