# Integración aditiva a Imagen Total y ROSI

1. **No sobrescribir fuentes.** Copiar `ACTUALIZACION_PNP_CME_2026-10-28.md` a `03_RAMAS/p_vs_np/ACTUALIZACION_2026-10-28/` y enlazarlo desde el índice de P/NP.
2. En `02_REALIZACIONES/01_cubo_de_espejos/` añadir enlace de regreso a la actualización. Mantener CME-001/002/003 originales tal como están, incluidos sus problemas y correcciones históricas.
3. Priorizar las distinciones: orientaciones vs posiciones; grupo finito vs geometría proyectada; firma vs objeto; pregunta invariante vs novedad; reducción correcta vs reducción barata; contrato matemático vs puente físico.
4. Incluir en el atlas un eje `observables/firmas` y otro `continuaciones/costos`. El cubo representa firmas bajo acciones, las esferas y el C4 son realizaciones separadas. ROSI puede indexar `CME ↔ MF97 ↔ CR6 ↔ N1`, sin postular que el índice es una prueba.
5. El próximo laboratorio no debe declararse completo hasta fijar representación nueva, operaciones, costo de todas ellas, familias adversas y certificados reejecutables. Priorizar casos sin diamantes de anchura creciente.
6. `verificacion/` acredita solo ejecuciones enumeradas; no inventar auditoría de todos los chats, de todos los ZIP antiguos ni de una revisión externa.
7. El repositorio GitHub no fue modificado en esta sesión; el suplemento se entrega listo para incorporar mediante revisión del usuario.
