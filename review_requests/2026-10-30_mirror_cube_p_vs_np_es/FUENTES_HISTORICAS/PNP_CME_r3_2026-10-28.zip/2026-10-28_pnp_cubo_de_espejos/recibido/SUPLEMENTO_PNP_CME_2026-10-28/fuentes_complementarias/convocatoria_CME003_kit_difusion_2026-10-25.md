# Kit de difusión — revisión independiente CME-003
**Preparado:** 25 de octubre de 2026  
**Autor del programa:** Le Matt Ansatz Di Ego  
**Estado de este kit:** mensajes redactados, **no enviados**. La convocatoria existe en GitHub; este kit no certifica su estado actual ni valida el resultado matemático.

## Destino principal
- [Issue #1 — Independent review request: CME-003, four references and reflection groups](https://github.com/EndlessMonkeyProyect/programa-geometria-relacional/issues/1)
- [PDF de la solicitud de revisión, enlazado en la conversación](https://github.com/user-attachments/files/33920521/CME003_review_brief.en.pdf). Antes de difusión masiva, comprobar que se descarga y contiene el documento correcto.

## Delimitación de lo que se solicita revisar
En el espacio euclidiano R³ se toman los cuatro vectores (1,1,1), (1,-1,-1), (-1,1,-1), (-1,-1,1). Se construyen las seis reflexiones con normales dadas por las diferencias entre pares de vectores. La nota estudia la acción sobre las cuatro referencias, un grupo de orden 24, una extensión de orden 48 mediante un cambio de signo coordenado y ángulos de espejo π/2, π/3 y π/4 en la extensión. Son premisas explícitas la métrica euclidiana y la elección de las cuatro referencias. **No se reivindica haber probado P=NP, Yang–Mills, Navier–Stokes ni el programa integral**. El propósito es comprobar la construcción bajo esas hipótesis, corregir terminología y situarla en la teoría clásica de grupos de reflexión A3/B3.

## Primera ronda — canales y orden sugerido

**1. Departamento de Matemática de la Universidad de Costa Rica**  
Canal institucional verificable: **pura.em@ucr.ac.cr**. Solicitar, si es posible, derivación a una persona con conocimiento de grupos de reflexión, geometría discreta o teoría de grupos finitos. Sitio: https://emate.ucr.ac.cr/index.php/departamento-de-matematica . No suponer que el destinatario ya accedió a revisar.

**2. Especialistas en grupos de reflexión / Coxeter (consulta individual y breve, no envíos masivos)**  
- Grupo de *Groups and Geometry*, Universidad de Bielefeld: https://www.math.uni-bielefeld.de/groupsgeometry/index.php — investiga grupos de reflexión, Coxeter y grupos finitos. Conviene consultar la vía institucional de contacto y enviar a una sola persona relevante.
- Petra Schwer, Universidad de Heidelberg: https://web.mathi.uni-heidelberg.de/ggt/schwer — investigación en geometría y grupos de Coxeter; página que menciona la Reflection Groups Network.
- James Parkinson, Universidad de Sídney: https://extern.maths.usyd.edu.au/u/jamesp/ — intereses en grupos de Coxeter, geometría de incidencia y teoría de representaciones. Correo profesional público en su página: jamesp@maths.usyd.edu.au.

**3. Difusión pública moderada**  
Explorar r/math y cualquier hilo expresamente habilitado para proyectos/consultas; revisar las reglas vigentes de cada comunidad antes de publicar, revelar la autoría y no repetir el enlace en múltiples comunidades. **No usar MathOverflow para pedir que revisen un artículo completo**: su normativa considera fuera de tema las solicitudes genéricas de verificación de pruebas o anuncios de resultados. Solo sería pertinente una pregunta autónoma sobre un punto matemático preciso, sin publicidad.

## Mensaje de contacto individual — ESPAÑOL
**Asunto:** Consulta de revisión matemática acotada: cuatro referencias y grupos de reflexión A3/B3 (CME-003)

Estimada/o colega:

Estoy solicitando una evaluación independiente de una nota breve y reproducible sobre una construcción geométrica de cuatro referencias en R³ y las reflexiones que estas generan. La nota trabaja bajo hipótesis explícitas de geometría euclidiana; no presenta la teoría clásica de reflexiones como un resultado nuevo.

La pregunta central es si las identificaciones con las representaciones de reflexión A3/B3 y las distinciones entre reflexiones, rotaciones y acciones sobre vértices son correctas, así como qué correcciones o referencias estándar conviene incorporar.

El expediente, la nota y el verificador están disponibles públicamente aquí:
https://github.com/EndlessMonkeyProyect/programa-geometria-relacional/issues/1

Agradecería incluso una observación breve y crítica, una referencia adecuada o una indicación de que el alcance requiere correcciones. Puede responder allí en español o inglés; no se le solicita respaldar el resto del programa.

Atentamente,  
Le Matt Ansatz Di Ego  
Programa de Geometría Relacional

## Individual email — ENGLISH
**Subject:** Focused mathematical review request: four references and A3/B3 reflection groups (CME-003)

Dear colleague,

I am seeking independent feedback on a short, reproducible mathematical note concerning four reference vectors in Euclidean R³ and the reflection groups arising from their pairwise differences.

The proposed construction is explicitly framed within classical reflection theory; it is not presented as a new proof of a major open problem. I would especially value a critical check of the group identifications (A3/B3), the mirror angles, the distinctions between group elements and proper rotations, and standard references that should be cited.

The bounded review request, fixed source revision, note, verifier, and review questions are available here:
https://github.com/EndlessMonkeyProyect/programa-geometria-relacional/issues/1

Even a short correction, counterexample, or reference would be useful. Please feel free to decline if the topic is outside your interests. Comments in English or Spanish are welcome; feedback on this component will not be portrayed as validation of the larger program.

Kind regards,  
Le Matt Ansatz Di Ego  
Relational Geometry Program

## Mensaje público breve — en inglés, sujeto a reglas comunitarias
**Title:** Request for critical feedback on a four-vector reflection-group construction (A3/B3)

I am sharing a narrow, reproducible mathematical review request. Starting with the four vectors (±1,±1,±1) forming a regular tetrahedral vertex set in Euclidean R³, the note examines the six pairwise-difference reflections, an order-24 group and an order-48 extension. I am looking for corrections to the group identification, terminology on rotations vs reflections, and standard sources for the corresponding A3/B3 theory. This is a request for independent criticism, **not a claim to have solved an open problem**. The fixed source, Python check, and three precise review questions are here: https://github.com/EndlessMonkeyProyect/programa-geometria-relacional/issues/1. I am the author of the program.

## Lista de control antes de cada publicación
- Confirmar enlace público al Issue y verificar que el PDF abre y es correcto.
- Confirmar reglas de comunidad y si se permite autopromoción o consultas de revisión.
- Identificar al remitente y no atribuir revisiones que no han ocurrido.
- Enviar invitaciones individuales, no masivas; una ronda de tres contactos como máximo al comenzar.
- Registrar fecha, destinatario, enlace, respuesta y posibles correcciones; no presionar por una respuesta.
- No confundir comentarios, número de visitas o aprobaciones sociales con revisión matemática formal.

## Fuentes consultadas (25-oct-2026)
- Convocatoria: https://github.com/EndlessMonkeyProyect/programa-geometria-relacional/issues/1
- UCR: https://emate.ucr.ac.cr/index.php/departamento-de-matematica
- Bielefeld: https://www.math.uni-bielefeld.de/groupsgeometry/index.php
- Heidelberg: https://web.mathi.uni-heidelberg.de/ggt/schwer
- Sídney: https://extern.maths.usyd.edu.au/u/jamesp/
- MathOverflow — alcance y normas: https://mathoverflow.net/help/on-topic
- Reddit — normas de comunidad: https://www.business.reddit.com/learning-hub/articles/find-subreddits-for-your-business
- Zenodo para depósito posterior (opcional): https://help.zenodo.org/docs/get-started/quickstart/
