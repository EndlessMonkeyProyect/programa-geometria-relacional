# E26 / O2d — Testigos relacionales, elección de cierre y economía de recorrido

**Programa de Geometría Relacional · suplemento reproducible · 15 de octubre de 2026**  
**Autor del programa:** Le Matt Ansatz Di Ego  
**Objeto:** 3-coloración exacta de grafos generales. **No** se transforma la instancia a SAT.

## 0. Estatuto epistemológico

- **[DEFINICIÓN]** Los objetos matemáticos y los contratos algorítmicos quedan explícitos.
- **[TEOREMA]** La regla del diamante y la proyección exacta son consecuencias matemáticas demostradas; no se presentan como descubrimientos inéditos de teoría de grafos.
- **[EXPERIMENTO]** Las estadísticas de la implementación se refieren a los grafos y semillas publicados.
- **[NO-GO]** La heurística de previsualización no ofrece por sí sola una economía nueva demostrada y falló en esta batería.
- **[ABIERTO]** No se deriva un algoritmo polinómico universal para 3-coloración, y por ello tampoco se resuelve P frente a NP.

## 1. Premisa ontológica y comparación

La comparación aparece dentro de una disposición determinada de relaciones. Cuando cambia una relación acreditada, puede cambiar el mapa de dependencias y el costo de resolver preguntas. Que dos coloraciones globales produzcan una misma respuesta a una pregunta no significa que sean la misma historia ni que la historia interna haya sido descartada.

En la traducción matemática, sea el grafo simple no dirigido `G=(V,E)` y `C(G)` el conjunto de coloraciones propias `c:V→{0,1,2}`. Para frontera `B⊆V`:

\[
\Gamma_G(B)=\{c|_B:c\in C(G)\}.
\]

Para pregunta `Q` sobre la frontera, `A_Q(G)=Q(Γ_G(B))`; por convención, si `Γ=∅`, no existe respuesta acreditada. La consulta de igualdad de dos terminales toma `Q(c)=[c_u=c_v]`.

**No confundir** `|C(G)|`, `|Γ_G(B)|`, `|A_Q(G)|` y el costo de construirlos. E25 mostró por qué las marginales individuales no reemplazan siempre a la relación conjunta.

## 2. E26-T1 — Testigo de igualdad por diamante

**Hipótesis:** tres colores exactos, aristas `ab,au,bu,av,bv ∈ E`.

**Tesis:** para toda coloración propia `c` del grafo, `c(u)=c(v)`.

**Demostración:** como `a` y `b` son adyacentes, reciben dos colores distintos. Tanto `u` como `v` son adyacentes a ambos; por tanto, en un alfabeto de tres colores cada uno debe recibir el único tercer color. ∎

En consecuencia, puede identificarse `u~v` manteniendo correspondencia biunívoca entre las coloraciones propias del grafo original y las del cociente, si no aparece conflicto. Si además `uv∈E`, las aristas fuerzan simultáneamente `c(u)=c(v)` y `c(u)≠c(v)`; el grafo no admite 3-coloración (contiene K₄ sobre esos cuatro vértices).

La prueba **NO vale para cuatro colores**: `c(a)=0,c(b)=1,c(u)=2,c(v)=3` satisface las cinco aristas anteriores y `u≠v`.

## 3. E26-T2 — Propagación y conservación de frontera

El algoritmo inspecciona las aristas `ab` de un grafo *contraído en el estado actual*, calcula vecinos comunes y conserva un testigo `{a,b,u,v}` de cada igualdad forzada. Contrae `u,v` y vuelve a inspeccionar. Cada contracción reduce la cantidad de clases de vértices; por tanto, hay a lo sumo `|V|-1` fusiones. Cada vuelta inspecciona finitamente aristas e intersecciones de vecinos; la implementación ingenua tiene costo **polinómico** en el tamaño de entrada.

Sea `p:V→V'` el mapa de clases tras contraer. La relación exterior original se reconstruye de la relación del grafo cociente:

\[
\Gamma_G(B)=\{(c'(p(b)))_{b\in B}:c'\in C(G')\}.
\]

**Demostración:** la aplicación `c'↦c'∘p` conserva las aristas originales al haber contraído solo igualdades obligatorias. Recíprocamente toda coloración original es constante en cada clase fusionada, y por eso induce una única coloración del cociente. Ambas operaciones son inversas. Si aparece una arista interna a una clase, la relación exterior es vacía. ∎

**Límite:** este procedimiento no encuentra necesariamente todas las igualdades semánticas; es una prueba local *suficiente*, no un decisor general.

**Certificado verificable:** la lista de testigos se reproduce sobre el grafo contraído y se comprueba que cada testigo contiene las cinco aristas requeridas. Se prueba también que alterar una referencia del testigo invalida la verificación. Este certificado acredita solo la corrección de esas fusiones: no reemplaza al oráculo de coloración del grafo residual.

## 4. E26-T3 — Recierre exacto por eliminación de factores

Un factor `f` almacena una tabla finita de asignaciones permitidas a las variables de su ámbito. Para una referencia interna `v`, la transformación exacta es:

\[
\left\{f_i:v\in\operatorname{scope}(f_i)\right\}
\longmapsto\left\{\exists v\ \bigwedge_{i:v\in\operatorname{scope}(f_i)}f_i\right\}.
\]

Para toda elección de orden de eliminación, la proyección final es exactamente `Γ_G(B)`, porque cuantificación existencial y conjunción de factores ajenos a la variable conmutan. El orden **sí** modifica la anchura y el trabajo intermedio, no la respuesta al problema original. Es la garantía matemática del motor O2/O2c, reutilizado sin alterar.

## 5. E26-H1 — Previsualizar el encuentro local exacto

La política nueva `preview_local` no mira ninguna coloración global. En cada estado:

1. Calcula el mismo orden estructural `min_fill` que el comparador.
2. Preselecciona hasta tres candidatos con bolsa de tamaño como máximo `min_bag + 1` y como máximo cinco variables.
3. Para cada candidato, **calcula exactamente** la tabla que produciría su próximo cierre; prioriza la menor densidad de filas sobrevivientes, luego cercanía con las referencias preguntadas y luego costos y desempates estructurales.
4. Reutiliza la tabla del candidato finalmente elegido; no vuelve a computarla.
5. **Cobra** el trabajo de calcular las tablas de candidatos descartados.

Se distinguen operaciones de tabla `3^{|bag|}` (enumeraciones reales), lecturas de factores del selector previo, y exploraciones estructurales. Estas unidades **no equivalen** automáticamente a tiempo CPU.

`total_candidates` = enumeraciones de cierre ejecutado + frontera final.  
`rejected_preview_candidates` = enumeraciones de candidatos inspeccionados y no elegidos.  
`effective_table_candidates` = suma de ambos.

### Resultado empírico negativo: primera muestra preregistrada

| Grupo | Casos | Previsualización mejora, contando sobrecosto | Empata | Empeora |
|:--|--:|--:|--:|--:|
| O2c histórico predefinido | 35 | 0 | 0 | 35 |
| Grafos nuevos con semillas predefinidas | 18 | 0 | 0 | 18 |
| Casos históricos exploratorios | 4 | 0 | 0 | 4 |

Todos los cierres producen `Γ(B)` idéntica. **Conclusión:** calcular exactamente varios cierres para escoger uno no garantiza economía; aquí resultó peor al contabilizar la exploración. No se ocultó ese resultado negativo ni se ajustaron coeficientes para que la muestra saliera favorable. Las semillas y la política están en el código.

## 6. E26-H2 — Reducción acreditada mediante testigos

Antes de eliminar factores, se prueban fusiones obligatorias por el lema del diamante. Se conserva el mapa de clases y las preguntas se reconstruyen en las referencias originales. Después, se ejecuta el **mismo** `min_fill` original sobre el grafo reducido.

| Grupo | Casos | Menos enumeraciones de tablas | Iguales | Más enumeraciones |
|:--|--:|--:|--:|--:|
| O2c histórico predefinido | 35 | 16 | 19 | 0 |
| Aleatorios nuevos, semillas declaradas | 18 | 14 | 4 | 0 |
| Familia estructurada de diamantes | 14 | 14 | 0 | 0 |
| Testigos O2c postseleccionados | 4 | 3 | 1 | 0 |
| Falsador sin testigos | 1 | 0 | 1 | 0 |

**Advertencia imprescindible:** esto mide ahorro en las **tablas posteriores**, no reducción del tiempo total. Buscar testigos también cuesta: en las 14 cadenas estructuradas se inspeccionaron 13.921 aristas a través de múltiples pasadas, frente a 23.238 enumeraciones de tabla del comparador. No es lícito sumar ambas unidades ni declarar una mejora de tiempo sin medición adicional y control de hardware.

Para las 35 instancias históricas, el comparador examinó 7.839 asignaciones de tabla y el método reducido examinó 4.776. Estos resultados no acreditan una cota polinómica para grafos arbitrarios.

### Testigo negativo indispensable: Grötzsch / Mycielski(C₅)

La construcción de Mycielski del ciclo de cinco vértices tiene **11 vértices, 20 aristas, ningún triángulo y no admite 3-coloración**. Como no posee aristas con pares de vecinos comunes adyacentes, el reductor no encuentra fusiones ni contradicción. El motor general O2c decide correctamente que `Γ=∅`; el DFS independiente confirma el resultado. **No confundir «ningún testigo local» con «colorable».**

## 7. Qué permanece abierto para P frente a NP

La 3-coloración de grafos generales es NP-completa. Por ello, un algoritmo **correcto, completo, uniforme y polinómico en todo grafo** demostraría `P=NP`.

El procedimiento O2d demuestra un **tipo de cierre local acreditable** y puede reducir costo de tablas en subfamilias. Pero no evita que el grafo residual posea gran anchura, ni demuestra una cota uniforme sobre tablas o el costo de encontrar la secuencia de cierres. La **siguiente obligación** no es reinterpretar SAT: consiste en construir/testear una política de grafos que, al obtener testigos nuevos, actualice el mapa de dependencias y tenga una cota comprobable sobre su trabajo integral, incluidos falsadores sin diamantes.

No se igualan *radio ontológico*, *profundidad de comparaciones*, *rango algebraico*, *anchura de bolsa* o *tiempo de ejecución* sin derivación adicional. La semejanza puede orientar preguntas; solo los certificados acreditan una fusión.

## 8. Reproducción y genealogía

El ZIP contiene copias **sin cambios** de `laboratorio_grafos_o2.py` y `laboratorio_selector_dinamico_o2c.py`, con hashes SHA-256 y su paquete histórico original conservado en `upstream/`. Incluye 57 pruebas unitarias (también las de O2/O2c), controles exhaustivos DFS y metamórficos, tablas con semillas fijas, y un verificador de resultados semánticos que rechaza adulteraciones.

La cadena conceptual es **MF-46–MF-63B → O2b (comparación) → O2c (selector según pregunta) → E11–E25 (herencia, testigos y memoria) → E26/O2d (testigos acreditados de grafos y contabilidad de elección)**. No se reemplazan los documentos ni la versión maestra anterior.
