# Informe de auditoría — E25 y v3.4.2
**Fecha:** 15 de octubre de 2026. **Alcance:** edición auditada de laboratorio, no certificación externa por pares.

## Procedencia e integridad
- Edición v3.4.1 conservada íntegra en `historico/v3_4_1_original_frozen.zip`.
- `Programa_Relacional_v3_4_2_Edicion_Auditada_2026-10-15.zip`: `11783319` bytes, SHA-256 `5cae318c70f1240ec1a68678f25b32ad0ebb086695ef4ec88816ae06aa151e5f`.
- `E25_Fronteras_Conjuntas_Reproducible_2026-10-15.zip`: `15539` bytes, SHA-256 `c264a3a3e361b4b167ce69d9d2227ccaa2558daec493576b1fc79a1eebfbbd8b`.
- Desde el ZIP v3.4.2 extraído en una carpeta limpia: `verify_snapshot.py` comprobó 535 archivos; `verify_manifest.py` comprobó 514 archivos estáticos; cero errores.
- Integridad ZIP comprobada con `ZipFile.testzip()`.

## Hallazgo formal E25
1. Dos relaciones con idénticos marginales individuales pueden diferir al introducir una relación que compara las referencias conjuntamente. Contraejemplo de igualdad/distinción reproducido por código.
2. La proyección existencial sobre frontera B responde exactamente a todos los contextos definidos **solo** sobre B.
3. Permitir todos los contextos sobre B exige distinguir relaciones diferentes. Para b bits existen 2^(2^b) relaciones y una codificación fija universal requiere al menos 2^b bits.
4. Paridad par e impar coinciden en todas las proyecciones a subconjuntos propios; una pregunta de paridad total las distingue.
5. Los límites no implican dificultad para clases especiales: XOR admite descripción compacta y eliminación gaussiana.

## Evidencia ejecutada
- E25: 16 pruebas automatizadas pasadas.
- 256 relaciones ternarias; 32.640 pares distintos contrastados mediante contextos unitarios.
- 5.000 instancias aleatorias de proyección y respuesta contextual con semilla 25015.
- Paridades b=2,...,8: todas las proyecciones propias verificadas.
- 165 árboles aleatorios pequeños E24, con cambios de factores y hasta dos enlaces cruzados; comparados con oráculo radix-4 escrito sin reutilizar el oráculo E24.
- En extracción limpia, E11–E21 pasaron en una primera pasada interrumpida después de E21 por tiempo disponible, sin que se registraran fallos en esos comandos. E22–E25 se ejecutaron posteriormente por separado y pasaron, incluidas las regeneraciones de evidencias E22–E25.
- Controles adversariales `redteam_e22.py`, `redteam_e24.py`, `selftest_negative_evidence.py`: pasaron.

## Hallazgo de auditoría A2
La regeneración de E22 incluye `elapsed_seconds_observed`, que varía entre máquinas. La comparación estricta anterior de v3.4.1 trataba esos tiempos como discrepancia, aun con la misma respuesta matemática. La v3.4.2 ignora **únicamente ese campo de E22** en la comparación semántica, y conserva la regla E23 que ignora solo `wall_seconds`. Las demás diferencias, incluidos resultados, clases, estrategias, contadores y certificados, producen fallo. El original v3.4.1 permanece archivado sin modificación.

## Receta de reproducción
```bash
python3 scripts/verify_snapshot.py
python3 scripts/verify_manifest.py
python3 scripts/run_all.py --target E25 --experiments
python3 scripts/run_all.py --target E22 --experiments
python3 scripts/run_all.py --target E23 --experiments
python3 scripts/run_all.py --target E24 --experiments
python3 scripts/run_redteam.py
python3 scripts/verify_manifest.py
```

## Exclusiones explícitas
Este informe no demuestra la validez de las premisas ontológicas, originalidad de teoremas clásicos, límite inferior de tiempo para SAT, P=NP, Yang–Mills ni correspondencias físicas. Los ensayos son finitos y deben ser revisados por un equipo independiente antes de presentarlos como validación externa.
