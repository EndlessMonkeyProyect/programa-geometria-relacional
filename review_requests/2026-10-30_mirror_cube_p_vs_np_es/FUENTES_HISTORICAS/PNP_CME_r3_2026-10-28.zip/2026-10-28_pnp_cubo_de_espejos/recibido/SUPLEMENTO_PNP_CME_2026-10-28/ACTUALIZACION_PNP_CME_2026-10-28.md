# PGR — Actualización aditiva de P versus NP y la caja de espejos

**Programa de Geometría Relacional · Autoría del hilo: Le Matt Ansatz Di Ego**  
**Corte documental:** 28 de octubre de 2026.  
**Naturaleza:** reconstrucción crítica e integración aditiva; **no sustituye los originales ni afirma resolver P vs NP**.

## 0. Alcance, estados y jerarquía del programa

Orden de exposición: **lenguaje del pensamiento → ontología → definiciones de observación → teoremas → experimentos → hipótesis y falsadores → próximas operaciones**. Revisión sobre la edición ordenada del 24-oct, la Imagen Total 3.9, las contribuciones CME-001/002/003, O19–O22, O59–O60, N1, MF-27/52/86/97/99/106, CR-3/6, E25/26/28 y LAB-CONV v2, más discusiones conservadas y el repositorio público. El acceso a conversaciones históricas fue **indirecto por sus documentos de continuidad**; no se dispone de transcripciones íntegras de cada chat antiguo.

Marcas: **[O]** ontología, **[D]** definición, **[T]** derivado bajo hipótesis, **[E]** ensayo reproducido, **[F]** falsador, **[C]** condicional, **[A]** abierto.

## 1. Lenguaje y nacimiento de la pregunta

[O] La unidad puede reflexionarse y construir distinciones dentro de la totalidad. La diferencia precede a medirla; la comparación acredita relaciones; un cierre suficiente permite volver a usar lo resuelto como una referencia y un nuevo vínculo puede distinguir clases anteriormente comunes. **La novedad refina el lenguaje** sin convertir en falsa una respuesta anterior para su pregunta original. El múltiplo que normalizó conserva la proporción de la representación; no por ello controla tiempo de cómputo o identidad física.

La frase rectora en la rama P/NP es: «Cada número nuevo que aparece es un nodo de caminos para llegar a él como soluciones donde convergen estructuras». La formulación posterior exigió distinguir **coincidencia de valor**, **equivalencia contextual** y **convergencia estructural certificada**. No todo número cardinal identifica por sí solo una clase suficiente.

## 2. Los espejos: qué se probó, qué se corrigió

### 2.1 CME-001 — cierre de orientaciones frente a posiciones [T/E]

Las partes lineales de los espejos ortogonales ideales producen ocho patrones de signo en tres coordenadas; el ortoesquema cúbico estudiado produce 48 orientaciones. La reflexión entre planos paralelos produce posiciones virtuales infinitas, aun cuando las orientaciones sean finitas. Por tanto, **«ocho orientaciones» no significa «ocho imágenes espaciales»**. Los ensayos históricos contienen además una construcción de tetraedro regular con recuento de palabras de reflexión bajo hipótesis explícitas. Es imprescindible no identificar un cierre finito de orientaciones con un cierre espacial, óptico o computacional general.

### 2.2 O59 — órbita y firma plegada [T]

En una dimensión con paredes en 0 y L>0:

\[\mathcal O_L(p)=\{2nL\pm p:n\in\mathbb Z\},\quad \rho_L(x)=\operatorname{dist}(x,2L\mathbb Z).\]

Para el grupo generado por estas reflexiones, dos posiciones comparten órbita si y solo si comparten firma \(\rho_L\). Con tres ejes se componen tres firmas (con sus longitudes), cuando el contrato es separable. La firma es **suficiente para la pregunta de pertenencia a órbita**, no para una consulta arbitraria de posición, fase o historia. El número de imágenes es infinito; la representación de la clase no lo es.

### 2.3 CME-002 — tres regímenes, condición global [T/E/F]

En la familia triangular de grupos de reflexión \((2,3,k)\), la suma \(\tfrac12+\tfrac13+\tfrac1k\) es mayor que 1 para k=2..5, igual a 1 para k=6, y menor que 1 para k≥7. En el contrato correspondiente, esto clasifica grupo esférico finito, afín euclídeo e hiperbólico infinito, respectivamente. **«Sólo cierra hasta 5» vale para esta familia, no para todas las disposiciones:** el control \((2,2,k)\) es finito para cada k. La finitud de cada producto de dos generadores no prueba finitud del grupo generado por todos (control (2,3,7)). El origen de los ángulos \(\pi/2,\pi/3\) no fue demostrado desde una pared móvil sin hipótesis geométricas adicionales.

### 2.4 CME-003 — cuatro referencias y reflexión [T/E]

Cuatro vectores con coordenadas de paridad \((1,1,1),(1,-1,-1),(-1,1,-1),(-1,-1,1)\) en \(\mathbb R^3\) euclídeo. Los intercambios de pares se realizan por reflexiones con normales dadas por diferencias de vértices: su grupo es una representación de \(S_4\) de orden 24. Dos intercambios disjuntos producen producto de orden 2; dos con vértice compartido, orden 3 (ángulos agudos de planos \(\pi/2,\pi/3\)). Al agregar un cambio de signo coordenado, aparece extensión de orden 48 (tipo \(B_3\)), con productos de orden 4. **Ojo:** en el grupo de orden 24 hay elementos de orden 4 que son transformaciones de orientación inversa; no denominarlos indiscriminadamente «rotaciones». Los operadores originales usan métrica y cuatro referencias como premisas, no las derivan de la ontología.

En la actualización presente se reejecutaron satisfactoriamente `cme003_cuatro_referencias.py`, `cme002_angulos_e_identidades.py`, `comprobacion_regla_del_bit.py` y `verificar_o59.py` (registros en `verificacion/`). La teoría de reflexiones utilizada es clásica; su integración ontológica es el aporte interpretativo del programa.

## 3. Puente formal entre reflexión y cierre computacional

### T-PN-CME-1 — Descenso de una dinámica a clases de simetría [T; proposición elemental]

Sea un grupo \(G\) actuando en un conjunto \(X\), su proyección de órbitas \(\pi:X\to X/G\), un observable \(Q:X\to Y\) y una transición \(F:X\to X\). Si \(Q(gx)=Q(x)\) y \(F(gx)=gF(x)\) para todo \(g\in G\), entonces existen mapas bien definidos \(\bar Q:X/G\to Y\) y \(\bar F:X/G\to X/G\) tales que

\[Q=\bar Q\circ\pi,\qquad \pi\circ F=\bar F\circ\pi.\]

**Demostración.** Si \(\pi(x)=\pi(y)\), hay \(g\) con \(y=gx\). Por invariancia, \(Q(y)=Q(x)\); por equivariancia, \(F(y)=F(gx)=gF(x)\), de modo que sus imágenes permanecen en la misma órbita. Definimos \(\bar Q([x])=Q(x)\) y \(\bar F([x])=[F(x)]\). Ninguno depende del representante. ∎

La equivariancia es **suficiente**, no necesaria: el criterio necesario y suficiente para \(F\) es sólo que preserve la relación de equivalencia. Si cambian las reglas, la firma anterior puede ser insuficiente.

### T-PN-CME-2 — Criterio exacto de actualización de una firma [T]

Para una firma \(\Phi:X\to S\) y transición \(F:X\to X\), existe \(\widehat F\) sobre \(\Phi(X)\) con \(\Phi\circ F=\widehat F\circ\Phi\) si y sólo si

\[\Phi(x)=\Phi(y)\Rightarrow\Phi(F(x))=\Phi(F(y)).\]

**Prueba.** Necesidad por sustitución. Suficiencia: definir \(\widehat F(\Phi(x))=\Phi(F(x))\), bien definido por la implicación. ∎

### F-PN-CME-1 — Cambiar la pared rompe la suficiencia de una firma [F/E]

Tome \(x=1/4\), \(y=7/4\), \(L=1\). Se cumple \(\rho_1(x)=\rho_1(y)=1/4\). Al cambiar a \(L'=3/2\), sin cambiar las dos posiciones:

\[\rho_{3/2}(x)=1/4,\qquad\rho_{3/2}(y)=5/4.\]

Por tanto, **no existe en todas las posiciones un mapa \(T\) con \(\rho_{3/2}=T\circ\rho_1\)**. Para reconstruir la nueva comparación hacen falta más datos de rama/procedencia, o refinamiento explícito. El mecanismo de novedad existe aquí como ejemplo concreto, pero **no es gratis**. La firma ampliada \((\rho_1,\rho_{3/2})\) sí conserva ambas respuestas, sin demostrar una cota uniforme de tamaño ante sucesivos cambios.

### F-PN-CME-2 — Una operación no equivalente rompe el cociente [F/E]

Con los mismos \(x,y,L=1\), tras desplazar ambas posiciones \(t=1/4\): \(\rho_1(x+t)=1/2\) y \(\rho_1(y+t)=0\). Un desplazamiento arbitrario no desciende necesariamente al cociente de la reflexión; reflexiones que ya son elementos de su grupo sí preservan la firma.

### T-PN-CME-3 — El cociente de colores no vence una barrera exponencial [T/E]

En 3-coloración sin colores absolutos fijados, la permutación global \(S_3\) actúa sobre las asignaciones, y las restricciones de desigualdad son invariantes. Para una frontera de k posiciones, los patrones de igualdad bajo esa acción son \(P_3(k)=\sum_{j=1}^{\min(3,k)}\big\{\!\!\begin{smallmatrix}k\\j\end{smallmatrix}\!\!\big\}\), con números de Stirling. Para k=8 hay 1094 patrones frente a 6561 asignaciones; para k grande la mejora es de factor constante cercano a 6, no una cota polinómica. Si se exige que un vértice tenga específicamente color 0, la simetría global de renombramiento deja de respetar la pregunta. Un grupo finito de 24/48 transformaciones de CME-003 no sustituye automáticamente las restricciones de 3-coloración de un grafo arbitrario.

### F-PN-CME-3 — Cardinalidad e interfaces parciales insuficientes [F/E]

Las relaciones de paridad ternaria par/impar poseen cuatro soluciones cada una, todas sus proyecciones binarias coinciden, y su intersección es vacía. El par de relaciones de frontera \(A=\{a\neq b\}\) y \(D=\{b\neq c\}\) en tres colores posee cardinalidad 18 en ambos casos, pero la nueva pregunta \(K=\{a\neq b\}\) deja 18 vs. 12 casos. Los testigos de E25 y LAB-CONV siguen vigentes: **valor, radio o correlaciones por pares no determinan la respuesta de cada relación futura**.

## 4. P versus NP: estado correcto después de N1 y LAB-CONV v2

**Establecido bajo contratos:** MF-86 normalización contextual idempotente; MF-97 equivalencia ante continuaciones; MF-99 composición; CR-6 firma existencial sobre frontera; E25 contraejemplo ternario; E26 fusiones por diamante con certificado; LAB-CONV v2 eliminación exacta, simetría y obstrucciones; N1-A/N1-B límites para las variantes de eliminación por tablas O2/O2c. El informe del 24-oct vuelve a ejecutar 1338 controles de grafos y clasifica coNP-completo el problema de igualdad global forzada de dos vértices bajo el contrato del laboratorio.

**N1-A:** la contabilidad del motor sin poda se gobierna por la anchura de las tablas de frontera; la elección de orden por sí sola no cambia esa familia de limitaciones. **N1-B:** toda corrida negativa del motor extensional O2c, cuando sólo cambia la prioridad de eliminación, puede traducirse a una refutación por resolución. La fuente demostraba una cota de \(\le(3/2)\cdot\texttt{total_candidates}\) pasos de resolución bajo su codificación y convenio de conteo. Esto transfiere cotas inferiores de resolución de familias correctamente emparejadas a **ese motor**, no a toda posible operación relacional. Son resultados históricos del programa, no teoremas nuevos de este suplemento.

**Resultado de LAB-CONV v2:** 1338 grafos de control con coincidencia exacta en la reproducción actual de `verificar_exhaustivo.py` (64 de orden 4, 1024 de orden 5 y 250 de orden 6), además de instancias con y sin cierres locales. Reconocer una fusión *globalmente forzada* puede esconder una decisión coNP-completa. Un mero selector de la siguiente variable del motor ya delimitado por N1 no constituye vía nueva hacia P=NP.

**Obligación abierta:** un operador uniforme, causal, correcto y de costo polinómico total que produzca y actualice firmas contextuales operables para 3-coloración de grafos arbitrarios sin presuponer las respuestas. Debe contabilizar descubrimiento de cierres, comprobación, construcción, unión, proyección, normalización, refino, almacenamiento, consultas y resolución residual. Probar ese procedimiento para 3-coloración demostraría P=NP; un fallo del operador no demostraría P≠NP.

## 5. Contrato de la siguiente operación: otra clase de representación, no otro orden de tablas

Buscamos una `Cápsula` **operable** (MF-27/MF-52):

\[\mathfrak K=(\text{Representar},\text{Comparar},\text{Incorporar},\text{Refinar},\text{Unir},\text{Proyectar},\text{Vacío},\text{Certificar}).\]

Entrada: grafo simple con restricciones 3-color y preguntas exteriores declaradas. Salida: respuesta exacta y su certificado, o cápsula reducible con interfaz suficiente. La nueva clase debe permitir operaciones verificables con costos de bits explícitos; no basta afirmar que la cápsula tiene una fórmula corta. Formalizar sobre familias que eviten diamantes y sean de anchura creciente, incluyendo casos positivos y negativos. Exigir demostración de cómo escapa **expresivamente** a las tablas de O2/O2c, o bien reconocer que N1 vuelve a aplicar. Probar separadamente calidad de compresión, costo de encontrar equivalencias y cantidad de clases necesarias.

### Secuencia de ensayos ya convenida

1. Copiar los verificadores originales sin editarlos y repetir controles conocidos antes de cambios.
2. Usar transformaciones de espejo para verificar invariancia de la firma bajo el grupo, y falsadores cuando la pregunta nueva no sea invariante.
3. Ensayar parejas de familias de grafos de elevada anchura y con estadísticas locales semejantes, separando SAT/UNSAT y costos de selección/consulta.
4. En toda transición mantener `referencia anterior`, `novedad`, `interfaz previa`, `interfaz nueva`, `testigo`, `costo`, `condición de falsación`.
5. Evitar expresiones «múltiplo nuevo = independencia computacional» hasta demostrar un mapa operativo; la regla aritmética \(h/N=(ph)/(pN)\) no cierra el costo de 3-coloración.

## 6. Estado de repositorio y procedencia

El repositorio público `https://github.com/EndlessMonkeyProyect/programa-geometria-relacional` presenta la edición base del 24-oct y el complemento de Yang–Mills del 27-oct en su README consultado. CME-003 tiene una solicitud pública de revisión en `https://github.com/EndlessMonkeyProyect/programa-geometria-relacional/issues/1`, que aparece **cerrada el 25-oct**, con aclaración explícita de que las reproducciones locales no son revisión externa. **Este suplemento no está publicado en GitHub**, y no se afirma haber recibido evaluación matemática independiente ni tener transcripciones literales de todos los chats.

Las fuentes congeladas de esta entrega se extrajeron sin modificaciones del ZIP ordenado del 24-oct y se incluyen junto con un manifiesto de SHA-256. Los verificadores reportados como reejecutados figuran nominalmente en `verificacion/` con estado y salida. CME-001 no se rotula como reejecutado si no tiene registro nuevo de ejecución. Las pruebas de reflexión/combinatoria y las barreras clásicas no se reclaman como descubrimientos inéditos; la propuesta original aquí es su encadenamiento desde el hilo del programa y sus preguntas de investigación.

## 7. Estado final

- **[T]** Firmas de órbita y compresión bajo simetrías para preguntas invariantes.
- **[T]** Descenso de acciones compatibles a un cociente y criterio exacto de suficiencia dinámica.
- **[F]** La pared móvil y operaciones nuevas pueden romper la suficiencia de la firma antigua.
- **[E]** Verificadores históricos CME-002, CME-003, O59, regla del bit y LAB-CONV v2 reproducidos; 7 controles nuevos de puente exacto.
- **[A]** No hay regla universal de transformación PNP derivada del cubo, ni cota polinómica total para grafos generales.

**Punto preciso para continuar:** construir y someter a prueba un **refinador de cierre con procedencia** que incorpore preguntas nuevas sin reexpandir indebidamente las clases, bajo una arquitectura no reducida a elegir el orden de las mismas tablas de eliminación.
