#!/usr/bin/env python3
"""Puente CME ↔ PNP. Controles nuevos, exactos, sin dependencias externas.
No demuestra P=NP ni separación de clases.
"""
import itertools, json, hashlib
from fractions import Fraction as F
from pathlib import Path


def rho(x, L):
    """Firma plegada de la órbita generada por dos espejos paralelos 0,L."""
    x, L = F(x), F(L)
    assert L > 0
    r = x % (2 * L)
    return min(r, 2 * L - r)


def canonical_colors(seq):
    renaming = {}
    return tuple(renaming.setdefault(x, len(renaming)) for x in seq)


def count_3_coloring(n, edges):
    return sum(all(x[a] != x[b] for a, b in edges)
               for x in itertools.product(range(3), repeat=n))


def pairs_projection(states, i, j):
    return {(row[i], row[j]) for row in states}


def verify():
    result = {}
    # E1: el mismo cierre del espejo para L=1 puede abrirse al correr la pared.
    x, y = F(1, 4), F(7, 4)
    assert rho(x, 1) == rho(y, 1) == F(1, 4)
    assert rho(x, F(3, 2)) == F(1, 4)
    assert rho(y, F(3, 2)) == F(5, 4)
    result['pared_movil'] = {
        'x': str(x), 'y': str(y), 'firma_L1': str(rho(x, 1)),
        'firmas_L3_2': [str(rho(x, F(3, 2))), str(rho(y, F(3, 2)))],
        'conclusion': 'novedad contextual: la firma antigua deja de ser suficiente'
    }
    # E2: un desplazamiento que no respeta las órbitas no desciende al cociente.
    t = F(1, 4)
    assert rho(x+t, 1) != rho(y+t, 1)
    # Pero una reflexión de la pared sí respeta la firma.
    assert all(rho(2 - a, 1) == rho(a, 1) for a in [F(k, 8) for k in range(-40, 41)])
    result['factorizacion_dinamica'] = {
        'desplazamiento': str(t), 'nueva_firma_x': str(rho(x+t, 1)),
        'nueva_firma_y': str(rho(y+t, 1)),
        'reflexion_en_pared_conserva_firma_en_81_casos': True
    }
    # E3: la simetría S3 de colores reduce clases, no deja de ser exponencial.
    vals = {}
    for n in (1,2,3,4,5,6,7,8):
        vals[n] = len({canonical_colors(tup) for tup in itertools.product(range(3), repeat=n)})
    assert vals[8] == 1094
    # Una condición que ancla el color rompe el cociente anterior:
    assert canonical_colors((0,)) == canonical_colors((1,))
    assert ((0,)[0] == 0) != ((1,)[0] == 0)
    result['orbitas_S3'] = {'clases_por_longitud':vals, 'etiquetados_n8':3**8,
                           'canon_n8':vals[8], 'anclaje_rompe_simetria':True}
    # E4: E25: las paridades opuestas tienen igual proyección sobre pares.
    states = list(itertools.product((0, 1), repeat=3))
    E = {z for z in states if sum(z) % 2 == 0}
    O = {z for z in states if sum(z) % 2 == 1}
    assert len(E) == len(O) == 4 and not E.intersection(O)
    assert all(pairs_projection(E, i, j) == pairs_projection(O,i,j)
               for i,j in itertools.combinations(range(3), 2))
    result['paridad_ternaria']={'mismo_tamano':4, 'marginales_pares_iguales':True,
                               'interseccion_vacia':True}
    # E5: certificado local de diamante para 3-coloración.
    edges = {(0,1),(0,2),(0,3),(1,2),(1,3)}
    assert count_3_coloring(4,edges)==6
    assert count_3_coloring(4,edges|{(2,3)})==0
    result['diamante']={'coloraciones_antes':6, 'coloraciones_con_arista_uv':0,
                        'contexto':'tres colores sin anclajes'}
    # E6: un mismo valor de cardinal no determina la firma de frontera.
    A = {z for z in itertools.product(range(3), repeat=3) if z[0] != z[1]}
    D = {z for z in itertools.product(range(3), repeat=3) if z[1] != z[2]}
    K = {z for z in itertools.product(range(3), repeat=3) if z[0] != z[1]}
    assert len(A)==len(D)==18 and len(A&K)==18 and len(D&K)==12
    result['mismo_cardinal_distinto_contexto']={'ambos_tamano':18,'A_con_K':18,'D_con_K':12}
    # E7: relación aritmética preservada, sin consecuencia de costos algorítmicos.
    n,p,h=F(6),F(5),F(2)
    assert (h/n)==(p*h/(p*n))
    result['normalizador']={'antes':'2/6','despues':'10/30','valor_conservado':True}
    result['conclusion']='Todos los controles son exactos y finitos; no infieren complejidad universal.'
    return result

if __name__=='__main__':
    result=verify()
    output=Path(__file__).resolve().parent/'resultados_puente.json'
    output.write_text(json.dumps(result, ensure_ascii=False, indent=2, sort_keys=True)+'\n',encoding='utf-8')
    print('PUENTE CME-PNP: PASS (7 familias de pruebas exactas)')
    print('Resultados:',output)
