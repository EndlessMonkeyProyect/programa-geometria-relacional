# Matriz de estado PNP ↔ CME · 2026-10-28 · revisada

Versión revisada de la [matriz recibida](recibido/SUPLEMENTO_PNP_CME_2026-10-28/MATRIZ_DE_RESULTADOS.md). Las filas nuevas o cambiadas llevan ✱.

**Niveles de prueba**, de más fuerte a más débil:
- **Teorema conocido:** resultado de la literatura, citado.
- **Teorema del programa:** demostrado en el programa, bajo el contrato que se indica.
- **Prueba computacional exacta y finita:** acredita los casos calculados bajo la implementación, no un enunciado general.
- **Analogía orientadora:** una imagen que da la forma de una pregunta, sin valor de prueba.
- **Abierto** o **Propuesta**.

Un falsador es un contraejemplo exacto: se marca con su nivel y con la palabra «falsador».

## Resultados recibidos

| ID | Enunciado delimitado | Nivel | Prueba o fuente | Advertencia |
|---|---|---|---|---|
| CME-001 ✱ | Cubo ideal: 8 partes lineales; ortoesquema: 48; tetraedro regular: 2·3ᴸ − 1, nunca cierra | Teorema conocido; prueba computacional hasta L = 12 | CME-001; Świerczkowski 1959; Dekker 1959 | Las posiciones de las imágenes son infinitas |
| O59 | Firma de órbita de espejos en 0 y L | Teorema conocido (elemental); prueba computacional | `verificar_o59.py` | No responde cualquier consulta exterior |
| CME-002 | Tricotomía de (2,3,k): cierra en k = 2…5, afín en 6, se abre desde 7 | Teorema conocido; prueba computacional hasta L = 16 | `cme002_angulos_e_identidades.py`; Coxeter 1934 | No generalizar a todo grupo de Coxeter |
| CME-003 ✱ | Intercambios de cuatro referencias: 24; con el bit: 48 | Teorema conocido; prueba computacional | `cme003_cuatro_referencias.py` | Hipótesis geométricas explícitas; los elementos de orden 4 del grupo de 24 son rotorreflexiones, no giros |
| PN-CME-T1 | Cociente por un grupo y dinámica equivariante | Teorema del programa (elemental) | §4 | Criterio suficiente |
| PN-CME-T2 | Factorización si y solo si se preservan las clases | Teorema del programa (elemental) | §4 | No promete cómputo económico |
| PN-CME-T3 ✱ | El cociente por un grupo fijo G ahorra a lo sumo \|G\| | Teorema (elemental); prueba computacional | §4; puente P3 y C2 | Factor constante |
| PN-CME-F1 | Cambiar L separa puntos de una misma órbita vieja | Falsador; prueba computacional | puente P1 | La diferencia nueva exige refinar; no favorece P = NP ni P ≠ NP |
| PN-CME-F2 | Un desplazamiento arbitrario no respeta el cociente | Falsador; prueba computacional | puente P2 | No toda operación del marco es simetría |
| E25 ✱ | Las proyecciones binarias no determinan la restricción ternaria | Teorema; falsador; prueba computacional | E25; puente P4 y P6 (testigo no degenerado K₂) | Cardinal y radio no bastan |
| E26 | El diamante certifica una igualdad en 3-coloración | Teorema conocido; prueba computacional | E26; puente P5 | No detecta todos los cierres globales |
| LAB-CONV-v2 | Eliminación por fronteras; 1338 controles | Teorema del programa; prueba computacional | `verificar_exhaustivo.py` | El ancho crece; la simetría S₃ ahorra un factor constante |
| N1-A/B | Barreras de los motores de tablas O2/O2c | Teorema del programa, condicionado al motor | PISO, N1-B | No implica P ≠ NP |
| R-01 | Normalización aritmética de múltiplos | Teorema (elemental) | R-01; puente P7 (ilustración) | No equiparar con costo computacional |
| Hipótesis central | Refinador universal económico para 3-coloración | Abierto | Laboratorio futuro | Implicaría P = NP si se demostrara |
| P = NP / P ≠ NP | Resolución general | Abierto | Ninguna | No reclamada |

## Imagen del cubo (nuevas) ✱

| ID | Enunciado delimitado | Nivel | Prueba o fuente | Advertencia |
|---|---|---|---|---|
| C1 | (2,3,k): cierra en 48 y 120, se repite en k = 6 (+12 cada 5 pasos), se abre en k = 7 (razón → Lehmer). Cada par de espejos cierra en todos los casos. Las esferas de k = 6 y k = 7 coinciden hasta L = 5 | Prueba computacional exacta (tercer cálculo, coincide con CME-002); teorema conocido de crecimiento (de la Harpe 1987) | puente C1 | Los dos grupos difieren en un par (orden 6 frente a 7). Leer los regímenes como costo de un algoritmo es analogía orientadora |
| C2 | Con el grupo del cubo: 6561 → 267 órbitas (48) y 58 (288); 114 coloraciones propias → 15 y 4 | Prueba computacional exacta (conteo directo y Burnside) | puente C2 | El ahorro nunca supera \|G\| |
| C3 | Con 2 colores la arista es la involución x ↦ 1 − x y un ciclo cierra si y solo si es par; con 3, componer dos aristas da las 9 parejas | Prueba computacional exacta | puente C3 | — |
| C4 | Operaciones ternarias que conservan «distinto»: 16 con 2 colores (incluye mayoría y paridad); 18 con 3: proyecciones seguidas de permutaciones de colores, ninguna WNU | Prueba computacional exacta; teorema conocido (Greenwell–Lovász 1974) | puente C4 | Habla de la plantilla fija K₃, no de los cierres contextuales de una instancia ni de algoritmos construidos de otra manera; la dicotomía de CSP no decide P frente a NP |
| C5 | El cubo es bipartito y sus clases son los dos tetraedros de O19; K₄ no es bipartito | Prueba computacional exacta; teorema conocido (Hell–Nešetřil 1990) | puente C5 | — |
| C6 | Diamante: intercambiar las puntas es simetría; puntas iguales en 6/6 coloraciones con 3 colores y en 24/48 con 4 | Prueba computacional exacta | puente C6; E26 | — |
| C7 | Paridad en las aristas del cubo: Gauss decide las 256 cargas; resoluble si y solo si la carga total es par; 32 soluciones | Prueba computacional exacta; teorema conocido (Urquhart 1987) | puente C7 | El álgebra escapa a la resolución en paridad, no en 3 colores (Lauria–Nordström 2017) |
| Imagen | Cierra / se repite / se abre como constante / polinómico / exponencial en algoritmos | Analogía orientadora | §3 | El espacio de búsqueda no es un grupo de Coxeter |
| Mapa de barreras | Clasificar cada cápsula propuesta por el sistema de prueba que la simula y la cota que hereda | Propuesta | §6.1 | Decide el autor |
