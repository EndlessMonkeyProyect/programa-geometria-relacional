# P frente a NP y el cubo de espejos — complemento del 28 de octubre de 2026

**Programa de Geometría Relacional · Le Matt Ansatz Di Ego**

Este complemento integra la actualización de la rama P/NP con el laboratorio del cubo de espejos, revisada. Lee los ejemplos del cubo como **imagen tangible** del problema: un recinto que cierra, se repite o se abre según cómo se relacionan sus espejos. Se agrega a la edición del 24 de octubre sin modificar nada de ella. [Read this in English](READ_FIRST.en.md).

**Estatus.** No prueba P = NP ni P ≠ NP. Reúne lo establecido bajo contrato, los falsadores y lo que sigue abierto. Las correspondencias entre el cubo y la complejidad que son teoremas conocidos se citan como tales; las demás se marcan como imagen.

## Contenido

| Ruta | Qué contiene |
|---|---|
| [`ACTUALIZACION_PNP_CME_2026-10-28_revisada.md`](ACTUALIZACION_PNP_CME_2026-10-28_revisada.md) | El documento principal. La sección 3 es la imagen del cubo |
| [`ACTUALIZACION_PNP_CME_2026-10-28_revisada.en.md`](ACTUALIZACION_PNP_CME_2026-10-28_revisada.en.md) | Traducción al inglés; la versión de referencia es la española |
| [`MATRIZ_DE_RESULTADOS_revisada.md`](MATRIZ_DE_RESULTADOS_revisada.md) | Estado y fuente de cada afirmación, incluidas C1–C7 |
| [`GRAFO_DE_RELACIONES_revisado.md`](GRAFO_DE_RELACIONES_revisado.md) | Genealogía de resultados con la capa de la imagen del cubo |
| [`REVISION_2026-10-28.md`](REVISION_2026-10-28.md) | Qué se comprobó, qué se corrigió, qué se agregó y dónde se apartó la integración de las instrucciones |
| [`laboratorio/`](laboratorio/puente_cme_pnp_revisado.py) | Puente revisado: los 7 controles recibidos (P1–P7), etiquetados, y 7 nuevos de la imagen del cubo (C1–C7) |
| [`reproducir_todo.py`](reproducir_todo.py) | Integridad, todos los verificadores en una copia temporal y comparación byte a byte |
| [`verificacion/`](verificacion/registro_reproduccion.json) | Registro de la reproducción de esta entrega y [consulta del issue #1 a la API de GitHub](verificacion/issue1_github_api.json) |
| [`recibido/`](recibido/SUPLEMENTO_PNP_CME_2026-10-28/README.md) | El suplemento tal como se recibió, sin cambios, salvo las 49 fuentes congeladas, idénticas a las de la edición del 24-oct ([lista](recibido/DUPLICADOS_RETIRADOS.csv)) |
| `MANIFIESTO_SHA256.txt` | Huella de cada archivo de este complemento, salvo el registro de verificación, que `--registrar` reescribe |

## Orden de lectura

1. **La imagen del cubo**, sección 3 del documento principal. Es la entrada: cada ejemplo del laboratorio, qué corresponde en 3-coloración y qué no dice.
2. **El puente formal y el estado de P/NP**, secciones 4 y 5.
3. **El contrato de la siguiente operación**, sección 6, con la propuesta del mapa de barreras (6.1), que el autor decide si adopta.
4. **La matriz**, para el estado de cada afirmación.

## Las fuentes, en la edición del 24 de octubre

- **Cubo de espejos:**
  - [laboratorio](../2026-10-24/02_REALIZACIONES/01_cubo_de_espejos/02_CUBO_DE_ESPEJOS.es.md);
  - [CME-001](../2026-10-24/02_REALIZACIONES/01_cubo_de_espejos/CME-001_cierre_por_reflexion/CME-001_Cierre_por_reflexion.md), [CME-002](../2026-10-24/02_REALIZACIONES/01_cubo_de_espejos/CME-002_pared_que_se_corre/CME-002_Pared_que_se_corre.md) y [CME-003](../2026-10-24/02_REALIZACIONES/01_cubo_de_espejos/CME-003_de_las_cuatro_referencias_a_los_angulos/CME-003_De_las_cuatro_referencias_a_los_angulos.md);
  - [O59](../2026-10-24/02_REALIZACIONES/01_cubo_de_espejos/O59_orbita_y_firma_plegada/O59_AUTORREFERENCIA_Y_SECTORES.es.md) y [O22](../2026-10-24/02_REALIZACIONES/01_cubo_de_espejos/geometria_O19_O22/O22/O22_CONTINUIDAD_Relleno_Y_FOCO.es.md).
- **Rama P/NP:**
  - [LAB-CONV v2](../2026-10-24/03_RAMAS/p_vs_np/VIGENTE_LAB_CONV_V2/LAB_CONV_V2_NODOS_Y_FRONTERAS.md);
  - [revisión del 24-oct](../2026-10-24/03_RAMAS/p_vs_np/revision_2026-10-24/README.md);
  - la barrera N1: [PISO DEL CAMINO](../2026-10-24/01_HILO/fuentes/06_hilo_del_dos/v2_8/docs/PISO_DEL_CAMINO_v2_7.md) y [N1-B](../2026-10-24/01_HILO/fuentes/06_hilo_del_dos/v2_8/docs/N1_B_CERTIFICADOS_Y_PRIORIDAD_v2_8.md).

## Reproducción

**Mientras el complemento no esté en `main`**, se aplica sobre una copia del repositorio, que ya trae la edición `2026-10-24/`:

    git clone https://github.com/EndlessMonkeyProyect/programa-geometria-relacional.git
    cd programa-geometria-relacional
    git am Complemento_2026-10-28_PNP_Cubo_de_Espejos_r3.patch   # o descomprimir el ZIP en esta carpeta
    cd 2026-10-28_pnp_cubo_de_espejos

**Una vez publicado**, basta clonar el repositorio y entrar en `2026-10-28_pnp_cubo_de_espejos/`. En los dos casos, después:

    pip install -r requirements.txt            # numpy y sympy; solo los usan CME-001, CME-002 y la regla del bit
    python3 reproducir_todo.py                 # todos los verificadores
    python3 reproducir_todo.py --rapido        # omite CME-001 y CME-002, los más pesados
    python3 reproducir_todo.py --limite 120    # corta cada verificador a los 120 s
    python3 reproducir_todo.py --registrar     # además reescribe verificacion/registro_reproduccion.json

**El complemento se reproduce dentro del repositorio completo.** El script lee la edición hermana `2026-10-24/`; el ZIP del complemento suelto no basta. La corrida completa tardó unos 35 segundos en el equipo registrado en `verificacion/`, pero en otros equipos puede tardar bastante más: CME-001 enumera más de un millón de orientaciones.

**Códigos de salida.** 0 si todo pasa y no se omitió nada; 1 si algo falla; 2 si algo quedó sin comprobar. Con `--rapido` el resumen dice INCOMPLETO y el código es 2 aunque todo lo ejecutado pase, porque los dos verificadores pesados se omiten a propósito.

El script hace tres cosas:
1. **Integridad.** Comprueba el manifiesto de este complemento y la procedencia del suplemento recibido. Las fuentes congeladas se comprueban contra sus copias en `2026-10-24/`.
2. **Verificación.** Corre cada verificador en una copia temporal. Nunca se ejecutan en su sitio, porque varios reescriben sus resultados.
3. **Comparación.** Exige que cada resultado regenerado sea idéntico byte a byte al guardado.

| Verificador | Resultado en esta entrega |
|---|---|
| CME-001, CME-002, regla del bit, CME-003, O59, O22 | PASS; resultados idénticos a los guardados |
| LAB-CONV v2: laboratorio y exhaustivo (1338 grafos) | PASS; resultados idénticos |
| Escalado del motor (revisión 24-oct) | PASS |
| Puente recibido (7 controles) y puente revisado (P1–P7, C1–C7) | PASS; resultados idénticos |

Entorno y tiempos: `verificacion/registro_reproduccion.json`. Los tiempos son datos de la ejecución, no evidencia de complejidad.
