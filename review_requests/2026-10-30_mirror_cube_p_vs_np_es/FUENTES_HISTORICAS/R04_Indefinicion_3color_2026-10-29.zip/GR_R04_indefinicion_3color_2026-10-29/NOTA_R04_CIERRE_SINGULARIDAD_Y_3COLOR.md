# R–04 · Punto de indefinición, cierre y contraejemplos en 3-coloración

**Programa de Geometría Relacional · 29 de octubre de 2026.**  
**Estado:** resultados matemáticos [T], pruebas computacionales finitas [E], delimitaciones [A]. Complemento propuesto: no modifica R–03, MF–97, CR–6, E25, E26, N1 ni el suplemento revisado del 28 de octubre.

## 1. Hilo de lenguaje antes de la complejidad

Conservar la distinción del autor: la **singularidad** parte de la incertidumbre **en el punto donde las condiciones se indefinen**; el **radio** se introduce para expresar el alcance de esa incertidumbre; el **grado de un polinomio** describe un exponente de costo de cálculo bajo un algoritmo concreto, no constituye por sí mismo ni radio ni singularidad.

El ensayo operacional de R–03 considera referencia `π`, punto `s`, fibra `F_s` y consulta `q`:

- **Indefinición**: `F_s ≠ ∅` y `|q(F_s)| ≥ 2`: hay condiciones posibles que coinciden en el punto de referencia sin determinar una respuesta única.
- **Determinación**: `F_s ≠ ∅` y `|q(F_s)| = 1`: la consulta queda definida; pueden persistir otras posibilidades o preguntas.
- **Incompatibilidad**: `F_s = ∅`: las condiciones exigidas no tienen realización conjunta. No denominar singularidad a toda contradicción; no atribuir a la singularidad un significado físico sin un puente adicional.

Estas son **definiciones operacionales de prueba**, no una sustitución de la ontología ni una identificación con singularidades de análisis matemático.

## 2. Control W5: transición entre los tres estados [T/E]

Construir cinco vértices `0,1,2,3,4`, un centro `5`, y exigir colores distintos para cada arista centro–anillo. Incorporar las aristas consecutivas del anillo una a una. Preguntar `q: color(0)=color(4)`.

| Restricciones del anillo | Respuesta a q | Factibilidad |
|---|---|---|
| Cero a tres aristas del camino | `INDEFINIDO` (ambas respuestas se realizan) | Sí |
| Cuatro aristas del camino `0-1-2-3-4` | `IGUALES` | Sí |
| Se agrega `4-0` | `VACÍO` | No |

**Prueba.** El centro usa un color. Los cinco vértices externos deben usar únicamente los otros dos. Un camino de cuatro aristas alterna esos colores y obliga a igualar sus extremos. Cerrar el ciclo exige que los mismos extremos difieran: contradicción. Para menos de cuatro aristas, los dos extremos no están conectados entre sí por el camino declarado, así que existen extensiones con ambas respuestas. ∎

La regla de **diamante** (E26) contrae vecinos comunes de un par adyacente. Aplicada repetidamente a las ruedas impares `W_{2t+1}` produce una contradicción. Para cualquier rueda impar, la demostración anterior (alternancia de dos colores en ciclo impar) es un certificado estructural corto: no hace falta abrir las `3^n` asignaciones.

## 3. Familia infinita sin diamantes: M(C_{2t+1}) [T]

Para un grafo `G` con vértices `v_i`, su construcción de Mycielski `M(G)` contiene cada vértice original `v_i`, una copia `u_i` y un vértice nuevo `w`. Conserva las aristas originales, conecta `u_i` con todo vecino original de `v_i`, y conecta `w` con todos los `u_i`. No hay aristas entre copias `u_i`.

**Proposición.** Para todo ciclo impar `C_r`, con `r ≥ 5`, el grafo `M(C_r)`:

1. No contiene triángulos ni diamantes.
2. No es 3-coloreable.
3. Sí es 3-coloreable tras quitar **cualquier** vértice. En consecuencia, todos sus subgrafos inducidos propios son 3-coloreables.

**Demostración de 1.** El ciclo `C_r` no tiene triángulos. Una terna original–original–copia formaría un triángulo solo si dos vecinos de un mismo vértice del ciclo fueran adyacentes, lo que no ocurre para `r≥5`. El vértice `w` solo está conectado a copias y no hay aristas entre copias. Un diamante incluye al menos un triángulo, luego tampoco existe. ∎

**Demostración de 2.** Supongamos una 3-coloración de `M(C_r)`, con `w` de color 2. Todas las copias `u_i` tienen color 0 o 1. Recoloramos cada vértice original `v_i` que tenía color 2 con el color de su copia `u_i`; los otros originales conservan su color. Si una arista original `v_iv_j` tenía un extremo con color 2, la copia correspondiente está conectada al otro extremo y no puede tomar su color. No puede haber ambos extremos originalmente de color 2, pues eran adyacentes. Obtenemos así una 2-coloración del ciclo impar, imposible. ∎

**Demostración de 3.** Se proporcionan construcciones tras borrar cada clase de vértice:

- Al borrar `w`, 3-colorear el ciclo original y asignar a cada `u_i` el color de `v_i`; las aristas entre copia y vecinos originales siguen respetadas.
- Al borrar un original `v_i`, los originales restantes forman un camino, que se 2-colorea con 0 y 1. Dar a `w` el color 0. Cada copia `u_j` puede recibir 1 o 2 evitando el color de sus vecinos originales: para `j=i` los dos vecinos del camino pueden ser 0 y 1, y se elige 2; para los demás los vecinos visibles son iguales (a distancia dos en el camino) o queda uno solo, así que una de 1 o 2 sirve.
- Al borrar una copia `u_i`, asignar 2 al original `v_i` y a `w`, y alternar 0,1 sobre el camino de originales restantes. Para cada copia restante `u_j`, sus vecinos originales tienen, descontando a lo sumo un vecino de color 2, un único color entre 0 y 1; asignar el otro. Como cada copia es adyacente a `w`, no se asigna 2 a ninguna copia.

En todos los casos se construye una 3-coloración. Cualquier subgrafo inducido propio está contenido en un grafo obtenido borrando por lo menos un vértice; por restricción, también es 3-coloreable. ∎

**Consecuencia delimitada.** No existe un tamaño de ventana de vértices **constante** cuyo ensayo de 3-colorabilidad de todos los subgrafos inducidos de ese tamaño (o menor) detecte siempre una incompatibilidad global. Para cualquier ventana fija `k`, elegir `r` impar suficientemente grande para que `2r+1 > k`: cada ventana resulta compatible y el grafo completo no.

Esto **no prueba** que 3-coloración requiera tiempo superpolinómico: la propia estructura `M(C_r)` tiene una demostración corta y reconocible de su imposibilidad. Es un falsador preciso de la **completitud de una clase determinada de controles locales**, no de toda operación relacional.

## 4. Controles computacionales [E]

`verificar_R04.py` usa biblioteca estándar y separa:

- `cierre_diamante`: solo fusiones con prueba E26; resultado `contradiccion` o `sin_conclusion`, nunca interpreta silencio como compatibilidad.
- `dsatur`: decisión exacta por búsqueda con ruptura de simetría de nombres de color, empleada como oráculo independiente de prueba para las instancias finitas; sus números de nodos **no** son cotas asintóticas.
- `elimination`: proyección existencial por tablas de frontera (CR–6), solo como **línea base de comparación**, sujeta a presupuestos explícitos. No se presenta como una clase nueva capaz de escapar a N1.
- Verificación de 64 grafos etiquetados de cuatro vértices contra fuerza bruta y comprobación de criticidad por supresión para `M(C_r)` con `r=5,7,9,11,13`.

| Instancia | Vértices | Diamantes | 3-coloreable | Regla de diamante | Tablas |
|---|---:|---:|:---:|---|---|
| `W5` | 6 | 5 | No | contradicción | incompatibilidad |
| `W7` | 8 | 7 | No | contradicción | incompatibilidad |
| `W9` | 10 | 9 | No | contradicción | incompatibilidad |
| `W11` | 12 | 11 | No | contradicción | incompatibilidad |
| `M(C5)` | 11 | 0 | No | sin conclusión | incompatibilidad |
| `M(C7)` | 15 | 0 | No | sin conclusión | incompatibilidad |
| `M(M(C5))` | 23 | 0 | No | sin conclusión | **presupuesto**, no decisión |
| Cuadrícula `3×4` | 12 | 0 | Sí | sin conclusión | compatible |

En el ensayo `M(M(C5))`, la búsqueda exacta decide que no existe 3-coloración. El motor de tablas supera su **límite por unión de 100.000** y se interrumpe sin respuesta. **No** registrar ese límite como una demostración de dificultad asintótica.

Nota metodológica: el algoritmo de diamantes es polinómico (en cada fusión disminuye el número de clases y las inspecciones de vecinos son polinómicas). En esta familia resuelve toda rueda impar; eso no implica que sea completo sobre grafos arbitrarios.

## 5. Qué ganamos respecto de R–03 [I]

El ejemplo de paridad R–03 mostraba que una relación global podía resolverse en `O(n)` con el álgebra adecuada. Ahora tenemos un contraste **dentro de 3-coloración**:

- Las ruedas impares admiten un cierre estructural repetible, barato y certificado.
- Los `M(C_r)` exhiben un punto de incompatibilidad que no se manifiesta en ninguna prueba de una ventana propia de vértices, aunque tiene certificado global elemental.

Por tanto, **el orden de las relaciones que hay que reunir, el radio que pueda medir la separación y el exponente del costo algorítmico son magnitudes distintas**. Ninguna implica automáticamente a las otras.

### Próxima pregunta falsable, sin pedir nuevos postulados

> ¿Qué representación interna permite a la cápsula `Representar–Comparar–Incorporar–Refinar–Unir–Proyectar–Vacío–Certificar` identificar un certificado global como el de `M(C_r)` sin enumerar realizaciones, y cómo se verifica que el mismo tipo de operación funciona **para cualquier** instancia de 3-coloración?

Un operador propuesto debe declarar: (a) cuáles son sus entradas válidas, (b) qué pregunta preserva, (c) prueba de equivalencia al incorporar una relación, (d) costo total de **construir** el certificado, no solo comprobarlo, y (e) familias de contraejemplos. Si resulta una secuencia de `n^d` operaciones, debe demostrarse que `d` es constante independiente de la entrada. Si produce una secuencia de `n` etapas de costo `n^2`, sería `O(n^3)` sin importar que la profundidad crezca linealmente.

## 6. Estado

- [T] Distinción entre indefinición, determinación e incompatibilidad bajo el contrato R–03.
- [T] Transición exacta de W5 y cierre por alternancia de todas las ruedas impares.
- [T] Familia infinita de Mycielski de ciclo impar sin triángulos ni diamantes, no 3-coloreable y crítica por supresión de vértice.
- [E] Controles finitos, verificador exacto y presupuesto explícito para tablas.
- [A] Una cápsula nueva y completa para todos los grafos con cota polinómica; P=NP o P≠NP; vínculo físico del punto de indefinición.

**Fuentes internas:** R–03 29-oct; R–02 29-oct; suplemento `ACTUALIZACION_PNP_CME_2026-10-28_revisada.md` (§§3–6, T-PN-CME-2, E25/E26, N1), e Imagen Total 3.9 (§6). La construcción de Mycielski y sus propiedades son matemáticas conocidas: aquí se desarrolla una demostración especializada, no una reclamación de descubrimiento original.
