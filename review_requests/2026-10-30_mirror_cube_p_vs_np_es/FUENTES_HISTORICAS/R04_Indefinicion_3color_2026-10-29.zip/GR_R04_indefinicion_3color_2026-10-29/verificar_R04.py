#!/usr/bin/env python3
"""R-04 | Indefinición, cierre por diamantes y 3-coloración.
Sólo usa la biblioteca estándar, exactitud íntegra, y salida reproducible.
No pretende decidir P frente a NP.
"""
from itertools import combinations, product
from collections import defaultdict
from pathlib import Path
import json


def normalize(n, edges):
    e=set()
    for u,v in edges:
        assert 0 <= u < n and 0 <= v < n
        if u!=v: e.add(tuple(sorted((u,v))))
    return tuple(sorted(e))


def cycle(k): return k, normalize(k, [(i,(i+1)%k) for i in range(k)])

def wheel(k):
    assert k >= 5 and k % 2 == 1
    n,E=cycle(k)
    return n+1,normalize(n+1,list(E)+[(i,n) for i in range(n)])

def mycielski(g):
    n,E=g
    # original 0..n-1; clones n..2n-1; apex 2n
    edges=list(E)+[(u,n+v) for u,v in E]+[(v,n+u) for u,v in E]+[(n+i,2*n) for i in range(n)]
    return 2*n+1,normalize(2*n+1,edges)

def grid(h,w):
    E=[]
    for i in range(h):
        for j in range(w):
            if i+1<h:E.append((i*w+j,(i+1)*w+j))
            if j+1<w:E.append((i*w+j,i*w+j+1))
    return h*w,normalize(h*w,E)

def neighbors(n,E):
    ns=[set() for _ in range(n)]
    for u,v in E: ns[u].add(v); ns[v].add(u)
    return ns

def triangle_diamond(n,E):
    adj=neighbors(n,E)
    tri=sum(1 for i,j,k in combinations(range(n),3) if j in adj[i] and k in adj[i] and k in adj[j])
    # diamante: ancla i-j adyacente con dos vecinos comunes distintos
    dia=sum(len(adj[i]&adj[j])*(len(adj[i]&adj[j])-1)//2 for i,j in E)
    return tri,dia

def cierre_diamante(n,E):
    """Contracciones certificadas por un par adyacente con dos vecinos comunes.
    Retorna contradicción o grafo cociente. No afirma completitud.
    """
    p=list(range(n));count=0;steps=0
    def find(x):
        while p[x]!=x:
            p[x]=p[p[x]]; x=p[x]
        return x
    while True:
        V=sorted({find(i) for i in range(n)})
        ed={(find(u),find(v)) for u,v in E}
        if any(u==v for u,v in ed):
            return {'estado':'contradiccion','fusiones':count,'rondas':steps,'vertices_restantes':len(V)}
        adj={i:set() for i in V}
        for u,v in ed: adj[u].add(v);adj[v].add(u)
        proposed=None
        for u,v in sorted(tuple(sorted(p)) for p in ed):
            common=sorted(adj[u] & adj[v])
            if len(common)>=2:
                a,b=common[:2]
                # si los comunes son adyacentes, el grafo contiene K4 y es imposible
                if b in adj[a]:
                    return {'estado':'contradiccion','fusiones':count,'rondas':steps,'vertices_restantes':len(V),'testigo':'K4 en ancla'}
                proposed=(a,b)
                break
        if proposed is None:
            return {'estado':'sin_conclusion','fusiones':count,'rondas':steps,'vertices_restantes':len(V)}
        a,b=proposed
        p[max(a,b)]=min(a,b)
        count+=1; steps+=1


def dsatur(n,E, colors=3, need_pair=None):
    """Verificador exacto de existencia, orden DSATUR y ruptura S3.
    need_pair=(u,v,iguales) opcional. Devuelve testigo si existe.
    """
    adj=neighbors(n,E)
    color=[-1]*n
    nodes=0
    def dfs(used):
        nonlocal nodes
        nodes+=1
        left=[v for v in range(n) if color[v]<0]
        if not left:
            if need_pair and ((color[need_pair[0]]==color[need_pair[1]])!=need_pair[2]): return False
            return True
        v=max(left,key=lambda v:(len({color[u] for u in adj[v] if color[u]>=0}),len(adj[v]),-v))
        banned={color[u] for u in adj[v] if color[u]>=0}
        for c in range(min(colors-1,used+1)+1):
            if c in banned: continue
            color[v]=c
            if need_pair:
                u,w,eq=need_pair
                if color[u]>=0 and color[w]>=0 and (color[u]==color[w])!=eq:
                    color[v]=-1;continue
            if dfs(max(c,used)): return True
            color[v]=-1
        return False
    sat=dfs(-1)
    return {'compatible':sat,'nodos_busqueda':nodes,'testigo':color[:] if sat else None}


def minfill_order(n,E):
    adj=neighbors(n,E); remaining=set(range(n));order=[];maxbag=0
    while remaining:
        def key(v):
            ns=adj[v]&remaining
            missing=sum(1 for a,b in combinations(ns,2) if b not in adj[a])
            return (missing,len(ns),v)
        v=min(remaining,key=key);B=adj[v]&remaining
        maxbag=max(maxbag,len(B)+1)
        for a,b in combinations(B,2):adj[a].add(b);adj[b].add(a)
        remaining.remove(v);order.append(v)
    return order,maxbag


def elimination(n,E,max_enumerations=300000):
    """Proyección existencial exacta de tablas con límite explícito por factor.
    Estados cada factor = {tuple de valores} y su frontera; costo = asignaciones
    candidatas examinadas para uniones, no tiempo ni cota asintótica.
    """
    factors=[((u,v),{(a,b) for a in range(3) for b in range(3) if a!=b}) for u,v in E]
    order,width=minfill_order(n,E)
    attempted=0; peak_states=max([len(v) for _,v in factors] or [1]); peak_scope=2 if E else 0
    for elim in order:
        selected=[(scope,S) for scope,S in factors if elim in scope]
        factors=[f for f in factors if elim not in f[0]]
        if not selected: continue
        joint=tuple(sorted(set().union(*(set(scope) for scope,_ in selected))))
        nassign=3**len(joint)
        if nassign>max_enumerations:
            return {'estado':'PRESUPUESTO','limite_por_union':max_enumerations,'bolsa':len(joint), 'candidatos_estimados':nassign,'candidatos_examinados':attempted,'max_frontera_orden':width,'max_firma_observada':peak_states}
        pos={v:i for i,v in enumerate(joint)}
        loc=[([pos[v] for v in scope],S) for scope,S in selected]
        drop=pos[elim]
        allowed=set()
        for row in product(range(3),repeat=len(joint)):
            attempted+=1
            if all(tuple(row[i] for i in idx) in S for idx,S in loc):
                allowed.add(tuple(x for i,x in enumerate(row) if i!=drop))
        remaining=tuple(v for v in joint if v!=elim)
        peak_states=max(peak_states,len(allowed))
        peak_scope=max(peak_scope,len(remaining))
        if not allowed:
            return {'estado':'INCOMPATIBLE','candidatos_examinados':attempted,'max_frontera_orden':width,'max_firma_observada':peak_states,'max_alcance_firma':peak_scope}
        if remaining: factors.append((remaining,allowed))
    return {'estado':'COMPATIBLE','candidatos_examinados':attempted,'max_frontera_orden':width,'max_firma_observada':peak_states,'max_alcance_firma':peak_scope}


def indeterminacion_par(n,E,u,v):
    a=dsatur(n,E,need_pair=(u,v,True))
    b=dsatur(n,E,need_pair=(u,v,False))
    if a['compatible'] and b['compatible']: return 'INDEFINIDO'
    if a['compatible']:return 'IGUALES'
    if b['compatible']:return 'DIFERENTES'
    return 'VACIO'


def casos():
    base=[]
    base.append(('C5',cycle(5)))
    base.append(('C7',cycle(7)))
    base.append(('W5',wheel(5)))
    base.append(('W7',wheel(7)))
    base.append(('W9',wheel(9)))
    base.append(('W11',wheel(11)))
    base.append(('Grötzsch M(C5)',mycielski(cycle(5))))
    base.append(('M(C7)',mycielski(cycle(7))))
    base.append(('M(M(C5))',mycielski(mycielski(cycle(5)))))
    base.append(('Cuadrícula 3x4',grid(3,4)))
    base.append(('Diamante K4-e',(4,normalize(4,[(0,1),(0,2),(0,3),(1,2),(1,3)]))))
    base.append(('K4',(4,normalize(4,combinations(range(4),2)))))
    return base


def ensayo_secuencial_wheel():
    n=6;hub=5
    E=normalize(n,[(i,hub) for i in range(5)])
    seq=[('sin_aristas_del_anillo', E)]
    for i in range(4):
        E=normalize(n,list(E)+[(i,i+1)])
        seq.append((f'con_{i+1}_aristas_del_anillo',E))
    E=normalize(n,list(E)+[(4,0)])
    seq.append(('anillo_cerrado',E))
    out=[]
    for tag,E in seq:
        q=indeterminacion_par(n,E,0,4)
        found=dsatur(n,E)
        out.append({'paso':tag,'pregunta_q_color_0_igual_color_4':q,'solucion_existe':found['compatible'], 'aristas':len(E)})
    assert out[0]['pregunta_q_color_0_igual_color_4']=='INDEFINIDO'
    assert out[-2]['pregunta_q_color_0_igual_color_4']=='IGUALES'
    assert out[-1]['pregunta_q_color_0_igual_color_4']=='VACIO'
    return out


def validaciones():
    # Correctitud del DSATUR en todos los grafos etiquetados de 4 vertices (2^6=64).
    for mask in range(1<<6):
        all_edges=list(combinations(range(4),2))
        E=normalize(4,(ed for i,ed in enumerate(all_edges) if mask>>i&1))
        exact=dsatur(4,E)['compatible']
        brute=any(all(z[u]!=z[v] for u,v in E) for z in product(range(3),repeat=4))
        assert exact==brute
        dp=elimination(4,E)
        assert (dp['estado']=='COMPATIBLE')==brute, (mask,dp)
        d=cierre_diamante(4,E)
        if d['estado']=='contradiccion': assert not brute
    # Criticidad vértices M(C5) y ausencia de diamantes
    n,E=mycielski(cycle(5))
    assert not dsatur(n,E)['compatible']
    assert triangle_diamond(n,E)==(0,0)
    for u in range(n):
        vs=[v for v in range(n) if v!=u]
        ren={v:i for i,v in enumerate(vs)}
        EE=normalize(n-1,[(ren[a],ren[b]) for a,b in E if a!=u and b!=u])
        assert dsatur(n-1,EE)['compatible'],u
    return {'64_grafos_n4_comparados_con_fuerza_bruta':True,'M_C5_critico_por_vertices':True}


def familia_critica_mycielski():
    """Controles finitos de una proposición que se demuestra aparte en la nota."""
    checked=[]
    for k in (5,7,9,11,13):
        n,E=mycielski(cycle(k))
        assert triangle_diamond(n,E)==(0,0)
        assert not dsatur(n,E)['compatible']
        for drop in range(n):
            vs=[v for v in range(n) if v!=drop]
            ren={v:i for i,v in enumerate(vs)}
            reduced=normalize(n-1,[(ren[a],ren[b]) for a,b in E if a!=drop and b!=drop])
            assert dsatur(n-1,reduced)['compatible']
        checked.append({'ciclo_original':k,'vertices_mycielski':n,'aristas':len(E),'triangulos':0,'diamantes':0,'3colorable':False,'todas_las_supresiones_de_un_vertice_3colorables':True})
    return checked


def main():
    verify=validaciones()
    rows=[]
    for tag,(n,E) in casos():
        triun,dia=triangle_diamond(n,E)
        cd=cierre_diamante(n,E)
        cert=dsatur(n,E)
        dp=elimination(n,E, max_enumerations=100000)
        if dp['estado']!='PRESUPUESTO':assert (dp['estado']=='COMPATIBLE')==cert['compatible'],(tag,dp,cert)
        rows.append({'grafo':tag,'n':n,'m':len(E),'triangulos':triun,'diamantes':dia,'cierre_diamante':cd,'3_colorable':cert['compatible'],'nodos_dsatur':cert['nodos_busqueda'],'tablas':dp})
        print(f"{tag:22s} n={n:2d} m={len(E):3d} tri={triun:3d} diam={dia:3d} diamante={cd['estado']:14s} 3col={str(cert['compatible']):5s} tabla={dp['estado']:13s} candidatos={dp.get('candidatos_examinados', 0)}")
    result={'version':'R04 2026-10-29','controles':verify,'secuencia_wheel_W5':ensayo_secuencial_wheel(),'familia_critica_mycielski':familia_critica_mycielski(),'graficos':rows,'notas':['PRESUPUESTO no es respuesta de decisión','conteos para instancias finitas no establecen cotas asintóticas','cierre por diamantes es correcto pero incompleto']}
    p=Path(__file__).with_name('resultados_R04.json')
    p.write_text(json.dumps(result,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
    print('resultados guardados:',p)

if __name__=='__main__':main()
