# R–04 | 29 de octubre de 2026

Complemento autónomo para evaluar el punto de indefinición y el cierre en 3-coloración, sin magnitudes energéticas.

**Documentos**
- `NOTA_R04_CIERRE_SINGULARIDAD_Y_3COLOR.md`: formulación, demostraciones, resultados y límites.
- `verificar_R04.py`: controles reproducibles exactos (Python 3, solo biblioteca estándar).
- `resultados_R04.json`: salida archivada de la ejecución.

**Reproducir**: `python3 verificar_R04.py`.

Este paquete **no sustituye** el material base, ni declara resuelto P versus NP. La tabla extensional es línea base y los casos de presupuesto son pruebas inconclusas, no resultados negativos.
