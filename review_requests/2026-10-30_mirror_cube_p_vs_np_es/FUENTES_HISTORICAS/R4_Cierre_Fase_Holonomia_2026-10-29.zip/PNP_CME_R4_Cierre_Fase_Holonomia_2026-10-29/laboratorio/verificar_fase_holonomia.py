#!/usr/bin/env python3
"""PGR/CME/PNP R4. Verificador exacto y finito, biblioteca estándar.

Resultados: tensión Z3 sobre ciclos; caras triangulares localmente consistentes;
holonomía global no nula y condición precisa en un toro triangular periódico.
No afirma P=NP ni P!=NP. La geometría/teoremas son clásicos.
"""
import json
import itertools
from collections import defaultdict, deque
from pathlib import Path


def construir_toro(n, m):
    if min(n, m) < 4: raise ValueError('n,m >= 4 para grafo simple sin degeneraciones')
    xy = [(i, j) for i in range(n) for j in range(m)]
    idx = {v:k for k,v in enumerate(xy)}
    def v(i,j): return idx[(i % n, j % m)]
    caras = []
    for i in range(n):
        for j in range(m):
            caras.append((v(i,j),v(i+1,j),v(i,j+1)))
            caras.append((v(i+1,j+1),v(i,j+1),v(i+1,j)))
    return xy, caras


def firma_caras(n, m):
    xy, caras = construir_toro(n, m)
    eps = {} # tensión e_ab para a<b, valores +/-1 en F3
    incidencias=defaultdict(list)
    for f, (a,b,c) in enumerate(caras):
        s = 1 if f % 2 == 0 else -1
        for u,v in ((a,b),(b,c),(c,a)):
            key = (min(u,v),max(u,v))
            inc = s if u < v else -s
            if key in eps: assert eps[key] == inc, ('incompatibilidad cara-cara',n,m,f,key)
            else: eps[key] = inc
            incidencias[key].append(f)
    assert len(eps) == 3*n*m
    assert len(caras) == 2*n*m
    assert all(len(fs)==2 for fs in incidencias.values())
    # Una cara debe cerrar en F3, aunque el transporte global no cierre
    for (a,b,c) in caras:
        assert (inc_e(eps,a,b)+inc_e(eps,b,c)+inc_e(eps,c,a)) % 3 == 0
    # La adyacencia dual es bipartita: una cara arriba y una abajo.
    for f,fs in enumerate(incidencias.values()):
        assert (fs[0]%2) != (fs[1]%2)
    idx={coord:i for i,coord in enumerate(xy)}
    def v(i,j):return idx[(i%n,j%m)]
    Hx=sum(inc_e(eps,v(i,0),v(i+1,0)) for i in range(n))%3
    Hy=sum(inc_e(eps,v(0,j),v(0,j+1)) for j in range(m))%3
    assert Hx == n%3 and Hy == (-m)%3
    col,errores=integrar_potencial(len(xy),eps)
    # Es suficiente: integración exacta de la forma cerrada cuando periodos cero
    assert (col is not None) == (Hx == 0 and Hy == 0)
    if col is not None:
        assert all(col[b]-col[a] in (1,-1,2,-2) and (col[b]-col[a]-s)%3==0
                   for (a,b),s in eps.items())
    return {'n':n,'m':m,'vertices':len(xy),'aristas':len(eps),'caras':len(caras),
            'dual_bipartito':True,'cierre_de_cada_cara':True,
            'holonomias_Z3':[Hx,Hy], 'tension_integrable': col is not None,
            'numero_coloraciones_predicho': 6 if col is not None else 0,
            'incompatibilidades_integracion':errores}


def inc_e(eps,u,v):
    assert u!=v
    return eps[(min(u,v),max(u,v))]*(1 if u<v else -1)


def integrar_potencial(n,eps):
    vecinos=[[] for _ in range(n)]
    for (a,b),s in eps.items():
        vecinos[a].append((b,s));vecinos[b].append((a,-s))
    color={0:0};q=deque([0]);inconsistencias=0
    while q:
        u=q.popleft()
        for v,s in vecinos[u]:
            prop=(color[u]+s)%3
            if v not in color:
                color[v]=prop;q.append(v)
            elif color[v]!=prop:
                inconsistencias+=1
    assert len(color)==n
    return (color if inconsistencias == 0 else None), inconsistencias


def brute3(n,m):
    xy,caras=construir_toro(n,m)
    e=set()
    for a,b,c in caras:
        for u,v in ((a,b),(b,c),(c,a)):
            e.add((min(u,v),max(u,v)))
    N=n*m;nb=[set() for _ in range(N)]
    for u,v in e:nb[u].add(v);nb[v].add(u)
    states=[-1]*N;states[0]=0; count=[0]; nodes=[0]
    def dfs():
        nodes[0]+=1
        if nodes[0]>100000:raise RuntimeError('límite de enumeración')
        best=None; domain=None
        for i in range(N):
            if states[i]!=-1:continue
            used={states[j] for j in nb[i] if states[j]!=-1}
            opts=[c for c in range(3) if c not in used]
            if not opts:return
            if domain is None or len(opts)<len(domain):best,domain=i,opts
        if best is None:
            count[0]+=1;return
        for a in domain:
            states[best]=a;dfs()
        states[best]=-1
    dfs()
    # El primer vértice se fija a 0; renombrar los tres colores da factor 3.
    return {'numero_coloraciones_exhaustivo':3*count[0], 'nodos_de_busqueda':nodes[0]}


def main():
    casos=[(4,4),(5,4),(6,4),(4,6),(5,5),(6,6),(6,9),(9,6),(9,9),(10,10)]
    res=[]
    for n,m in casos:
        d=firma_caras(n,m)
        if n*m<=36:
            brute=brute3(n,m)
            assert brute['numero_coloraciones_exhaustivo']==d['numero_coloraciones_predicho'],(n,m,brute,d)
            d.update(brute)
        res.append(d)
    out={'version':'PNP-CME-R4 2026-10-29',
         'alcance':'Familia explicita de triangulaciones toroidales T(n,m), n,m>=4',
         'enunciado':'3-coloracion existe sii n y m son divisibles por 3; dual de caras siempre bipartito',
         'casos':res,'estado':'PASS',
         'advertencia':'Teorema clasico de tensiones y cohomologia; la realizacion se incorpora como laboratorio PGR. No mejora la complejidad del 3COL general.'}
    path=Path(__file__).parent/'resultados_fase_holonomia.json'
    path.write_text(json.dumps(out,ensure_ascii=False,indent=2,sort_keys=True)+'\n',encoding='utf-8')
    for v in res:
        print(f"T({v['n']},{v['m']}): V={v['vertices']:3d}, caras={v['caras']:3d}, dual bipartito, periodos={v['holonomias_Z3']}, 3COL={v['numero_coloraciones_predicho']}" )
    print('PASS: todos los cierres locales y los controles globales; ',path)

if __name__=='__main__':main()
