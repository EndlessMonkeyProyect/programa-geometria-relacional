# PGR · P frente a NP / Espejos · R4
## La orientación, el desfase y la condición de cierre global

**Fecha de consolidación:** 29 de octubre de 2026  
**Autoría del hilo:** Le Matt Ansatz Di Ego  
**Carácter:** suplemento aditivo exploratorio; no altera la edición base ni la r3.  
**Estado:** identidades y teoremas exactos en modelos declarados; experimento reproducible; P versus NP general **ABIERTO**.

### 1. Hilo ontológico — sin asumir complejidad ni física

Una relación puede conservar su referencia mientras aparecen varias orientaciones posibles. Un cierre local no acredita por sí mismo el cierre del recorrido completo. La caja de espejos enseña que la orientación y la posición pertenecen a preguntas diferentes; una nueva vuelta puede revelar un desfase no detectado por comparaciones locales. Se propone tratar las **orientaciones** como transporte relacional, el **recorrido** como composición y la **referencia común** como la condición que permite reconocer si se retorna al origen. Este uso de «desfase» es matemático y modular; no se atribuye energía física.

### 2. Puente matemático exacto: tres colores como tensiones no nulas

Sea `G=(V,E)` un grafo finito no dirigido; fije una orientación arbitraria en cada arista. Los colores son `c:V→F₃` y la arista es propia si `c(v)≠c(u)`. Defina `ε_uv=c(v)-c(u)∈F₃`. Entonces `ε_uv∈{1,−1}`. Para cualquier ciclo orientado `C`:

```
      ∑_{e∈C} s(C,e) ε_e = 0 en F₃.
```

**Teorema R4-T1 (clásico, exacto).** `G` admite 3-coloración propia si y solo si existe una tensión `ε:E→{±1}⊂F₃` con suma cero sobre una base del espacio de ciclos. Para un grafo conexo, si una tensión cumple todos los ciclos, integra a un potencial `c` único salvo una constante global de `F₃`. **Prueba.** Toda coloración induce las tensiones y la suma telescopa. Recíprocamente, fije un vértice y asigne su color; integre las tensiones sobre un árbol generador. La condición de cierre para cada arista fuera del árbol asegura que su valor coincide con la diferencia de potencial. Como cada tensión es no nula, los extremos tienen colores distintos. ∎

**Cuidado crucial:** las tensiones están restringidas a `±1`, por lo que las igualdades lineales no vuelven trivial la búsqueda universal. Ésta es la formulación estándar de **tensiones modulares sin ceros**, equivalente a 3-coloración; no constituye un algoritmo polinómico general.

### 3. Cierre local de triángulos y orientación de caras

Suponga que `K` es una superficie cerrada, conexa, orientable, *triangulada*, con una orientación coherente de todas sus caras y un dual de caras conexo. Si una cara orientada `f=(u,v,w)` posee tres colores diferentes, sus tres incrementos en el borde deben tener el **mismo** valor `σ_f∈{+1,−1}` en `F₃`. Dos caras vecinas recorren su arista común con sentidos opuestos, así que **sus signos son opuestos**.

Esto obliga a que el grafo dual de caras sea bipartito. Recíprocamente, si el dual es bipartito, asigne alternadamente `σ_f=+1` y `−1` y defina `ε_uv` en cada arista por el incremento que prescribe la cara incidente. La orientación opuesta de la segunda cara garantiza que la definición es coherente. Cada triángulo tiene suma `3σ_f=0` en `F₃`, de modo que `ε` es un 1-cociclo.

**Teorema R4-T2 (consecuencia clásica de teoría de grafos/cohomología).** En estas superficies, la 3-coloración propia existe si y solo si (i) el dual es bipartito y (ii) los periodos de esta tensión `ε` son cero sobre los generadores de `H₁(K;F₃)`. En tal caso la tensión es un coborde `ε=dc` y produce exactamente seis coloraciones propias para el complejo conexo. **Prueba.** La necesidad se deduce de los incrementos de una coloración. La suficiencia se deduce de que una 1-forma cerrada con todos los periodos nulos es exacta: se integra para obtener `c`; sus incrementos son ±1. Las dos asignaciones globales de signo y las tres elecciones de color base dan seis coloraciones. ∎

En particular, el **cierre de todas las caras** no decide el cierre de un recorrido que atraviesa una dirección topológicamente no contráctil. El número de periodos independientes en género `g` es `2g`. Ésta es una instancia exacta del «desfase» que ya investigábamos, no un resultado físico.

### 4. Experimento R4-E1: toro triangular periódico

Defina `T(n,m)` con vértices `(i,j)∈Z_n×Z_m`, `n,m≥4`; conecte cada `(i,j)` con `(i+1,j)`, `(i,j+1)` y `(i+1,j−1)`, con índices periódicos. Cada cuadrilátero fundamental se divide en dos caras triangulares. Todas las caras admiten incrementos ±1 que se cancelan en `F₃`, y el dual de caras es bipartito.

Con `σ_arriba=+1`, `σ_abajo=−1` los transportes sobre las aristas de las dos direcciones fundamentales son `ε_(i,j→i+1,j)=+1` y `ε_(i,j→i,j+1)=−1`. Por tanto, los dos **periodos de cierre** son

```
       H_x = n mod 3,       H_y = −m mod 3.
```

**Teorema R4-T3 (familia declarada).** `T(n,m)` es 3-coloreable si y solo si `3 | n` y `3 | m`.

**Prueba.** Si existe una coloración, la tensión es exacta y ambos periodos deben anularse, dando `3|n` y `3|m`. Si son divisibles por 3, la fórmula `c(i,j)=i−j (mod 3)` está bien definida en el cociente y asigna colores diferentes a todos los pares adyacentes. Hay exactamente seis coloraciones por permutación global de los tres colores. ∎

**Dos pruebas adversarias:** `T(4,4)` tiene 16 vértices, 32 caras, todas las caras cierran y el dual es bipartito, pero `H=(1,2)` y **NO** hay 3-coloración. `T(6,6)` tiene 36 vértices, 72 caras, `H=(0,0)` y **SÍ** tiene exactamente seis coloraciones.

### 5. Reproducción y resultados

`python3 laboratorio/verificar_fase_holonomia.py`

El programa, escrito solo con la biblioteca estándar de Python, construye la triangulación y cada arista, comprueba consistencia de las dos caras incidentes, verifica que los 2nm triángulos cierran, que el dual es bipartito, calcula los dos residuos, intenta integrar la tensión por BFS y contrasta con un enumerador de 3-coloraciones independiente para ejemplos de hasta 36 vértices. La prueba exhaustiva cuenta coloraciones con el primer vértice fijado y multiplica por 3 (simetría de colores). El JSON queda en `laboratorio/resultados_fase_holonomia.json`.

Resultados exactos:

| Familia | Caras | Dual bipartito | Holonomías mod 3 | Coloraciones |
|---|---:|:---:|:---:|---:|
| T(4,4) | 32 | sí | (1,2) | 0 |
| T(6,4) | 48 | sí | (0,2) | 0 |
| T(4,6) | 48 | sí | (1,0) | 0 |
| T(6,6) | 72 | sí | (0,0) | 6 |
| T(9,9) | 162 | sí | (0,0) | 6 |
| T(10,10) | 200 | sí | (1,2) | 0 |

### 6. Qué ganamos y qué NO ganamos

**[DEMOSTRADO, contrato exacto]** El cierre de triángulos y la bipartición del dual **no bastan** para acreditar el cierre global en topología no trivial; se necesitan periodos. Aquí la firma global puede reducirse a dos residuos en `F₃`. Para la familia dada, construcción y verificación son lineales en el número de vértices/aristas/caras. El algoritmo no recorre todas las coloraciones: decide y, si corresponde, construye una en tiempo lineal.

**[ESTADO CONOCIDO]** Las tensiones de `F₃`, el lenguaje de cociclos y holonomías, y el hecho de que las triangulaciones conexas posean propagación rígida de colores son matemática estándar. **La aportación interna del programa** es hilarlos desde el espejo móvil y la orientación, construyendo un laboratorio que distingue las preguntas de cierre local y global.

**[NO-GO / NO EXTRAPOLAR]** `T(n,m)` no representa un grafo general. Agregar triangulaciones a un grafo arbitrario puede cambiar la respuesta a 3-coloración. No se ha probado un procedimiento polinómico que transforme una instancia arbitraria en tal complejo **preservando equivalencia**, ni que reconozca y mantenga interfaces de tamaño limitado para cualquier familia. Tampoco se deriva `P=NP` o `P≠NP`.

### 7. La obligación siguiente: una cápsula de fase operable

Definir una cápsula con `referencia`, `tensiones`, `interfaz`, `periodos de cierre`, `proveniencia de las identidades` y `operaciones` **incorporar relación / comparar / unir / proyectar / refinar / certificar**.

1. **Corrección:** para cada relación agregada, el certificado prueba que la respuesta nueva coincide con la pregunta original sobre el grafo, sin resolverla de antemano.
2. **Costo integral:** no basta la pequeña firma final de este toro; hay que contar cómo se obtiene, se actualiza y se consulta para familias *no* trianguladas, con costo de bits explícito.
3. **Falsadores:** empezar por grafos sin triángulos y anchura creciente, y añadir adversarios que comparten estadísticas locales pero poseen distintos cierres globales. No repetir como si fuera nueva la refutación del diamante o el caso Mycielski ya estudiado.
4. **Criterio de resultado nuevo:** identificar una familia de entradas más amplia que las clases actualmente tratadas, y demostrar un operador de fase con un ahorro **asintótico** frente a una técnica conocida, o producir un límite inferior **para el operador definido**.

**Secuencia PGR:** reflexión → orientación → transporte → cierre local → periodos comunes → cierre global → firma suficiente → pregunta nueva → actualización acreditada y costo. En ROSI la realización se puede indexar como `CME ↔ O59 ↔ MF-97 ↔ E25 ↔ R4 ↔ N1`. Las flechas son relaciones de investigación, no implicaciones universales.
