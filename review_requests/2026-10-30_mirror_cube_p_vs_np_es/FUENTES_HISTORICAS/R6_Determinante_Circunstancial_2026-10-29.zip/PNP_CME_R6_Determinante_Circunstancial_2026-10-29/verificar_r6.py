#!/usr/bin/env python3
"""R6: determinante de restricciones nuevas bajo continuaciones de aristas.
Verificador autocontenido. No necesita dependencias externas.
"""
from itertools import combinations, product
from collections import Counter
import hashlib, json
from pathlib import Path


def edges(n):
    return list(combinations(range(n), 2))


def partitions_3(n):
    """Particiones no vacías en exactamente tres clases sin etiquetas (RG strings)."""
    assert n >= 3
    out = []
    def rec(a, maximum):
        if len(a) == n:
            if maximum == 2:
                out.append(tuple(a))
            return
        for x in range(min(2, maximum + 1) + 1):
            rec(a + [x], max(maximum, x))
    rec([0], 0)
    return out


def make_environment(n):
    es = edges(n)
    partitions = partitions_3(n)
    crossing = []
    complete = (1 << len(es)) - 1
    for p in partitions:
        x = 0
        for idx, (a,b) in enumerate(es):
            if p[a] != p[b]:
                x |= 1 << idx
        crossing.append(x)
    sig = [0] * (1 << len(es))
    for graph in range(len(sig)):
        z = 0
        for j, c in enumerate(crossing):
            if graph & ~c == 0:
                z |= 1 << j
        sig[graph] = z
    return es, partitions, crossing, sig, complete


def all_colorings(n, graph, es):
    # Oráculo independiente por fuerza bruta sobre asignaciones de 3 colores.
    for tup in product(range(3), repeat=n):
        if all(not (graph >> i & 1) or tup[a] != tup[b] for i,(a,b) in enumerate(es)):
            yield tup


def exact_three_partition(n, c):
    # Convierte colores etiquetados a una partición sin etiquetas.
    d = {}
    canon = tuple(d.setdefault(x, len(d)) for x in c)
    return canon if len(d) == 3 else None


def closure(graph, S, crossing, complete):
    if S == 0:
        return complete
    x = complete
    for j, c in enumerate(crossing):
        if S >> j & 1:
            x &= c
    return x


def audit(n):
    es, parts, crossing, sig, full = make_environment(n)
    counts = Counter()
    for g, s in enumerate(sig):
        # Un grafo con n>=3 es colorable iff tiene una coloración que usa tres colores.
        brute = tuple(all_colorings(n, g, es))
        assert bool(s) == bool(brute), (n,g,'colorabilidad')
        # Independencia: el oráculo de coloraciones enumera particiones de tamaño 3.
        from_brute = {exact_three_partition(n, c) for c in brute if len(set(c)) == 3}
        from_sig = {parts[j] for j in range(len(parts)) if s >> j & 1}
        assert from_brute == from_sig, (n,g,'particiones')
        cl = closure(g, s, crossing, full)
        assert cl & g == g, (n,g,'extensividad')
        assert sig[cl] == s, (n,g,'conservacion')
        assert closure(cl, sig[cl], crossing, full) == cl, (n,g,'idempotencia')
        for i,e in enumerate(es):
            new = g | (1 << i)
            expected = s & sum((1 << j) for j, c in enumerate(crossing) if c >> i & 1)
            assert sig[new] == expected, (n,g,e,'novedad')
            assert ((sig[new] == s) == bool(cl >> i & 1) or not s), (n,g,e,'redundancia')
            counts['actualizaciones'] += 1
        for j in range(len(parts)):
            k = crossing[j] # Grafo completo tripartito K_P
            v = sig[g | k]
            assert v == (1 << j if s >> j & 1 else 0), (n,g,j,'contexto separador')
            counts['contextos_separadores'] += 1
        counts['grafos'] += 1
    # Exhaustivo de todas las parejas (G,F), ley exacta de unión de restricciones.
    for g, sg in enumerate(sig):
        for f, sf in enumerate(sig):
            assert sig[g | f] == (sg & sf), (n,g,f,'composicion')
            counts['composiciones'] += 1
    return dict(counts), len(parts), len(es), sig, crossing, es


def check_r5_example():
    # frontera B={0,1}, interior u=2,v=3
    edge = lambda es,a,b: es.index(tuple(sorted((a,b))))
    es = edges(4)
    H1 = sum(1 << edge(es,a,b) for a,b in [(0,1),(0,2),(1,2),(0,3),(1,3)])
    H2 = sum(1 << edge(es,a,b) for a,b in [(0,1),(0,2),(1,2),(0,3)])
    e = 1 << edge(es,2,3)
    def frontier(g):
        return sorted({(c[0],c[1]) for c in all_colorings(4,g,es)})
    assert frontier(H1) == frontier(H2) and len(frontier(H1)) == 6
    assert len(frontier(H1|e))==0 and len(frontier(H2|e))==6
    return {'misma_frontera_anterior': 6, 'despues_H1':0,'despues_H2':6}


def examples(n, sig, crossing, es):
    idx = {e:i for i,e in enumerate(es)}
    mask = lambda pairs: sum(1 << idx[tuple(sorted(pair))] for pair in pairs)
    H = mask([(1,2),(0,1),(0,2),(3,1),(3,2),(0,4)])
    redundant = mask([(3,4)])
    assert not H & redundant and sig[H] == sig[H|redundant]
    G1, G2 = mask([(0,1)]), mask([(1,2)])
    assert sig[G1].bit_count() == sig[G2].bit_count() and sig[G1] != sig[G2]
    witness = next(j for j in range(len(crossing)) if (sig[G1] >> j & 1) and not (sig[G2] >> j & 1))
    K = crossing[witness]
    assert sig[G1|K] != 0 and sig[G2|K] == 0
    return {
        'arista_redundante': {'n':n, 'aristas_iniciales':[(1,2),(0,1),(0,2),(3,1),(3,2),(0,4)], 'nueva_arista':[3,4], 'particiones_antes': sig[H].bit_count(), 'particiones_despues':sig[H|redundant].bit_count()},
        'mismo_N_no_es_misma_firma': {'aristas_G1':[(0,1)],'aristas_G2':[(1,2)],'N_ambos':sig[G1].bit_count(),'contexto_tripartito_que_distingue':[(es[i][0],es[i][1]) for i in range(len(es)) if K>>i&1], 'G1_admite':bool(sig[G1|K]),'G2_admite':bool(sig[G2|K])}
    }


def main():
    results={'version':'R6-2026-10-29','contrato':'grafico simple fijo n>=3; continuaciones por nuevas aristas; consulta de factibilidad de 3 colores'}
    for n in (3,4,5):
        counts, p, m, sig, crossing, es = audit(n)
        results[f'n{n}']={'vertices':n,'aristas_posibles':m,'particiones_exactamente_tres':p,**counts}
        if n==5:
            results['ejemplos'] = examples(n,sig,crossing,es)
    results['r5_testigo']=check_r5_example()
    results['conclusion']='Ley de composicion por interseccion y redundancia contextual demostradas en el contrato; controles exactos exhaustivos n<=5.'
    target=Path(__file__).with_name('resultados_r6.json')
    target.write_text(json.dumps(results, ensure_ascii=False, indent=2,sort_keys=True)+'\n',encoding='utf-8')
    print('R6 PASS')
    for n in (3,4,5):
        r=results[f'n{n}']
        print(n,'grafos',r['grafos'],'composiciones',r['composiciones'],'updates',r['actualizaciones'],'contextos',r['contextos_separadores'])
    print('SALIDA',target)

if __name__=='__main__':
    main()
