# R6 — El determinante circunstancial de una relación

**Programa de Geometría Relacional · 29 de octubre de 2026**  
**Continuación:** MF-97 → CR-6 → E25/E26 → PNP–CME r3 → R5 interior/exterior.  
**Criterio editorial:** se conservan los conceptos ya formulados; solo se explicita la consecuencia matemática comprobada.

## 1. Pregunta

¿Cuándo una relación incorporada cambia de verdad la información distinguible de una estructura presente, y cuándo expresa algo que la estructura ya conservaba? ¿Es suficiente conocer el número `N` de soluciones?

La respuesta debe ser relativa al **marco de observación y al conjunto de continuaciones admitidas**. El laboratorio usa grafos finitos simples y una pregunta fija: la factibilidad de 3-coloración después de añadir aristas entre los mismos vértices.

## 2. Referencia matemática

Fijemos un conjunto `V` de `n≥3` vértices. Una **partición de tres clases** `P=(P₀,P₁,P₂)` divide `V` en tres partes no vacías, sin etiquetas de color. La partición es compatible con `G` cuando toda arista de `G` conecta clases distintas. Escribimos

\[
\mathcal P_3(G)=\{P:\text{partición de }V\text{ en tres clases, válida para }G\}.
\]

Si `G` tiene una 3-coloración que solo usa uno o dos colores, podemos refinar una de sus clases hasta usar exactamente tres porque `n≥3`: dividir una clase no crea conflictos de aristas. Por tanto, `G` es 3-coloreable si y solo si `\mathcal P_3(G)` no está vacío.

El número contextual de familias de soluciones es `N_G=|\mathcal P_3(G)|`. **No se reemplaza la familia por ese número.**

## 3. R6-T1 — Unión de circunstancias por intersección

Para cualesquiera grafos `G,F` sobre el mismo `V`:

\[
\boxed{\mathcal P_3(G\cup F)=\mathcal P_3(G)\cap\mathcal P_3(F).}
\]

**Demostración.** Una partición es válida para la unión si y solo si todas sus aristas atraviesan clases; esto ocurre si y solo si es válida para ambos grafos. ∎

Si la circunstancia añade una arista `e=uv`, su firma se actualiza mediante

\[
\boxed{\mathcal P_3(G+uv)=\{P\in\mathcal P_3(G):P(u)\neq P(v)\}.}
\]

El operador es una **intersección exacta** entre el cierre anterior y la nueva condición. Esta representación conserva las respuestas sin enumerar de nuevo coloraciones etiquetadas, siempre que la firma ya esté disponible.

## 4. R6-T2 — El determinante de novedad es la diferencia distinguible

Definamos para una nueva arista `e`:

\[
\Delta_G(e)=\mathcal P_3(G)\setminus\mathcal P_3(G+e).
\]

La relación es **redundante en el presente** si `\Delta_G(e)=∅`. Equivalentemente,

\[
\boxed{\mathcal P_3(G+uv)=\mathcal P_3(G)\iff
\forall P\in\mathcal P_3(G),\ P(u)\ne P(v).}
\]

Su *magnitud* puede contarse como `|Δ_G(e)|`, pero la diferencia misma contiene más información que esa cantidad.

La **saturación semántica** es `Cl≠(G)={uv: P(u)≠P(v) para todo P∈𝒫₃(G)}`. Contiene las aristas originales y conserva exactamente la misma familia de particiones; además `Cl≠(Cl≠(G))=Cl≠(G)`. Es el representante con todas las desigualdades ya obligatorias, no una nueva dinámica supuesta. Si el grafo ya es incompatible, la familia está vacía y ninguna arista adicional cambia esta respuesta; para otras preguntas se declarará otro contrato.

### Certificado concreto: una arista no escrita pero redundante

Sea `V={0,1,2,3,4}` y

`E={(1,2),(0,1),(0,2),(3,1),(3,2),(0,4)}`.

Los vértices `0` y `3` comparten los dos vecinos adyacentes `1,2`; el lema del diamante los obliga a recibir el mismo tercer color. Como existe `04`, necesariamente `3` y `4` reciben colores distintos. La arista nueva `34` no modifica ninguna partición válida, aun sin estar escrita antes en el grafo. El verificador obtiene **2 particiones antes y 2 después**.

## 5. R6-T3 — Las continuaciones distinguen estructuras con igual N

Para cualquier partición de tres clases `P`, definamos `K_P` como el **grafo completo tripartito** que tiene aristas precisamente entre vértices de clases diferentes de `P`.

**Lema.** Toda 3-coloración de `K_P` determina exactamente `P`, salvo el nombre de los colores. En efecto, cada clase no vacía necesita al menos un color, los colores de clases diferentes no pueden coincidir y solo hay tres colores disponibles. Por tanto,

\[
\boxed{G\cup K_P\text{ es 3-coloreable}\iff P\in\mathcal P_3(G).}
\]

**Teorema de equivalencia por continuaciones.** Dos grafos `G,H` sobre el mismo `V` dan exactamente la misma respuesta de factibilidad ante **todas** las posibles incorporaciones futuras de aristas entre sus vértices si y solo si

\[
\boxed{\mathcal P_3(G)=\mathcal P_3(H).}
\]

**Prueba.** La igualdad de familias implica igualdad de respuestas por R6-T1. Si son distintas, elegimos `P` en su diferencia simétrica; el contexto `K_P` hace factible uno e incompatible el otro, y así separa sus respuestas. ∎

La familia `\mathcal P_3(G)` es, por tanto, un **invariante contextual completo para esta clase de preguntas**. Esto no afirma que su enumeración explícita sea la única codificación posible.

### Testigo: mismo número de respuestas, distinto cierre

En `V={0,1,2,3,4}`, tomar `G₁` con la única arista `01` y `G₂` con la única arista `12`. Ambos poseen exactamente **19** particiones de tres clases compatibles, pero las familias son distintas. Existe un contexto completo tripartito `K_P` que admite 3-coloración con `G₁` y no con `G₂`. Se conserva `N=19`, pero cambia la respuesta a la nueva circunstancia.

Esto demuestra por qué `N` es una medida contextual, no toda la identidad de la solución.

## 6. Dos posiciones de observación

- **Desde el exterior de una isla**: si las continuaciones solo tocan la frontera `B`, la referencia exacta es la firma `Γ_G(B)` de R5.
- **Desde una circunstancia que puede modificar cualquier par interior**: para la pregunta de factibilidad, el invariante exacto de todas las continuaciones sobre el mismo `V` es `\mathcal P_3(G)`.

Ampliar las continuaciones admitidas puede refinar la equivalencia contextual: dos interiores antes indistinguibles pueden separarse. Las dos representaciones responden a **contratos diferentes**, no a realidades incompatibles.

## 7. Economía operacional y próxima investigación

El número de particiones en tres clases de un conjunto de `n` vértices es

\[
S(n,3)=\frac{3^n-3\cdot 2^n+3}{6}.
\]

Su lista explícita puede ser exponencial. En cambio, escribir el **grafo original** requiere solo `O(n²)` bits, y agregar una arista a esa descripción es barato. El costo decisivo cambia de lugar: **determinar la respuesta de cierre de esa descripción ante cada nueva circunstancia**.

La pregunta operativa siguiente es identificar una representación intensional que conserve la ley exacta de composición, permita decidir cuándo una relación es redundante y produzca certificados de incompatibilidad sin materializar toda `\mathcal P_3(G)`.

Propuesta de prueba R7: comparar la firma explícita de R6, el reductor por diamantes E26, los cierres de paridad y una cápsula intensional con nodos de procedencia. Cada caso registrará `estado interior`, `pregunta exterior`, `continuación`, `familia antes`, `familia después`, `testigo`, `operaciones efectuadas` y `costo de bits`.

## 8. Reproducción

Ejecutar `python3 verificar_r6.py`. El código usa solo biblioteca estándar y comprueba, por enumeración independiente de coloraciones etiquetadas:

- todas las `8` instancias sobre 3 vértices, `64` sobre 4 y `1.024` sobre 5;
- la conservación e idempotencia de la saturación semántica de aristas;
- **10.648** actualizaciones de una arista;
- **1.052.736** pares de composición de circunstancias;
- **25.992** contextos completos tripartitos de separación;
- el testigo R5 de frontera idéntica y recierre distinto;
- los dos testigos propios de R6.

Las pruebas son finitas; las identidades T1, T2 y T3 quedan demostradas por los argumentos anteriores.

## 9. Resultado de ROSI (alcance de la pregunta)

**Determinante:** diferencia de familias de posibilidades reconocibles ante una continuación admitida, relativa al contrato de referencia.  
**Cierre demostrado:** intersección exacta, criterio de redundancia y separación por contextos tripartitos.  
**Siguiente discriminante:** costo de generar y actualizar una representación implícita suficiente, no solo su existencia matemática.
