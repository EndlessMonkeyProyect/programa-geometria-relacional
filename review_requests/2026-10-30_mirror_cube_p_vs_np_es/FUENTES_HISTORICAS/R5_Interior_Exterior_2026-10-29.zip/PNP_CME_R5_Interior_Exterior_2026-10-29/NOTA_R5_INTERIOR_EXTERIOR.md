# Programa de Geometría Relacional — R5
## Misma referencia exterior, interiores diferentes ante una relación nueva

**Corte:** 29 de octubre de 2026. **Autoría del hilo:** Le Matt Ansatz Di Ego.  
**Carácter:** realización aditiva sobre P versus NP; no redefine singularidad, normalización, equivalencia contextual ni el hilo ontológico. **No afirma P=NP ni P≠NP.**

### 1. Fuente y alcance del contrato

Recuperamos *sin reformularlos*: **MF-106 §6** (MF-97, equivalencia relativa a las continuaciones admisibles, y el criterio de no-factorización), **CR-6** (firma de frontera), **E25/E26** (proyección exacta y testigo de diamante), **PNP–CME r3, T-PN-CME-2** (criterio para que una transformación actúe sobre una firma) y **R-04** (indefinición, determinación e incompatibilidad relativas a condiciones y consulta). **R4** aporta otra realización: un cierre local de fases puede dejar residuos globales. Esta nota pregunta: ¿cuándo las preguntas que llegan desde afuera son distinguibles de modificaciones que ocurren dentro de la región?

La analogía de la *isla/espejo* es exclusivamente la interpretación dentro del programa: desde el exterior reconocemos una respuesta de frontera; desde el interior continúan existiendo las configuraciones que la producen. No se identifica esta realización de grafos con una singularidad física.

### 2. Definiciones heredadas y un teorema de composición [T]

Sea `H=(V,E)` un grafo finito y `B⊆V` su frontera declarada. Denotamos:

\[
\mathcal C_3(H)=\{c:V\to\{0,1,2\}:c(u)\ne c(v)\ \forall\,uv\in E\},
\quad
\Gamma_H(B)=\{c|_B:c\in\mathcal C_3(H)\}.
\]

Si dos regiones `H` y `K` solo comparten vértices de `B` (y no tienen aristas adicionales entre sus interiores), entonces:

\[
\boxed{H\cup_B K\text{ admite 3-coloración}\iff \Gamma_H(B)\cap\Gamma_K(B)\ne\varnothing.}\tag{R5-T1}
\]

**Prueba:** Toda coloración conjunta se restringe a una coloración válida de cada lado con idénticos colores en `B`. Recíprocamente, dos coloraciones válidas que coinciden en `B` se pueden unir, porque ninguna arista conecta interiores ajenos. ∎

**Lectura:** para *todas las continuaciones puramente exteriores que se conectan solo por `B`*, la firma de frontera es suficiente, incluso si el interior contiene múltiples historias.

### 3. Qué ocurre al incorporar una relación [T]

**(a) Relación sobre la frontera.** Si se agrega una arista `ab` con `a,b∈B`, sin haber estado antes, entonces

\[
\boxed{\Gamma_{H+ab}(B)=\{\beta\in\Gamma_H(B):\beta(a)\ne\beta(b)\}.}\tag{R5-T2}
\]

Ésta sí es una actualización exacta calculable desde la firma antigua. No requiere abrir las configuraciones internas, **si la firma está disponible**.

**(b) Relación entre puntos interiores.** Para una nueva arista `uv` con `u,v∉B`, no existe, en general, una transformación que actualice `\Gamma_H(B)` utilizando **solo** esa firma. El siguiente falsador lo prueba.

### 4. R5-F1 — Dos interiores, una misma firma, distinto recierre [F/T/E]

Tomar `V={0,1,2,3}`, `B={0,1}`, `u=2`, `v=3`. Dos regiones:

- `H₁` (diamante): aristas `01,02,12,03,13`.
- `H₂` (diamante con una arista retirada): `01,02,12,03`.

La pregunta exterior en ambos casos recibe exactamente las seis asignaciones de colores diferentes en `0` y `1`:

\[
\boxed{\Gamma_{H_1}(B)=\Gamma_{H_2}(B)=\{(a,b)\in\{0,1,2\}^2:a\ne b\}.}
\]

Se incorpora **la misma** arista interior `23` a ambos escenarios.

- En `H₁`, los vértices `2` y `3` estaban obligados a compartir el único tercer color. La nueva arista exige que difieran. Aparece `K₄` y **no queda ninguna solución**: `Γ_{H₁+23}(B)=∅`.
- En `H₂`, el vértice `2` toma el tercer color, pero `3` puede tomar el color de `1`; `23` es compatible. **Permanecen las seis respuestas exteriores**: `Γ_{H₂+23}(B)=Γ_{H₂}(B)`.

| Escenario | Respuestas exteriores antes | Respuestas exteriores después de `23` |
|---|---:|---:|
| `H₁` | 6 | 0 |
| `H₂` | 6 | 6 |

**Conclusión exacta:** la función de actualización «firma exterior antigua `→` nueva firma exterior» no existe para esta clase de modificaciones interiores sin información adicional sobre la región. Es una realización concreta de la no-factorización de MF-97/T-PN-CME-2. **No refuta la normalización anterior:** demuestra que su suficiencia estaba limitada a las continuaciones que fueron acreditadas.

### 5. Qué información adicional basta para una sola nueva arista [T]

Si se conoce de antemano que la próxima consulta es incorporar `uv`, una interfaz enriquecida exacta es:

\[
\Sigma_H^{u,v}(B)=\{(c|_B,c(u),c(v)):c\in\mathcal C_3(H)\}.
\]

Entonces:

\[
\boxed{\Gamma_{H+uv}(B)=\pi_B\big(\Sigma_H^{u,v}(B)\cap\{c(u)\ne c(v)\}\big).}\tag{R5-T3}
\]

Esto demuestra **suficiencia semántica**, no que la interfaz se pueda construir o almacenar con costo polinómico en todo grafo. Tampoco garantiza que sirva ante la siguiente arista distinta: cada familia de continuaciones requiere un contrato.

### 6. Por qué la firma exterior es exacta para *todas* las preguntas exteriores admisibles [T]

Existe además un converso preciso a R5-T1. Si dos grafos tienen firmas distintas sobre `B`, podemos construir un contexto exterior de 3-coloración que distinga su factibilidad al pegarlo por la frontera.

**Construcción del contexto de prueba:** elegir `β∈Γ_{H₁}(B)\setminusΓ_{H₂}(B)`; agregar tres anclas externas `t₀,t₁,t₂` formando un triángulo. Para cada `b∈B`, conectar `b` a las otras dos anclas, salvo `t_{β(b)}`. Esto fuerza que `b` tenga el mismo color que su ancla elegida (hasta un renombramiento global de los tres colores). Como las firmas de 3-coloración son invariantes bajo la permutación simultánea de los nombres de color, el contexto acepta `H₁` y rechaza `H₂`. ∎

Por tanto, la firma `Γ(B)` (o su codificación exacta por órbitas bajo `S₃`, si no hay anclajes absolutos) contiene **exactamente** la información necesaria para discriminar todas las continuaciones exteriores de este tipo. Esto es un resultado elemental de composición contextual, próximo a la idea de equivalencia de estados en teoría de autómatas; no se reclama novedad matemática general.

### 7. Control reproducible [E]

`verificar_r5.py` trabaja con todas las `64` estructuras etiquetadas de cuatro vértices y tres colores; no requiere bibliotecas externas.

- En `32` grafos que no tienen la arista `01`, verifica la actualización por frontera R5-T2.
- En `32` grafos que no tienen la arista interior `23`, verifica la interfaz enriquecida R5-T3.
- En las `64` estructuras y para cada uno de los dos patrones de igualdad de color de `B={0,1}`, verifica por fuerza bruta que el contexto de anclas selecciona exactamente el patrón correspondiente (`128` verificaciones).
- Comprueba por enumeración las seis respuestas idénticas de `H₁/H₂` antes y el resultado `0/6` después de incorporar `23`.

**Resultado:** `PASS`, 192 comprobaciones estructurales más el falsador explícito. Son pruebas finitas y controles de identidades conocidas, no cotas asintóticas.

### 8. Evaluación de cierre y continuación

**[RESOLVED en este contrato]** La frontera es suficiente para continuaciones puramente exteriores. Una modificación de frontera puede actualizarse directamente. Una modificación interna puede exigir procedencia de la estructura interior. Estos tres resultados tienen pruebas y controles exactos.

**[OPEN]** Construir un **refinador operable con procedencia** que descubra y mantenga las referencias internas necesarias para modificaciones futuras *desconocidas*, bajo costo total polinómico en grafos arbitrarios. Debe incluir costo de construir la firma, guardarla, incorporar cambios, consultar y certificar. Afirmar que un conjunto de respuestas se puede representar con una firma corta no demuestra que esa firma se pueda calcular eficientemente.

**Determinante para la siguiente operación, sin confundirlo con el parámetro `N` de complejidad:** qué continuaciones contempla la referencia y cuáles de las diferencias internas sobreviven en la interfaz disponible. La posición interior/exterior y el cambio de la circunstancia alteran el contrato de equivalencia; no alteran retroactivamente las pruebas válidas para el contrato anterior.

**Próximo control falsable:** probar una representación que, para una secuencia de relaciones interiores no anunciadas, elija qué información preservar sin esconder una búsqueda exponencial en el descubrimiento de las firmas. Comparar contra N1 y la batería R4.
