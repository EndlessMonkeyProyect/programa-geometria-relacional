# PGR — R5, interior/exterior y recierre

Suplemento aditivo y reproducible, conectado a MF-97, MF-106, CR-6, E25/E26, PNP–CME r3 y R4.

- `NOTA_R5_INTERIOR_EXTERIOR.md`: pruebas y alcance exacto, contraejemplo de cuatro vértices y próximo contrato.
- `verificar_r5.py`: script Python con biblioteca estándar.
- `resultados_r5.json`: resultado estructurado.
- `MANIFIESTO_SHA256.txt`: verificaciones de integridad de los tres archivos anteriores (el propio manifiesto no se incluye).

Reproducir: `python3 verificar_r5.py` y `sha256sum -c MANIFIESTO_SHA256.txt` desde esta carpeta.

No sustituye originales ni afirma resolver P frente a NP. El contenido describe una aplicación demostrada de la equivalencia contextual ya fijada, no una redefinición ontológica.
