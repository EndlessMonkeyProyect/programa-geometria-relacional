#!/usr/bin/env python3
"""R5: distinción entre frontera exterior e incorporación de aristas interiores.
   Verificador exacto y finito. Biblioteca estándar, sin tiempos como evidencia de complejidad.
"""
import itertools
import json
from pathlib import Path

COLORS = range(3)
VERTICES = range(4)
B = (0, 1)
U, V = 2, 3
ALL_EDGES = tuple(itertools.combinations(VERTICES, 2))


def col(G, n=4):
    return [c for c in itertools.product(COLORS, repeat=n)
            if all(c[i] != c[j] for i,j in G)]


def gamma(G):
    return frozenset(c[:2] for c in col(G))


def enriched(G):
    return frozenset((c[0], c[1], c[U], c[V]) for c in col(G))


def pin_context(beta):
    # 4,5,6 forman un triángulo con tres colores distintos.
    # En la frontera, cada v debe igualar el color del ancla 4+beta[v].
    T = [(4,5),(5,6),(4,6)]
    for v in B:
        for k in range(3):
            if k != beta[v]:
                T.append((v, 4+k))
    return frozenset(T)


def invariant_by_color_permutations(Gamma):
    for p in itertools.permutations(range(3)):
        if {tuple(p[z] for z in a) for a in Gamma} != set(Gamma):
            return False
    return True


def verify():
    tests = dict()
    all_g = []
    for bits in range(1 << len(ALL_EDGES)):
        G = frozenset(e for i,e in enumerate(ALL_EDGES) if bits >> i & 1)
        all_g.append(G)
    assert len(all_g) == 64

    # Si uv es arista interna aún ausente, la interfaz enriquecida permite actualizar.
    for G in all_g:
        if (U,V) not in G:
            expected = {a[:2] for a in enriched(G) if a[2] != a[3]}
            assert expected == gamma(G | {(U,V)})
    tests['incorporacion_interna_con_interfaz_enriquecida'] = '32/32 PASS'

    # Una nueva arista exterior entre puntos de B se computa exclusivamente con Γ(B).
    for G in all_g:
        if (0,1) not in G:
            assert gamma(G | {(0,1)}) == frozenset(a for a in gamma(G) if a[0] != a[1])
    tests['incorporacion_sobre_frontera'] = '32/32 PASS'

    # Interfaz exterior y dos historias diferentes, con la misma arista interna nueva.
    H1 = frozenset({(0,1),(0,2),(1,2),(0,3),(1,3)})  # diamante
    H2 = frozenset({(0,1),(0,2),(1,2),(0,3)})        # diamante sin (1,3)
    initial1, initial2 = gamma(H1), gamma(H2)
    after1, after2 = gamma(H1 | {(2,3)}), gamma(H2 | {(2,3)})
    assert initial1 == initial2 == frozenset((a,b) for a in COLORS for b in COLORS if a != b)
    assert not after1 and after2 == initial2
    assert invariant_by_color_permutations(initial1)
    tests['mismo_exterior_diferente_recierre_interior'] = dict(
        vertices=4, frontera=[0,1], arista_incorporada=[2,3],
        H1_diamante=sorted([list(e) for e in H1]),
        H2_interior_alternativo=sorted([list(e) for e in H2]),
        gamma_antes=[len(initial1),len(initial2)],
        gamma_despues=[len(after1),len(after2)],
        actualizacion_desde_gamma_antes_sola_imposible=True,
    )

    # El contexto testigo (con 3 anclas) reconoce las órbitas de cada patrón de frontera.
    patterns = [(0,0),(0,1)]
    for G in all_g:
        g = gamma(G)
        assert invariant_by_color_permutations(g)
        for pattern in patterns:
            condition = bool(col(G | pin_context(pattern), n=7))
            assert condition == (pattern in g), (G, pattern)
    tests['discriminacion_exterior_por_gadget'] = '64 grafos × 2 patrones = 128/128 PASS'

    # Composición por frontera: dos interiores independientes compartiendo frontera
    # equivale exactamente a intersección de firmas (probada en el documento).
    tests['principio_composicion'] = 'demostración por restricción y unión consistente; no se infiere complejidad'
    return {
        'documento':'PGR R5, 29-oct-2026',
        'naturaleza':'verificación exacta en 4 vertices, no demuestra P=NP ni P≠NP',
        'controles':tests,
        'estado':'PASS',
    }


if __name__ == '__main__':
    result = verify()
    p = Path(__file__).with_name('resultados_r5.json')
    p.write_text(json.dumps(result,ensure_ascii=False,indent=2,sort_keys=True)+'\n',encoding='utf-8')
    print('R5: PASS (32+32+128 ensayos; dos interiores con mismo exterior y recierre diferente)')
